/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
var im='images/';

var fonts = {};


var resources = [
];
var symbols = {
"stage": {
   version: "0.1.7",
   minimumCompatibleVersion: "0.1.7",
   build: "0.11.0.153",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: true,
   resizeInstances: false,
   content: {
         dom: [
         {
            id:'ground',
            type:'rect',
            rect:['61','47','289','74','auto','auto'],
            fill:["rgba(192,192,192,1)"],
            stroke:[0,"rgba(0,0,0,1)","none"]
         },
         {
            id:'BounceTemplate',
            type:'text',
            rect:['39','138','252','90','auto','auto'],
            text:"BOUNCE!",
            align:"center",
            font:['\'Arial Black\', Gadget, sans-serif',24,"rgba(0,0,0,1)","normal","none","normal"]
         },
         {
            id:'BOUNCE',
            type:'text',
            rect:['39','138','252','90','auto','auto'],
            text:"BOUNCE!",
            align:"center",
            font:['\'Arial Black\', Gadget, sans-serif',24,"rgba(0,0,0,1)","normal","none","normal"]
         }],
         symbolInstances: [

         ]
      },
   states: {
      "Base State": {
         "${_ground}": [
            ["color", "background-color", 'rgba(98,103,125,1.00)'],
            ["style", "height", '90px'],
            ["style", "top", '310px'],
            ["style", "left", '0px'],
            ["style", "width", '550px']
         ],
         "${_BOUNCE}": [
            ["style", "top", '0px'],
            ["style", "text-align", 'center'],
            ["transform", "rotateZ", '0deg'],
            ["style", "height", '85px'],
            ["style", "width", '550px'],
            ["style", "left", '0px'],
            ["style", "font-size", '72px']
         ],
         "${_stage}": [
            ["style", "height", '400px'],
            ["style", "width", '550px'],
            ["style", "overflow", 'visible']
         ],
         "${_BounceTemplate}": [
            ["style", "top", '230px'],
            ["style", "text-align", 'center'],
            ["color", "color", 'rgba(255,0,0,1.00)'],
            ["style", "font-size", '72px'],
            ["style", "left", '0px'],
            ["style", "width", '550px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 1000,
         autoPlay: true,
         timeline: [
            { id: "eid95", tween: [ "style", "${_BOUNCE}", "left", '0px', { fromValue: '0px'}], position: 0, duration: 0, easing: "easeOutBounce" },
            { id: "eid97", tween: [ "style", "${_BOUNCE}", "top", '230px', { fromValue: '0px'}], position: 0, duration: 1000, easing: "easeOutBounce" }         ]
      }
   }
}
};


Edge.registerCompositionDefn(compId, symbols, fonts, resources);

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     Edge.launchComposition(compId);
});
})(jQuery, AdobeEdge, "EDGE-178332291");
