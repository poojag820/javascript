/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
var im='images/';

var fonts = {};


var resources = [
];
var symbols = {
"stage": {
   version: "0.1.7",
   minimumCompatibleVersion: "0.1.7",
   build: "0.11.0.153",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: true,
   resizeInstances: false,
   content: {
         dom: [
         {
            id:'BannerBG',
            type:'rect',
            rect:['61','47','289','74','auto','auto'],
            fill:["rgba(192,192,192,1)"],
            stroke:[0,"rgba(0,0,0,1)","none"]
         },
         {
            id:'OnEdgeTemplate',
            type:'text',
            rect:['39','138','252','90','auto','auto'],
            text:"ON the Edge",
            align:"center",
            font:['\'Arial Black\', Gadget, sans-serif',24,"rgba(0,0,0,1)","normal","none","normal"]
         },
         {
            id:'ON',
            type:'text',
            rect:['39','138','252','90','auto','auto'],
            text:"ON",
            align:"center",
            font:['\'Arial Black\', Gadget, sans-serif',24,"rgba(0,0,0,1)","normal","none","normal"]
         },
         {
            id:'EDGE',
            type:'text',
            rect:['39','138','252','90','auto','auto'],
            text:"Edge",
            align:"center",
            font:['\'Arial Black\', Gadget, sans-serif',24,"rgba(0,0,0,1)","normal","none","normal"]
         },
         {
            id:'the',
            type:'text',
            rect:['39','138','252','90','auto','auto'],
            text:"the",
            align:"center",
            font:['\'Arial Black\', Gadget, sans-serif',24,"rgba(0,0,0,1)","normal","none","normal"]
         }],
         symbolInstances: [

         ]
      },
   states: {
      "Base State": {
         "${_ON}": [
            ["style", "top", '-93px'],
            ["style", "text-align", 'center'],
            ["transform", "rotateZ", '-30deg'],
            ["style", "width", '130px'],
            ["style", "left", '-65.2px'],
            ["style", "font-size", '72px']
         ],
         "${_BannerBG}": [
            ["color", "background-color", 'rgba(200,210,250,1.00)'],
            ["style", "height", '100px'],
            ["style", "top", '0px'],
            ["style", "left", '0px'],
            ["style", "width", '550px']
         ],
         "${_EDGE}": [
            ["style", "top", '-113px'],
            ["style", "text-align", 'center'],
            ["transform", "rotateZ", '30deg'],
            ["style", "font-size", '72px'],
            ["style", "left", '477px'],
            ["style", "width", '198px']
         ],
         "${_the}": [
            ["style", "top", '-93px'],
            ["style", "text-align", 'center'],
            ["transform", "rotateZ", '0deg'],
            ["style", "width", '130px'],
            ["style", "left", '172px'],
            ["style", "font-size", '72px']
         ],
         "${_stage}": [
            ["style", "height", '400px'],
            ["color", "background-color", 'rgba(255,255,255,1.00)'],
            ["style", "width", '550px'],
            ["style", "overflow", 'visible']
         ],
         "${_OnEdgeTemplate}": [
            ["style", "top", '0px'],
            ["style", "text-align", 'center'],
            ["style", "height", '100px'],
            ["color", "color", 'rgba(255,0,0,1.00)'],
            ["style", "font-size", '72px'],
            ["style", "left", '0px'],
            ["style", "width", '550px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 1000,
         autoPlay: true,
         timeline: [
            { id: "eid49", tween: [ "transform", "${_ON}", "rotateZ", '0deg', { fromValue: '-30deg'}], position: 0, duration: 500 },
            { id: "eid47", tween: [ "transform", "${_EDGE}", "rotateZ", '30deg', { fromValue: '30deg'}], position: 0, duration: 0 },
            { id: "eid58", tween: [ "transform", "${_EDGE}", "rotateZ", '0deg', { fromValue: '30deg'}], position: 500, duration: 500 },
            { id: "eid23", tween: [ "style", "${_the}", "width", '130px', { fromValue: '130px'}], position: 0, duration: 0 },
            { id: "eid45", tween: [ "style", "${_EDGE}", "left", '477px', { fromValue: '477px'}], position: 0, duration: 0 },
            { id: "eid52", tween: [ "style", "${_EDGE}", "left", '477px', { fromValue: '477px'}], position: 250, duration: 0 },
            { id: "eid59", tween: [ "style", "${_EDGE}", "left", '324.22px', { fromValue: '477px'}], position: 500, duration: 500 },
            { id: "eid48", tween: [ "transform", "${_the}", "rotateZ", '0deg', { fromValue: '0deg'}], position: 0, duration: 0 },
            { id: "eid50", tween: [ "style", "${_ON}", "left", '23.89px', { fromValue: '-65.2px'}], position: 0, duration: 500 },
            { id: "eid44", tween: [ "style", "${_the}", "top", '-93px', { fromValue: '-93px'}], position: 0, duration: 0 },
            { id: "eid54", tween: [ "style", "${_the}", "top", '0px', { fromValue: '-93px'}], position: 250, duration: 500 },
            { id: "eid46", tween: [ "style", "${_EDGE}", "top", '-113px', { fromValue: '-113px'}], position: 0, duration: 0 },
            { id: "eid53", tween: [ "style", "${_EDGE}", "top", '-113px', { fromValue: '-113px'}], position: 250, duration: 0 },
            { id: "eid60", tween: [ "style", "${_EDGE}", "top", '0px', { fromValue: '-113px'}], position: 500, duration: 500 },
            { id: "eid20", tween: [ "style", "${_EDGE}", "width", '198px', { fromValue: '198px'}], position: 0, duration: 0 },
            { id: "eid77", tween: [ "style", "${_the}", "left", '172.42px', { fromValue: '172px'}], position: 0, duration: 750 },
            { id: "eid51", tween: [ "style", "${_ON}", "top", '0px', { fromValue: '-93px'}], position: 0, duration: 500 },
            { id: "eid24", tween: [ "style", "${_ON}", "width", '130px', { fromValue: '130px'}], position: 0, duration: 0 }         ]
      }
   }
}
};


Edge.registerCompositionDefn(compId, symbols, fonts, resources);

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     Edge.launchComposition(compId);
});
})(jQuery, AdobeEdge, "EDGE-175569126");
