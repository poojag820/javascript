/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
var im='images/';

var fonts = {};


var resources = [
];
var symbols = {
"stage": {
   version: "0.1.7",
   minimumCompatibleVersion: "0.1.7",
   build: "0.11.0.153",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
         dom: [
         {
            id:'flowerStrip',
            type:'image',
            rect:['0px','0px','2500px','375px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"flowerStrip375x2500.jpg",'0px','0px']
         }],
         symbolInstances: [

         ]
      },
   states: {
      "Base State": {
         "${_Stage}": [
            ["color", "background-color", 'rgba(255,255,255,1)'],
            ["style", "overflow", 'hidden'],
            ["style", "height", '375px'],
            ["style", "width", '500px']
         ],
         "${_flowerStrip}": [
            ["style", "left", '0px'],
            ["style", "top", '0px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 6250,
         autoPlay: true,
         timeline: [
            { id: "eid8", tween: [ "style", "${_flowerStrip}", "left", '-500px', { fromValue: '0px'}], position: 1000, duration: 250 },
            { id: "eid9", tween: [ "style", "${_flowerStrip}", "left", '-1000px', { fromValue: '-500px'}], position: 2250, duration: 250 },
            { id: "eid10", tween: [ "style", "${_flowerStrip}", "left", '-1500px', { fromValue: '-1000px'}], position: 3500, duration: 250 },
            { id: "eid11", tween: [ "style", "${_flowerStrip}", "left", '-2000px', { fromValue: '-1500px'}], position: 4750, duration: 250 },
            { id: "eid12", tween: [ "style", "${_flowerStrip}", "left", '0px', { fromValue: '-2000px'}], position: 6000, duration: 250 }         ]
      }
   }
}
};


Edge.registerCompositionDefn(compId, symbols, fonts, resources);

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     Edge.launchComposition(compId);
});
})(jQuery, AdobeEdge, "EDGE-172081639");
