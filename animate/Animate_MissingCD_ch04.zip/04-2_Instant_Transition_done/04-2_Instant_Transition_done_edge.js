/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
var im='images/';

var fonts = {};


var resources = [
];
var symbols = {
"stage": {
   version: "0.1.7",
   minimumCompatibleVersion: "0.1.7",
   build: "0.11.0.164",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: true,
   resizeInstances: false,
   content: {
         dom: [
         {
            id:'trafficLight',
            type:'rect',
            rect:['0','0','149','288','auto','auto'],
            fill:["rgba(0,0,0,1.00)"],
            stroke:[0,"rgb(0, 0, 0)","none"],
            transform:[]
         },
         {
            id:'greenLight',
            type:'rect',
            rect:['6648','79207','73','73','auto','auto'],
            borderRadius:["36px 36px","36px 36px","36px 36px","36px 36px"],
            opacity:0.3013698630137,
            fill:["rgba(0,255,0,1.00)"],
            stroke:[0,"rgb(0, 0, 0)","none"],
            transform:[]
         },
         {
            id:'yellowLight',
            type:'rect',
            rect:['6648','79115','73','73','auto','auto'],
            borderRadius:["36px 36px","36px 36px","36px 36px","36px 36px"],
            opacity:0.32876712328767,
            fill:["rgba(255,255,1,1.00)"],
            stroke:[0,"rgb(0, 0, 0)","none"],
            transform:[]
         },
         {
            id:'redLight',
            type:'rect',
            rect:['6648','7923','73','73','auto','auto'],
            borderRadius:["36px 36px","36px 36px","36px 36px","36px 36px"],
            fill:["rgba(253,19,0,1.00)"],
            stroke:[0,"rgb(0, 0, 0)","none"],
            transform:[]
         }],
         symbolInstances: [

         ]
      },
   states: {
      "Base State": {
         "${_trafficLight}": [
            ["color", "background-color", 'rgba(0,0,0,1.00)'],
            ["style", "left", '76px'],
            ["style", "top", '88px']
         ],
         "${_greenLight}": [
            ["color", "background-color", 'rgba(0,255,0,1.00)'],
            ["style", "opacity", '1'],
            ["style", "left", '114px'],
            ["style", "top", '286px']
         ],
         "${_Stage}": [
            ["color", "background-color", 'rgba(255,255,255,1)'],
            ["style", "height", '400px'],
            ["style", "width", '550px']
         ],
         "${_yellowLight}": [
            ["color", "background-color", 'rgba(255,255,1,1.00)'],
            ["style", "opacity", '0.3'],
            ["style", "left", '114px'],
            ["style", "top", '194px']
         ],
         "${_redLight}": [
            ["style", "top", '102px'],
            ["style", "opacity", '0.3'],
            ["style", "left", '114px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 2000,
         autoPlay: true,
         timeline: [
            { id: "eid19", tween: [ "style", "${_yellowLight}", "opacity", '0.3', { fromValue: '0.3'}], position: 0, duration: 0 },
            { id: "eid22", tween: [ "style", "${_yellowLight}", "opacity", '1', { fromValue: '0.3'}], position: 1000, duration: 0 },
            { id: "eid23", tween: [ "style", "${_yellowLight}", "opacity", '0.3', { fromValue: '1'}], position: 2000, duration: 0 },
            { id: "eid27", tween: [ "style", "${_redLight}", "opacity", '0.3', { fromValue: '0.3'}], position: 0, duration: 0 },
            { id: "eid26", tween: [ "style", "${_redLight}", "opacity", '1', { fromValue: '0.3'}], position: 2000, duration: 0 },
            { id: "eid20", tween: [ "style", "${_greenLight}", "opacity", '1', { fromValue: '1'}], position: 0, duration: 0 },
            { id: "eid25", tween: [ "style", "${_greenLight}", "opacity", '0.3', { fromValue: '1'}], position: 1000, duration: 0 }         ]
      }
   }
}
};


Edge.registerCompositionDefn(compId, symbols, fonts, resources);

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     Edge.launchComposition(compId);
});
})(jQuery, AdobeEdge, "EDGE-41881717");
