/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
var im='images/';

var fonts = {};


var resources = [
];
var symbols = {
"stage": {
   version: "0.1.7",
   minimumCompatibleVersion: "0.1.7",
   build: "0.11.0.161",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: true,
   resizeInstances: false,
   content: {
         dom: [
         {
            id:'car',
            type:'image',
            rect:['0','0','381','151','undefined','undefined'],
            fill:["rgba(0,0,0,0)",im+"StutzBearcat.png"]
         },
         {
            id:'tbHide',
            type:'text',
            tag:'p',
            rect:['43','193','95','26','undefined','undefined'],
            text:"Hide",
            font:['Arial Black, Gadget, sans-serif',24,"rgba(0,0,0,1)","normal","none",""]
         },
         {
            id:'tbShow',
            type:'text',
            tag:'p',
            rect:['159','206','95','26','undefined','undefined'],
            text:"Show",
            align:"auto",
            font:['\'Arial Black\', Gadget, sans-serif',24,"rgba(0,0,0,1)","normal","none","normal"]
         },
         {
            id:'tbToggle',
            type:'text',
            tag:'p',
            rect:['289','207','135','26','undefined','undefined'],
            text:"Toggle",
            align:"auto",
            font:['\'Arial Black\', Gadget, sans-serif',24,"rgba(0,0,0,1)","normal","none","normal"]
         }],
         symbolInstances: [

         ]
      },
   states: {
      "Base State": {
         "${_tbShow}": [
            ["style", "top", '193px'],
            ["style", "left", '190.5px']
         ],
         "${_tbHide}": [
            ["style", "left", '21px']
         ],
         "${_car}": [
            ["style", "top", '13px'],
            ["style", "left", '43px']
         ],
         "${_stage}": [
            ["color", "background-color", 'rgba(255,255,255,1.00)'],
            ["style", "width", '468px'],
            ["style", "height", '400px'],
            ["style", "overflow", 'hidden']
         ],
         "${_tbToggle}": [
            ["style", "top", '193px'],
            ["style", "left", '360px'],
            ["style", "width", '95px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 0,
         autoPlay: true,
         timeline: [
            { id: "eid13", tween: [ "style", "${_tbToggle}", "width", '95px', { fromValue: '95px'}], position: 0, duration: 0 },
            { id: "eid10", tween: [ "style", "${_car}", "left", '43px', { fromValue: '43px'}], position: 0, duration: 0 },
            { id: "eid1", tween: [ "style", "${_car}", "top", '13px', { fromValue: '13px'}], position: 0, duration: 0 },
            { id: "eid19", tween: [ "style", "${_tbShow}", "left", '190.5px', { fromValue: '190.5px'}], position: 0, duration: 0 },
            { id: "eid11", tween: [ "style", "${_tbShow}", "top", '193px', { fromValue: '193px'}], position: 0, duration: 0 },
            { id: "eid18", tween: [ "style", "${_tbHide}", "left", '21px', { fromValue: '21px'}], position: 0, duration: 0 },
            { id: "eid12", tween: [ "style", "${_tbToggle}", "top", '193px', { fromValue: '193px'}], position: 0, duration: 0 },
            { id: "eid17", tween: [ "style", "${_tbToggle}", "left", '360px', { fromValue: '360px'}], position: 0, duration: 0 }         ]
      }
   }
}
};


Edge.registerCompositionDefn(compId, symbols, fonts, resources);

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     Edge.launchComposition(compId);
});
})(jQuery, AdobeEdge, "EDGE-53236650");
