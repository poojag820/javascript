/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
var im='images/';

var fonts = {};


var resources = [
];
var symbols = {
"stage": {
   version: "0.1.7",
   minimumCompatibleVersion: "0.1.7",
   build: "0.11.0.161",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: true,
   resizeInstances: false,
   content: {
         dom: [
         {
            id:'car',
            type:'image',
            rect:['0','0','381','151','undefined','undefined'],
            fill:["rgba(0,0,0,0)",im+"StutzBearcat.png"]
         },
         {
            id:'tbHide',
            type:'text',
            tag:'p',
            rect:['43','193','95','26','undefined','undefined'],
            cursor:['pointer'],
            text:"Hide",
            font:['Arial Black, Gadget, sans-serif',24,"rgba(0,0,0,1)","normal","none",""]
         },
         {
            id:'tbShow',
            type:'text',
            tag:'p',
            rect:['159','206','95','26','undefined','undefined'],
            cursor:['pointer'],
            text:"Show",
            align:"auto",
            font:['\'Arial Black\', Gadget, sans-serif',24,"rgba(0,0,0,1)","normal","none","normal"]
         },
         {
            id:'tbToggle',
            type:'text',
            tag:'p',
            rect:['289','207','135','26','undefined','undefined'],
            cursor:['pointer'],
            text:"Toggle",
            align:"auto",
            font:['\'Arial Black\', Gadget, sans-serif',24,"rgba(0,0,0,1)","normal","none","normal"]
         },
         {
            id:'tbFadeIn',
            type:'text',
            tag:'p',
            rect:['43','193','95','26','undefined','undefined'],
            cursor:['pointer'],
            text:"fadeIn",
            font:['Arial Black, Gadget, sans-serif',24,"rgba(0,0,0,1)","normal","none",""]
         },
         {
            id:'tbFadeOut',
            type:'text',
            tag:'p',
            rect:['159','206','95','26','undefined','undefined'],
            cursor:['pointer'],
            text:"fadeOut",
            align:"auto",
            font:['\'Arial Black\', Gadget, sans-serif',24,"rgba(0,0,0,1)","normal","none","normal"]
         },
         {
            id:'tbFadeToggle',
            type:'text',
            tag:'p',
            rect:['289','207','135','26','undefined','undefined'],
            cursor:['pointer'],
            text:"fadeToggle",
            align:"auto",
            font:['\'Arial Black\', Gadget, sans-serif',24,"rgba(0,0,0,1)","normal","none","normal"]
         },
         {
            id:'tbSlideDown',
            type:'text',
            tag:'p',
            rect:['43','193','95','26','undefined','undefined'],
            cursor:['pointer'],
            text:"slideDown",
            font:['Arial Black, Gadget, sans-serif',24,"rgba(0,0,0,1)","normal","none",""]
         },
         {
            id:'tbSlideUp',
            type:'text',
            tag:'p',
            rect:['159','206','95','26','undefined','undefined'],
            cursor:['pointer'],
            text:"slideUp",
            align:"auto",
            font:['\'Arial Black\', Gadget, sans-serif',24,"rgba(0,0,0,1)","normal","none","normal"]
         },
         {
            id:'tbSlideToggle',
            type:'text',
            tag:'p',
            rect:['289','207','135','26','undefined','undefined'],
            cursor:['pointer'],
            text:"slideToggle",
            align:"auto",
            font:['\'Arial Black\', Gadget, sans-serif',24,"rgba(0,0,0,1)","normal","none","normal"]
         },
         {
            id:'btnBar',
            type:'group',
            rect:['177','359','195','28','auto','auto'],
            c:[
            {
               id:'Rectangle',
               type:'rect',
               rect:['0px','2px','195px','26px','auto','auto'],
               borderRadius:["22px 22px","22px 22px","22px 22px","22px 22px"],
               opacity:1,
               fill:["rgba(30,83,176,1.00)"],
               stroke:[0,"rgba(0,0,0,1)","none"],
               boxShadow:["inset",0,0,3,4,"rgba(0,0,0,0.65)"]
            },
            {
               id:'Text',
               type:'text',
               rect:['56px','0px','auto','auto','auto','auto'],
               text:"animate",
               font:['Arial, Helvetica, sans-serif',[24,""],"rgba(255,255,255,1.00)","normal","none",""],
               textShadow:["rgba(0,0,0,0.648438)",3,3,3]
            }]
         }],
         symbolInstances: [

         ]
      },
   states: {
      "Base State": {
         "${_tbSlideDown}": [
            ["style", "top", '298.03px'],
            ["style", "left", '180px'],
            ["style", "cursor", 'pointer']
         ],
         "${_tbSlideToggle}": [
            ["style", "top", '298.03px'],
            ["style", "cursor", 'pointer'],
            ["style", "left", '365.07px'],
            ["style", "width", '95px']
         ],
         "${_tbShow}": [
            ["style", "top", '193px'],
            ["style", "left", '180px'],
            ["style", "cursor", 'pointer']
         ],
         "${_tbFadeOut}": [
            ["style", "top", '241px'],
            ["style", "left", '21px'],
            ["style", "cursor", 'pointer']
         ],
         "${_tbToggle}": [
            ["style", "top", '193px'],
            ["style", "cursor", 'pointer'],
            ["style", "left", '365.07px'],
            ["style", "width", '95px']
         ],
         "${_stage}": [
            ["color", "background-color", 'rgba(255,255,255,1.00)'],
            ["style", "width", '550px'],
            ["style", "height", '400px'],
            ["style", "overflow", 'hidden']
         ],
         "${_tbFadeToggle}": [
            ["style", "top", '241px'],
            ["style", "cursor", 'pointer'],
            ["style", "left", '365.07px'],
            ["style", "width", '95px']
         ],
         "${_Rectangle}": [
            ["color", "background-color", 'rgba(30,83,176,1.00)'],
            ["style", "border-top-left-radius", [22,22], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["subproperty", "boxShadow.blur", '3px'],
            ["style", "border-bottom-right-radius", [22,22], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["style", "opacity", '1'],
            ["style", "border-top-right-radius", [22,22], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["style", "top", '2px'],
            ["style", "border-bottom-left-radius", [22,22], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["subproperty", "boxShadow.spread", '4px'],
            ["style", "left", '0px'],
            ["subproperty", "boxShadow.inset", 'inset'],
            ["subproperty", "boxShadow.offsetV", '0px'],
            ["subproperty", "boxShadow.offsetH", '0px'],
            ["subproperty", "boxShadow.color", 'rgba(0,0,0,0.65)']
         ],
         "${_Text}": [
            ["subproperty", "textShadow.blur", '3px'],
            ["subproperty", "textShadow.offsetH", '3px'],
            ["subproperty", "textShadow.color", 'rgba(0,0,0,0.648438)'],
            ["color", "color", 'rgba(255,255,255,1.00)'],
            ["subproperty", "textShadow.offsetV", '3px'],
            ["style", "left", '56px'],
            ["style", "top", '0px']
         ],
         "${_tbHide}": [
            ["style", "left", '21px'],
            ["style", "cursor", 'pointer']
         ],
         "${_car}": [
            ["style", "top", '13.48px'],
            ["style", "left", '84px']
         ],
         "${_tbFadeIn}": [
            ["style", "top", '241px'],
            ["style", "left", '180px'],
            ["style", "cursor", 'pointer']
         ],
         "${_tbSlideUp}": [
            ["style", "top", '298.03px'],
            ["style", "left", '21px'],
            ["style", "cursor", 'pointer']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 0,
         autoPlay: true,
         timeline: [
         ]
      }
   }
}
};


Edge.registerCompositionDefn(compId, symbols, fonts, resources);

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     Edge.launchComposition(compId);
});
})(jQuery, AdobeEdge, "EDGE-53236650");
