/***********************
* Adobe Edge Composition Actions
*
* Edit this file with caution, being careful to preserve 
* function signatures and comments starting with 'Edge' to maintain the 
* ability to interact with these actions from within Adobe Edge
*
***********************/
(function($, Edge, compId){
var Composition = Edge.Composition, Symbol = Edge.Symbol; // aliases for commonly used Edge classes


//Edge symbol: 'stage'
(function(symbolName) {




      Symbol.bindElementAction(compId, symbolName, "${_tbHide}", "click", function(sym, e) {
         // Show an Element.
         //  (sym.$("name") resolves an Edge element name to a DOM
         //  element that can be used with jQuery)
         sym.$("car").hide(4000);
         

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_tbShow}", "click", function(sym, e) {
         // Show an Element.
         //  (sym.$("name") resolves an Edge element name to a DOM
         //  element that can be used with jQuery)
         sym.$("car").show(4000);
         

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_tbToggle}", "click", function(sym, e) {
         // Show an Element.
         //  (sym.$("name") resolves an Edge element name to a DOM
         //  element that can be used with jQuery)
         sym.$("car").toggle();
         

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_tbFadeToggle}", "click", function(sym, e) {
         // Show an Element.
         //  (sym.$("name") resolves an Edge element name to a DOM
         //  element that can be used with jQuery)
         sym.$("car").fadeToggle();
         

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_tbFadeOut}", "click", function(sym, e) {
         // Show an Element.
         //  (sym.$("name") resolves an Edge element name to a DOM
         //  element that can be used with jQuery)
         sym.$("car").fadeOut();
         

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_tbFadeIn}", "click", function(sym, e) {
         // Show an Element.
         //  (sym.$("name") resolves an Edge element name to a DOM
         //  element that can be used with jQuery)
         sym.$("car").fadeIn();
         

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_tbSlideToggle}", "click", function(sym, e) {
         // Show an Element.
         //  (sym.$("name") resolves an Edge element name to a DOM
         //  element that can be used with jQuery)
         sym.$("car").slideToggle();
         

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_tbSlideUp}", "click", function(sym, e) {
         // Show an Element.
         //  (sym.$("name") resolves an Edge element name to a DOM
         //  element that can be used with jQuery)
         sym.$("car").slideUp();
         

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_tbSlideDown}", "click", function(sym, e) {
         // Show an Element.
         //  (sym.$("name") resolves an Edge element name to a DOM
         //  element that can be used with jQuery)
         sym.$("car").slideDown();
         

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_Rectangle}", "click", function(sym, e) {
         sym.$("car").animate(
         {
         	opacity: .25,
         	width: 200
         },2000
         );
         sym.$("car").tbHide(
         {
         	fontSize: '12',
         	fontFamily: 'Times'
         },2000
         );

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_btnBar}", "click", function(sym, e) {
         sym.$("car").animate(
         {
         	opacity: .25,
         	width: 200
         },2000
         );
         sym.$("car").tbHide(
         {
         	fontSize: '12',
         	fontFamily: 'Times'
         },2000
         );

      });
      //Edge binding end

})("stage");
   //Edge symbol end:'stage'

})(jQuery, AdobeEdge, "EDGE-53236650");