/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
var im='images/';

var fonts = {};


var resources = [
];
var symbols = {
"stage": {
   version: "0.1.7",
   minimumCompatibleVersion: "0.1.7",
   build: "0.11.0.161",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
         dom: [
         {
            id:'Square',
            type:'rect',
            rect:['270px','99px','124px','124px','auto','auto'],
            fill:["rgba(31,88,25,1.00)"],
            stroke:[0,"rgba(0,0,0,1)","none"]
         },
         {
            id:'tbChangeSquare',
            type:'text',
            tag:'p',
            rect:['37px','147px','auto','auto','auto','auto'],
            text:"Change the square",
            font:['Arial, Helvetica, sans-serif',[24,""],"rgba(0,0,0,1)","normal","none",""]
         },
         {
            id:'tbValue',
            type:'text',
            rect:['90px','289px','335px','46px','auto','auto'],
            text:"Values",
            align:"left",
            font:['Arial, Helvetica, sans-serif',24,"rgba(0,0,0,1)","normal","none","normal"]
         }],
         symbolInstances: [

         ]
      },
   states: {
      "Base State": {
         "${_Stage}": [
            ["color", "background-color", 'rgba(255,255,255,1)'],
            ["style", "height", '400px'],
            ["style", "width", '550px']
         ],
         "${_tbChangeSquare}": [
            ["style", "left", '37.18px'],
            ["style", "top", '147px']
         ],
         "${_Square}": [
            ["color", "background-color", 'rgba(31,88,25,1.00)']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 0,
         autoPlay: true,
         timeline: [
         ]
      }
   }
}
};


Edge.registerCompositionDefn(compId, symbols, fonts, resources);

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     Edge.launchComposition(compId);
});
})(jQuery, AdobeEdge, "EDGE-13870545");
