/***********************
* Adobe Edge Composition Actions
*
* Edit this file with caution, being careful to preserve 
* function signatures and comments starting with 'Edge' to maintain the 
* ability to interact with these actions from within Adobe Edge
*
***********************/
(function($, Edge, compId){
var Composition = Edge.Composition, Symbol = Edge.Symbol; // aliases for commonly used Edge classes

//Edge symbol: 'stage'
(function(symbolName) {





      Symbol.bindElementAction(compId, symbolName, "${_sm_farmhouse}", "mouseover", function(sym, e) {
         // Hide an Element.
         //  (sym.$("name") resolves an Edge element name to a DOM
         //  element that can be used with jQuery)
         sym.$("mainPhoto").attr('src','images/farmhouse.jpg');
         sym.$("sm_farmhouse").css('cursor','pointer');

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_sm_squirrel}", "mouseover", function(sym, e) {
         // Hide an Element.
         //  (sym.$("name") resolves an Edge element name to a DOM
         //  element that can be used with jQuery)
         sym.$("mainPhoto").attr('src','images/squirrel.jpg');
         sym.$("sm_farmhouse").css('cursor','pointer');

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_sm_flowers}", "mouseover", function(sym, e) {
         // Hide an Element.
         //  (sym.$("name") resolves an Edge element name to a DOM
         //  element that can be used with jQuery)
         sym.$("mainPhoto").attr('src','images/flowers.jpg');
         sym.$("sm_farmhouse").css('cursor','pointer');

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_sm_bike}", "mouseover", function(sym, e) {
         // Hide an Element.
         //  (sym.$("name") resolves an Edge element name to a DOM
         //  element that can be used with jQuery)
         sym.$("mainPhoto").attr('src','images/bike.jpg');
         sym.$("sm_farmhouse").css('cursor','pointer');

      });
      //Edge binding end

})("stage");
   //Edge symbol end:'stage'

})(jQuery, AdobeEdge, "EDGE-132400554");