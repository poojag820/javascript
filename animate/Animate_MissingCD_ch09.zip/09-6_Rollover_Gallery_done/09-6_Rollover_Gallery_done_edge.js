/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
var im='images/';

var fonts = {};


var resources = [
];
var symbols = {
"stage": {
   version: "0.1.7",
   minimumCompatibleVersion: "0.1.7",
   build: "0.11.0.161",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: true,
   resizeInstances: false,
   content: {
         dom: [
         {
            id:'mainPhoto',
            type:'image',
            tag:'img',
            rect:['0','0','560','373','undefined','undefined'],
            fill:["rgba(0,0,0,0)",im+"bike.jpg"]
         },
         {
            id:'sm_bike',
            type:'image',
            rect:['0','0','125','83','undefined','undefined'],
            fill:["rgba(0,0,0,0)",im+"sm_bike.jpg"]
         },
         {
            id:'sm_farmhouse',
            type:'image',
            rect:['0','0','125','83','undefined','undefined'],
            fill:["rgba(0,0,0,0)",im+"sm_farmhouse.jpg"]
         },
         {
            id:'sm_flowers',
            type:'image',
            rect:['0','0','125','83','undefined','undefined'],
            fill:["rgba(0,0,0,0)",im+"sm_flowers.jpg"]
         },
         {
            id:'sm_squirrel',
            type:'image',
            rect:['0','0','125','83','undefined','undefined'],
            fill:["rgba(0,0,0,0)",im+"sm_squirrel.jpg"]
         }],
         symbolInstances: [

         ]
      },
   states: {
      "Base State": {
         "${_sm_flowers}": [
            ["style", "left", '455px'],
            ["style", "top", '418px']
         ],
         "${_mainPhoto}": [
            ["style", "left", '20px'],
            ["style", "top", '21px']
         ],
         "${_sm_farmhouse}": [
            ["style", "left", '165px'],
            ["style", "top", '418px']
         ],
         "${_sm_squirrel}": [
            ["style", "left", '310px'],
            ["style", "top", '418px']
         ],
         "${_stage}": [
            ["style", "height", '524px'],
            ["style", "width", '600px'],
            ["style", "overflow", 'hidden']
         ],
         "${_sm_bike}": [
            ["style", "left", '20px'],
            ["style", "top", '418px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 0,
         autoPlay: true,
         timeline: [
         ]
      }
   }
}
};


Edge.registerCompositionDefn(compId, symbols, fonts, resources);

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     Edge.launchComposition(compId);
});
})(jQuery, AdobeEdge, "EDGE-132400554");
