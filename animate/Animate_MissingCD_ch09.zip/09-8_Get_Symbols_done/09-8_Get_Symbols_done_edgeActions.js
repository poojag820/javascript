/***********************
* Adobe Edge Composition Actions
*
* Edit this file with caution, being careful to preserve 
* function signatures and comments starting with 'Edge' to maintain the 
* ability to interact with these actions from within Adobe Edge
*
***********************/
(function($, Edge, compId){
var Composition = Edge.Composition, Symbol = Edge.Symbol; // aliases for commonly used Edge classes


//Edge symbol: 'stage'
(function(symbolName) {

Symbol.bindElementAction(compId, symbolName, "${_tbChangeOne}", "click", function(sym, e) {
// Lookup the Edge Symbol Javascript Object from an element that is
// an instance of a symbol. The symbol object can be used to invoke
// symbol functions like play, stop etc.
var boxOne = sym.getSymbol("BoxInstanceOne");
boxOne.$("Square").css("backgroundColor","green");
boxOne.$("Circle").css("backgroundColor","yellow");
boxOne.$("Words").html("Instance One");
});
//Edge binding end


Symbol.bindElementAction(compId, symbolName, "${_tbChangeTwo}", "click", function(sym, e) {
var boxTwo = sym.getSymbol("BoxInstanceTwo");
boxTwo.$("Square").css("backgroundColor","purple");
boxTwo.$("Circle").css("backgroundColor","pink");
boxTwo.$("Words").html("Instance Two");
});
//Edge binding end



})("stage");
   //Edge symbol end:'stage'

//=========================================================

//Edge symbol: 'BoxSymbol'
(function(symbolName) {



})("BoxSymbol");
   //Edge symbol end:'BoxSymbol'

})(jQuery, AdobeEdge, "EDGE-156586467");