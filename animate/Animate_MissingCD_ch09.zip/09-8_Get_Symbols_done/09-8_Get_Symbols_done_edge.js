/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
var im='images/';

var fonts = {};


var resources = [
];
var symbols = {
"stage": {
   version: "0.1.7",
   minimumCompatibleVersion: "0.1.7",
   build: "0.11.0.161",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: true,
   resizeInstances: false,
   content: {
         dom: [
         {
            id:'BoxInstanceOne',
            type:'rect',
            rect:['162','89','0','0','undefined','undefined']
         },
         {
            id:'BoxInstanceTwo',
            type:'rect',
            rect:['270','262','0','0','undefined','undefined']
         },
         {
            id:'tbChangeOne',
            type:'text',
            rect:['24','72','236','34','undefined','undefined'],
            text:"Change instance 1",
            align:"auto",
            font:['Verdana, Geneva, sans-serif',24,"rgba(0,0,0,1)","normal","none","normal"],
            transform:[]
         },
         {
            id:'tbChangeTwo',
            type:'text',
            rect:['24','270','236','34','undefined','undefined'],
            text:"Change instance 2",
            align:"auto",
            font:['Verdana, Geneva, sans-serif',24,"rgba(0,0,0,1)","normal","none","normal"]
         }],
         symbolInstances: [
         {
            id:'BoxInstanceTwo',
            symbolName:'BoxSymbol'
         },
         {
            id:'BoxInstanceOne',
            symbolName:'BoxSymbol'
         }
         ]
      },
   states: {
      "Base State": {
         "${_BoxInstanceTwo}": [
            ["style", "top", '224px'],
            ["style", "left", '285px']
         ],
         "${_tbChangeOne}": [
            ["style", "top", '72px'],
            ["style", "cursor", 'pointer'],
            ["style", "height", '34px'],
            ["style", "font-family", 'Verdana, Geneva, sans-serif'],
            ["style", "left", '24px'],
            ["style", "width", '236px']
         ],
         "${_Stage}": [
            ["style", "height", '400px'],
            ["style", "width", '550px']
         ],
         "${_BoxInstanceOne}": [
            ["style", "left", '285px'],
            ["style", "top", '29px']
         ],
         "${_tbChangeTwo}": [
            ["style", "cursor", 'pointer']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 0,
         autoPlay: true,
         timeline: [
            { id: "eid4", tween: [ "style", "${_BoxInstanceTwo}", "top", '224px', { fromValue: '224px'}], position: 0, duration: 0 },
            { id: "eid3", tween: [ "style", "${_BoxInstanceTwo}", "left", '285px', { fromValue: '285px'}], position: 0, duration: 0 },
            { id: "eid8", tween: [ "style", "${_BoxInstanceOne}", "top", '29px', { fromValue: '29px'}], position: 0, duration: 0 },
            { id: "eid7", tween: [ "style", "${_BoxInstanceOne}", "left", '285px', { fromValue: '285px'}], position: 0, duration: 0 }         ]
      }
   }
},
"BoxSymbol": {
   version: "0.1.7",
   minimumCompatibleVersion: "0.1.7",
   build: "0.11.0.161",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: true,
   resizeInstances: false,
   content: {
   dom: [
   {
      transform: {},
      rect: ['0','0','242','153','undefined','undefined'],
      id: 'Frame',
      stroke: [4,'rgb(0, 0, 0)','solid'],
      type: 'rect',
      fill: ['rgba(0,0,255,0.00)']
   },
   {
      transform: {},
      rect: ['12','15','75','75','undefined','undefined'],
      id: 'Square',
      stroke: [0,'rgba(0,0,0,1)','none'],
      type: 'rect',
      fill: ['rgba(0,0,255,1)']
   },
   {
      transform: {},
      type: 'text',
      id: 'Words',
      text: 'My Word',
      font: ['Arial Black, Gadget, sans-serif',24,'rgba(0,0,0,1)','normal','none',''],
      rect: ['12','113','211','50','undefined','undefined']
   },
   {
      transform: {},
      borderRadius: ['117px 117px','117px 117px','117px 117px','117px 117px'],
      rect: ['148','15','75','75','undefined','undefined'],
      id: 'Circle',
      stroke: [0,'rgb(0, 0, 0)','none'],
      type: 'rect',
      fill: ['rgba(255,0,0,1.00)']
   }],
   symbolInstances: [
   ]
   },
   states: {
      "Base State": {
         "${_Square}": [
            ["color", "background-color", 'rgba(0,0,255,1.00)'],
            ["style", "left", '12px'],
            ["style", "top", '15px']
         ],
         "${_Frame}": [
            ["color", "background-color", 'rgba(0,0,255,0.00)'],
            ["style", "left", '0px'],
            ["style", "border-style", 'solid'],
            ["style", "border-width", '4px'],
            ["style", "width", '242px']
         ],
         "${_Circle}": [
            ["style", "top", '15px'],
            ["style", "border-top-left-radius", [117,117], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["style", "border-bottom-right-radius", [117,117], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["style", "border-bottom-left-radius", [117,117], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["style", "border-top-right-radius", [117,117], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["style", "left", '148px'],
            ["color", "background-color", 'rgba(255,0,0,1.00)']
         ],
         "${symbolSelector}": [
            ["style", "height", '166.66666666667px'],
            ["style", "width", '250px'],
            ["style", "overflow", 'hidden']
         ],
         "${_Words}": [
            ["style", "top", '113px'],
            ["style", "left", '12px'],
            ["style", "width", '211px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 0,
         autoPlay: false,
         timeline: [
         ]
      }
   }
}
};


Edge.registerCompositionDefn(compId, symbols, fonts, resources);

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     Edge.launchComposition(compId);
});
})(jQuery, AdobeEdge, "EDGE-156586467");
