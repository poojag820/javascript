/***********************
* Adobe Edge Composition Actions
*
* Edit this file with caution, being careful to preserve 
* function signatures and comments starting with 'Edge' to maintain the 
* ability to interact with these actions from within Adobe Edge
*
***********************/
(function($, Edge, compId){
var Composition = Edge.Composition, Symbol = Edge.Symbol; // aliases for commonly used Edge classes

   //Edge symbol: 'stage'
   (function(symbolName) {
      
      
      Symbol.bindElementAction(compId, symbolName, "${_hsPoppy}", "mouseout", function(sym, e) {
         sym.$("coPoppy").hide();

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_hsPoppy}", "mouseover", function(sym, e) {
         sym.$("coPoppy").show();

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_flowerStrip}", "click", function(sym, e) {
         // Find the position of the left side of the film strip
         // Store the value in the variable named posLeft
         var posLeft = sym.$("flowerStrip").position().left;
         
         // Use the variable posLeft (the position of the left side of the filmstrip
         // to determine which of the 5 images is displayed. Then move to the next image,
         // hide the callouts and hotspots from the previous image and show the hotspots 
         // for the current image.
         //
         switch(posLeft) {
         	case 0: 
         	// If the user clicks when posLeft is 0 (the first image) it's time to move
         	// to the 2nd image. So, do do setup for the 2nd image
         	//
         	// Hide hotspots and callouts for 1st filmstrip image
         	sym.$("hsPoppy").hide();
         	sym.$("coPoppy").hide();
         	// Show hotspots for 2nd filmstrip image
         	sym.$("hsRose").show();
         	// Move to the 2nd image
         	sym.$("flowerStrip").animate({left: "-500px"}, "slow");	
         	break;
         	
         	case -500:
         	// If the user clicks when posLeft is -500 (the 2nd image) it's time to move
         	// to the 3rd image. So, do do setup for the 3rd image
         	//
         	// Hide hotspots and callouts for 2nd filmstrip image
         	sym.$("hsRose").hide();
         	sym.$("coRose").hide();
         	// Show hotspots for 3rd filmstrip image
         	sym.$("hsDaisy").show();
         	// Move to the 3rd image
         	sym.$("flowerStrip").animate({left: "-1000px"}, "slow");	
         	break;
         	
         	case -1000:
         	// If the user clicks when posLeft is -1000 (the 3rd image) it's time to move
         	// to the 4th image. So, do do setup for the 4th image
         	//
         	// Hide hotspots and callouts for 3rdth filmstrip image
         	sym.$("hsDaisy").hide();
         	sym.$("coDaisy").hide();
         	// Show hotspots for 4th filmstrip image
         	sym.$("hsHydrangea").show();
         	// Move to the 4th image
         	sym.$("flowerStrip").animate({left: "-1500px"}, "slow");
         	break;
         	
         	case -1500:
         	// If the user clicks when posLeft is -1500 (the 4th image) it's time to move
         	// to the 5th image. So, do do setup for the 5th image
         	//
         	// Hide hotspots and callouts for 4th filmstrip image
         	sym.$("hsHydrangea").hide();
         	sym.$("coHydrangea").hide();
         	// Show hotspots for 5th filmstrip image
         	sym.$("hsTigerLily").show();
         	// Move to the 5th image
         	sym.$("flowerStrip").animate({left: "-2000px"}, "slow");
         	break;
         	
         	case -2000:
         	// If the user clicks when posLeft is -2000 (the 5th image) it's time to move
         	// back to the 1st image. So, do do setup for the 1st image
         	//
         	// Hide hotspots and callouts for 5th filmstrip image
         	sym.$("hsTigerLily").hide();
         	sym.$("coTigerLily").hide();
         	// Show hotspots for 5th filmstrip image
         	sym.$("hsPoppy").show();
         	// Last image in filmstrip so...
         	// Move the filmstrip back to the 1st image
         	sym.$("flowerStrip").animate({left: "0px"}, "slow");
         	break;	
         }
         

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_hsDaisy}", "mouseover", function(sym, e) {
         sym.$("coDaisy").show();
         

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_hsDaisy}", "mouseout", function(sym, e) {
         sym.$("coDaisy").hide();

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_hsHydrangea}", "mouseover", function(sym, e) {
         sym.$("coHydrangea").show();

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_hsHydrangea}", "mouseout", function(sym, e) {
         sym.$("coHydrangea").hide();

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_hsTigerLily}", "mouseover", function(sym, e) {
         sym.$("coTigerLily").show();

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_hsTigerLily}", "mouseout", function(sym, e) {
         sym.$("coTigerLily").hide();

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_hsRose}", "mouseover", function(sym, e) {
         sym.$("coRose").show();

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_hsRose}", "mouseout", function(sym, e) {
         sym.$("coRose").hide();

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "document", "compositionReady", function(sym, e) {
         $("#Stage").css("margin","auto");

      });
      //Edge binding end

   })("stage");
   //Edge symbol end:'stage'

   //=========================================================
   
   //Edge symbol: 'flowerStrip'
   (function(symbolName) {   
   
   })("flowerStrip");
   //Edge symbol end:'flowerStrip'

   //=========================================================
   
   //Edge symbol: 'coPoppy'
   (function(symbolName) {   
   
   })("coPoppy");
   //Edge symbol end:'coPoppy'

   //=========================================================
   
   //Edge symbol: 'hsPoppy'
   (function(symbolName) {   
   
      Symbol.bindElementAction(compId, symbolName, "${_hsPoppy}", "click", function(sym, e) {
         sym.$("coPoppy").show();
         

      });
      //Edge binding end

   })("hotSpot");
   //Edge symbol end:'hotSpot'

   //=========================================================
   
   //Edge symbol: 'coRose'
   (function(symbolName) {   
   
   })("coRose");
   //Edge symbol end:'coRose'

   //=========================================================
   
   //Edge symbol: 'coDaisy'
   (function(symbolName) {   
   
   })("coDaisy");
   //Edge symbol end:'coDaisy'

   //=========================================================
   
   //Edge symbol: 'coHydrangea'
   (function(symbolName) {   
   
   })("coHydrangea");
   //Edge symbol end:'coHydrangea'

   //=========================================================
   
   //Edge symbol: 'coTigerLily'
   (function(symbolName) {   
   
   })("coTigerLily");
   //Edge symbol end:'coTigerLily'

})(jQuery, AdobeEdge, "EDGE-86797179");