/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
var im='images/';

var fonts = {};


var resources = [
];
var symbols = {
"stage": {
   version: "0.1.7",
   minimumCompatibleVersion: "0.1.7",
   build: "0.11.0.161",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
         dom: [
         {
            id:'flowerStrip',
            type:'rect',
            rect:['0','0','0','0','undefined','undefined']
         },
         {
            id:'coTigerLily',
            display:'none',
            type:'rect',
            rect:['180','23','0','0','undefined','undefined']
         },
         {
            id:'hsTigerLily',
            display:'none',
            type:'rect',
            rect:['65','154','0','0','undefined','undefined']
         },
         {
            id:'coHydrangea',
            display:'none',
            type:'rect',
            rect:['92','113','0','0','undefined','undefined']
         },
         {
            id:'hsHydrangea',
            display:'none',
            type:'rect',
            rect:['94','62','0','0','undefined','undefined']
         },
         {
            id:'coDaisy',
            display:'none',
            type:'rect',
            rect:['365','45','0','0','undefined','undefined']
         },
         {
            id:'hsDaisy',
            display:'none',
            type:'rect',
            rect:['122','158','0','0','undefined','undefined']
         },
         {
            id:'coRose',
            display:'none',
            type:'rect',
            rect:['150','23','0','0','undefined','undefined']
         },
         {
            id:'hsRose',
            display:'none',
            type:'rect',
            rect:['168','119','0','0','undefined','undefined']
         },
         {
            id:'coPoppy',
            display:'none',
            type:'rect',
            rect:['226','73','0','0','undefined','undefined']
         },
         {
            id:'hsPoppy',
            type:'rect',
            rect:['130','119','0','0','undefined','undefined']
         }],
         symbolInstances: [
         {
            id:'coPoppy',
            symbolName:'coPoppy'
         },
         {
            id:'hsRose',
            symbolName:'hotSpot'
         },
         {
            id:'hsDaisy',
            symbolName:'hotSpot'
         },
         {
            id:'hsHydrangea',
            symbolName:'hotSpot'
         },
         {
            id:'hsPoppy',
            symbolName:'hotSpot'
         },
         {
            id:'coDaisy',
            symbolName:'coDaisy'
         },
         {
            id:'coRose',
            symbolName:'coRose'
         },
         {
            id:'flowerStrip',
            symbolName:'flowerStrip'
         },
         {
            id:'coHydrangea',
            symbolName:'coHydrangea'
         },
         {
            id:'hsTigerLily',
            symbolName:'hotSpot'
         },
         {
            id:'coTigerLily',
            symbolName:'coTigerLily'
         }
         ]
      },
   states: {
      "Base State": {
         "${_coHydrangea}": [
            ["style", "top", '268px'],
            ["style", "left", '298px'],
            ["style", "display", 'none']
         ],
         "${_hsPoppy}": [
            ["style", "display", 'block']
         ],
         "${_coPoppy}": [
            ["style", "display", 'none']
         ],
         "${_flowerStrip}": [
            ["style", "left", '0px'],
            ["style", "top", '0px']
         ],
         "${_hsHydrangea}": [
            ["style", "top", '80.74px'],
            ["transform", "scaleY", '2.29978'],
            ["style", "display", 'none'],
            ["style", "left", '150.99px'],
            ["transform", "scaleX", '3.7354']
         ],
         "${_hsRose}": [
            ["style", "top", '167.25px'],
            ["transform", "scaleY", '1.96511'],
            ["style", "display", 'none'],
            ["style", "left", '207.94px'],
            ["transform", "scaleX", '2.05128']
         ],
         "${_hsDaisy}": [
            ["style", "top", '132.03px'],
            ["transform", "scaleY", '2.74054'],
            ["style", "display", 'none'],
            ["style", "left", '198.64px'],
            ["transform", "scaleX", '3.14848']
         ],
         "${_coDaisy}": [
            ["style", "display", 'none']
         ],
         "${_Stage}": [
            ["color", "background-color", 'rgba(255,255,255,1)'],
            ["style", "overflow", 'hidden'],
            ["style", "height", '375px'],
            ["style", "width", '500px']
         ],
         "${_coRose}": [
            ["style", "display", 'none']
         ],
         "${_coTigerLily}": [
            ["style", "display", 'none']
         ],
         "${_hsTigerLily}": [
            ["style", "top", '145.01px'],
            ["transform", "scaleY", '1.62015'],
            ["style", "display", 'none'],
            ["style", "left", '235.89px'],
            ["transform", "scaleX", '4.8129']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 0,
         autoPlay: true,
         timeline: [
            { id: "eid34", tween: [ "style", "${_hsDaisy}", "top", '132.03px', { fromValue: '132.03px'}], position: 0, duration: 0 },
            { id: "eid33", tween: [ "style", "${_hsDaisy}", "left", '198.64px', { fromValue: '198.64px'}], position: 0, duration: 0 },
            { id: "eid60", tween: [ "style", "${_hsTigerLily}", "top", '145.01px', { fromValue: '145.01px'}], position: 0, duration: 0 },
            { id: "eid76", tween: [ "style", "${_flowerStrip}", "top", '0px', { fromValue: '0px'}], position: 0, duration: 0 },
            { id: "eid37", tween: [ "style", "${_coDaisy}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid36", tween: [ "transform", "${_hsDaisy}", "scaleY", '2.74054', { fromValue: '2.74054'}], position: 0, duration: 0 },
            { id: "eid50", tween: [ "transform", "${_hsHydrangea}", "scaleX", '3.7354', { fromValue: '3.7354'}], position: 0, duration: 0 },
            { id: "eid70", tween: [ "transform", "${_hsRose}", "scaleX", '2.05128', { fromValue: '2.05128'}], position: 0, duration: 0 },
            { id: "eid71", tween: [ "transform", "${_hsRose}", "scaleY", '1.96511', { fromValue: '1.96511'}], position: 0, duration: 0 },
            { id: "eid69", tween: [ "style", "${_hsRose}", "top", '167.25px', { fromValue: '167.25px'}], position: 0, duration: 0 },
            { id: "eid35", tween: [ "transform", "${_hsDaisy}", "scaleX", '3.14848', { fromValue: '3.14848'}], position: 0, duration: 0 },
            { id: "eid61", tween: [ "transform", "${_hsTigerLily}", "scaleX", '4.8129', { fromValue: '4.8129'}], position: 0, duration: 0 },
            { id: "eid40", tween: [ "style", "${_coHydrangea}", "left", '298px', { fromValue: '298px'}], position: 0, duration: 0 },
            { id: "eid65", tween: [ "style", "${_hsTigerLily}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid1", tween: [ "style", "${_coPoppy}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid66", tween: [ "style", "${_hsPoppy}", "display", 'block', { fromValue: 'block'}], position: 0, duration: 0 },
            { id: "eid53", tween: [ "style", "${_coHydrangea}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid49", tween: [ "style", "${_hsHydrangea}", "top", '80.74px', { fromValue: '80.74px'}], position: 0, duration: 0 },
            { id: "eid18", tween: [ "style", "${_coRose}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid38", tween: [ "style", "${_hsDaisy}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid59", tween: [ "style", "${_hsTigerLily}", "left", '235.89px', { fromValue: '235.89px'}], position: 0, duration: 0 },
            { id: "eid51", tween: [ "transform", "${_hsHydrangea}", "scaleY", '2.29978', { fromValue: '2.29978'}], position: 0, duration: 0 },
            { id: "eid48", tween: [ "style", "${_hsHydrangea}", "left", '150.99px', { fromValue: '150.99px'}], position: 0, duration: 0 },
            { id: "eid52", tween: [ "style", "${_hsHydrangea}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid68", tween: [ "style", "${_hsRose}", "left", '207.94px', { fromValue: '207.94px'}], position: 0, duration: 0 },
            { id: "eid41", tween: [ "style", "${_coHydrangea}", "top", '268px', { fromValue: '268px'}], position: 0, duration: 0 },
            { id: "eid62", tween: [ "transform", "${_hsTigerLily}", "scaleY", '1.62015', { fromValue: '1.62015'}], position: 0, duration: 0 },
            { id: "eid64", tween: [ "style", "${_coTigerLily}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid74", tween: [ "style", "${_flowerStrip}", "left", '0px', { fromValue: '0px'}], position: 0, duration: 0 },
            { id: "eid73", tween: [ "style", "${_hsRose}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 }         ]
      }
   }
},
"flowerStrip": {
   version: "0.1.7",
   minimumCompatibleVersion: "0.1.7",
   build: "0.11.0.161",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
   dom: [
   {
      transform: [[0,0]],
      type: 'image',
      id: 'flowerStrip',
      rect: ['0','0','2500','375'],
      cursor: ['pointer'],
      fill: ['rgba(0,0,0,0)','images/flowerStrip375x2500.jpg']
   }],
   symbolInstances: [
   ]
   },
   states: {
      "Base State": {
         "${_flowerStrip}": [
            ["style", "cursor", 'pointer'],
            ["style", "left", '0px']
         ],
         "${symbolSelector}": [
            ["style", "height", '375px'],
            ["style", "width", '2500px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 0,
         autoPlay: true,
         timeline: [
         ]
      }
   }
},
"coPoppy": {
   version: "0.1.7",
   minimumCompatibleVersion: "0.1.7",
   build: "0.11.0.161",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
   dom: [
   {
      rect: ['0','0','121','98','undefined','undefined'],
      borderRadius: ['20px 20px','20px 20px','20px 20px','20px 20px'],
      stroke: [0,'rgb(0, 0, 0)','none'],
      id: 'rectPoppy',
      opacity: 0.5,
      type: 'rect',
      fill: ['rgba(255,255,255,1)']
   },
   {
      transform: [{},{},{},['0.93','0.93']],
      rect: ['13','13','89','59','undefined','undefined'],
      align: 'auto',
      font: ['\'Arial Black\', Gadget, sans-serif',24,'rgba(255,255,255,1.00)','normal','none','normal'],
      id: 'tbIcelandPoppy',
      text: 'Iceland Poppy',
      textShadow: ['rgba(0,0,0,1.00)',4,4,6],
      type: 'text'
   }],
   symbolInstances: [
   ]
   },
   states: {
      "Base State": {
         "${_tbIcelandPoppy}": [
            ["subproperty", "textShadow.blur", '6px'],
            ["subproperty", "textShadow.offsetH", '4px'],
            ["transform", "scaleY", '0.93'],
            ["color", "color", 'rgba(255,255,255,1.00)'],
            ["subproperty", "textShadow.color", 'rgba(0,0,0,1.00)'],
            ["transform", "scaleX", '0.93'],
            ["subproperty", "textShadow.offsetV", '4px']
         ],
         "${symbolSelector}": [
            ["style", "height", '98px'],
            ["style", "overflow", 'hidden'],
            ["style", "width", '121px']
         ],
         "${_rectPoppy}": [
            ["style", "border-bottom-left-radius", [20,20], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["style", "border-bottom-right-radius", [20,20], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["style", "opacity", '0.5'],
            ["style", "border-top-right-radius", [20,20], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["style", "border-top-left-radius", [20,20], {valueTemplate:'@@0@@px @@1@@px'} ]
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 0,
         autoPlay: true,
         timeline: [
         ]
      }
   }
},
"hotSpot": {
   version: "0.1.7",
   minimumCompatibleVersion: "0.1.7",
   build: "0.11.0.161",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
   dom: [
   {
      type: 'rect',
      rect: ['0','0','76','100'],
      borderRadius: ['10px','10px','10px','10px'],
      stroke: [0,'rgba(0,0,0,1)','none'],
      id: 'hsPoppy',
      opacity: 0,
      cursor: ['help'],
      fill: ['rgba(255,255,255,1.00)']
   }],
   symbolInstances: [
   ]
   },
   states: {
      "Base State": {
         "${_hsPoppy}": [
            ["color", "background-color", 'rgba(255,255,255,1)'],
            ["style", "opacity", '0'],
            ["style", "cursor", 'help']
         ],
         "${symbolSelector}": [
            ["style", "height", '100px'],
            ["style", "width", '76px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 0,
         autoPlay: true,
         timeline: [
         ]
      }
   }
},
"coRose": {
   version: "0.1.7",
   minimumCompatibleVersion: "0.1.7",
   build: "0.11.0.161",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
   dom: [
   {
      rect: ['0','0','184','60','undefined','undefined'],
      borderRadius: ['20px 20px','20px 20px','20px 20px','20px 20px'],
      stroke: [0,'rgb(0, 0, 0)','none'],
      id: 'rectRose',
      opacity: 0.46470588235294,
      type: 'rect',
      fill: ['rgba(255,255,255,1)']
   },
   {
      transform: {},
      rect: ['21','13','0','0','undefined','undefined'],
      align: 'auto',
      font: ['\'Arial Black\', Gadget, sans-serif',24,'rgba(255,255,255,1.00)','normal','none','normal'],
      id: 'Text2',
      text: 'A Red Rose',
      textShadow: ['rgba(0,0,0,1.00)',4,4,6],
      type: 'text'
   }],
   symbolInstances: [
   ]
   },
   states: {
      "Base State": {
         "${symbolSelector}": [
            ["style", "height", '60px'],
            ["style", "overflow", 'hidden'],
            ["style", "width", '184px']
         ],
         "${_Text2}": [
            ["subproperty", "textShadow.blur", '6px'],
            ["subproperty", "textShadow.offsetH", '4px'],
            ["style", "top", '13px'],
            ["color", "color", 'rgba(255,255,255,1.00)'],
            ["subproperty", "textShadow.offsetV", '4px'],
            ["style", "left", '21px'],
            ["subproperty", "textShadow.color", 'rgba(0,0,0,1.00)']
         ],
         "${_rectRose}": [
            ["style", "opacity", '0.46470588235294']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 0,
         autoPlay: true,
         timeline: [
         ]
      }
   }
},
"coDaisy": {
   version: "0.1.7",
   minimumCompatibleVersion: "0.1.7",
   build: "0.11.0.161",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
   dom: [
   {
      rect: ['0px','0px','126','64','undefined','undefined'],
      borderRadius: ['20px 20px','20px 20px','20px 20px','20px 20px'],
      stroke: [0,'rgb(0, 0, 0)','none'],
      id: 'rectDaisy',
      opacity: 0.50013786764706,
      type: 'rect',
      fill: ['rgba(255,255,255,1)']
   },
   {
      transform: {},
      rect: ['11','11','0','0','undefined','undefined'],
      align: 'auto',
      font: ['\'Arial Black\', Gadget, sans-serif',24,'rgba(255,255,255,1)','normal','none','normal'],
      id: 'txtDaisy',
      text: 'A Daisy',
      textShadow: ['rgba(0,0,0,1.00)',4,4,6],
      type: 'text'
   }],
   symbolInstances: [
   ]
   },
   states: {
      "Base State": {
         "${symbolSelector}": [
            ["style", "height", '64px'],
            ["style", "overflow", 'hidden'],
            ["style", "width", '126px']
         ],
         "${_txtDaisy}": [
            ["subproperty", "textShadow.blur", '6px'],
            ["subproperty", "textShadow.offsetH", '4px'],
            ["style", "top", '11px'],
            ["subproperty", "textShadow.color", 'rgba(0,0,0,1.00)'],
            ["style", "left", '11px'],
            ["subproperty", "textShadow.offsetV", '4px']
         ],
         "${_rectDaisy}": [
            ["style", "top", '0px'],
            ["style", "opacity", '0.50013786764706'],
            ["style", "left", '0px'],
            ["style", "overflow", 'hidden']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 0,
         autoPlay: true,
         timeline: [
         ]
      }
   }
},
"coHydrangea": {
   version: "0.1.7",
   minimumCompatibleVersion: "0.1.7",
   build: "0.11.0.161",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
   dom: [
   {
      transform: {},
      rect: ['0','0','188px','86px','undefined','undefined'],
      borderRadius: ['20px 20px','20px 20px','20px 20px','20px 20px'],
      stroke: [0,'rgb(0, 0, 0)','none'],
      id: 'rectHydrangea',
      opacity: 0.5,
      type: 'rect',
      fill: ['rgba(255,255,255,1)']
   },
   {
      rect: ['21','5','0','0','undefined','undefined'],
      align: 'auto',
      font: ['\'Arial Black\', Gadget, sans-serif',24,'rgba(255,255,255,1)','normal','none','normal'],
      id: 'Text4',
      text: 'A Beautiful<br>Hydrangea',
      textShadow: ['rgba(0,0,0,1.00)',4,4,6],
      type: 'text'
   }],
   symbolInstances: [
   ]
   },
   states: {
      "Base State": {
         "${_rectHydrangea}": [
            ["style", "top", '0px'],
            ["style", "height", '86px'],
            ["style", "opacity", '0.5'],
            ["style", "left", '0px'],
            ["style", "width", '188.5234375px']
         ],
         "${symbolSelector}": [
            ["style", "height", '86px'],
            ["style", "overflow", 'hidden'],
            ["style", "width", '188px']
         ],
         "${_Text4}": [
            ["subproperty", "textShadow.blur", '6px'],
            ["subproperty", "textShadow.color", 'rgba(0,0,0,1.00)'],
            ["subproperty", "textShadow.offsetH", '4px'],
            ["subproperty", "textShadow.offsetV", '4px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 0,
         autoPlay: true,
         timeline: [
         ]
      }
   }
},
"coTigerLily": {
   version: "0.1.7",
   minimumCompatibleVersion: "0.1.7",
   build: "0.11.0.161",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
   dom: [
   {
      rect: ['0','0','232','79','undefined','undefined'],
      borderRadius: ['20px 20px','20px 20px','20px 20px','20px 20px'],
      stroke: [0,'rgb(0, 0, 0)','none'],
      id: 'rectTigerLily',
      opacity: 0.62,
      type: 'rect',
      fill: ['rgba(255,255,255,1)']
   },
   {
      transform: {},
      rect: ['41','23','0','0','undefined','undefined'],
      align: 'auto',
      font: ['\'Arial Black\', Gadget, sans-serif',24,'rgba(255,255,255,1)','normal','none','normal'],
      id: 'txtTigerLily',
      text: 'A Tiger Lily',
      textShadow: ['rgba(0,0,0,1.00)',4,4,6],
      type: 'text'
   }],
   symbolInstances: [
   ]
   },
   states: {
      "Base State": {
         "${_rectTigerLily}": [
            ["style", "opacity", '0.62']
         ],
         "${symbolSelector}": [
            ["style", "height", '79px'],
            ["style", "overflow", 'hidden'],
            ["style", "width", '232px']
         ],
         "${_txtTigerLily}": [
            ["subproperty", "textShadow.blur", '6px'],
            ["subproperty", "textShadow.offsetH", '4px'],
            ["subproperty", "textShadow.color", 'rgba(0,0,0,1.00)'],
            ["style", "top", '23px'],
            ["subproperty", "textShadow.offsetV", '4px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 0,
         autoPlay: true,
         timeline: [
         ]
      }
   }
}
};


Edge.registerCompositionDefn(compId, symbols, fonts, resources);

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     Edge.launchComposition(compId);
});
})(jQuery, AdobeEdge, "EDGE-86797179");
