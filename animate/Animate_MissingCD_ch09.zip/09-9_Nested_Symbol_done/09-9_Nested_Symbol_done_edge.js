/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
var im='images/';

var fonts = {};


var resources = [
];
var symbols = {
"stage": {
   version: "0.1.7",
   minimumCompatibleVersion: "0.1.7",
   build: "0.11.0.161",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
         dom: [
         {
            id:'nestedStuff',
            type:'rect',
            rect:['231','81','0','0','undefined','undefined']
         },
         {
            id:'tbChange',
            type:'text',
            rect:['40','70','172px','63px','undefined','undefined'],
            cursor:['pointer'],
            text:"Change square in symbol<br>",
            align:"auto",
            font:['Arial, Helvetica, sans-serif',24,"rgba(0,0,0,1)","normal","none","normal"]
         }],
         symbolInstances: [
         {
            id:'nestedStuff',
            symbolName:'framedStuff'
         }
         ]
      },
   states: {
      "Base State": {
         "${_tbChange}": [
            ["style", "height", '63px'],
            ["style", "cursor", 'pointer'],
            ["style", "width", '172px']
         ],
         "${_Stage}": [
            ["style", "height", '400px'],
            ["color", "background-color", 'rgba(255,255,255,1)'],
            ["style", "width", '550px']
         ],
         "${_nestedStuff}": [
            ["style", "left", '290px'],
            ["style", "top", '31px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 0,
         autoPlay: true,
         timeline: [
            { id: "eid2", tween: [ "style", "${_nestedStuff}", "top", '31px', { fromValue: '31px'}], position: 0, duration: 0 },
            { id: "eid1", tween: [ "style", "${_nestedStuff}", "left", '290px', { fromValue: '290px'}], position: 0, duration: 0 }         ]
      }
   }
},
"framedStuff": {
   version: "0.1.7",
   minimumCompatibleVersion: "0.1.7",
   build: "0.11.0.161",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
   dom: [
   {
      type: 'rect',
      id: 'Frame',
      stroke: [9,'rgb(0, 0, 0)','solid'],
      rect: ['0','0','210','283'],
      fill: ['rgba(192,192,192,0.00)']
   },
   {
      type: 'rect',
      id: 'Square',
      stroke: [0,'rgba(0,0,0,1)','none'],
      rect: ['61','29','86','90'],
      fill: ['rgba(72,120,243,1.00)']
   },
   {
      rect: ['61','151','86','90'],
      borderRadius: ['92px 92px','92px 92px','92px 92px','92px 92px'],
      id: 'Circle',
      stroke: [0,'rgb(0, 0, 0)','none'],
      type: 'rect',
      fill: ['rgba(246,14,14,1.00)']
   }],
   symbolInstances: [
   ]
   },
   states: {
      "Base State": {
         "${_Square}": [
            ["color", "background-color", 'rgba(72,120,243,1.00)']
         ],
         "${_Circle}": [
            ["color", "background-color", 'rgba(246,14,14,1.00)'],
            ["style", "border-bottom-left-radius", [92,92], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["style", "border-bottom-right-radius", [92,92], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["style", "border-top-right-radius", [92,92], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["style", "border-top-left-radius", [92,92], {valueTemplate:'@@0@@px @@1@@px'} ]
         ],
         "${symbolSelector}": [
            ["style", "height", '301px'],
            ["style", "width", '228px']
         ],
         "${_Frame}": [
            ["color", "background-color", 'rgba(192,192,192,0.00)'],
            ["style", "border-style", 'solid'],
            ["style", "border-width", '9px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 0,
         autoPlay: true,
         timeline: [
         ]
      }
   }
}
};


Edge.registerCompositionDefn(compId, symbols, fonts, resources);

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     Edge.launchComposition(compId);
});
})(jQuery, AdobeEdge, "EDGE-110280144");
