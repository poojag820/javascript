/***********************
* Adobe Edge Composition Actions
*
* Edit this file with caution, being careful to preserve 
* function signatures and comments starting with 'Edge' to maintain the 
* ability to interact with these actions from within Adobe Edge
*
***********************/
(function($, Edge, compId){
var Composition = Edge.Composition, Symbol = Edge.Symbol; // aliases for commonly used Edge classes


//Edge symbol: 'stage'
(function(symbolName) {

Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 0, function(sym, e) {
// insert code here

});
//Edge binding end


Symbol.bindElementAction(compId, symbolName, "${_tbStop}", "click", function(sym, e) {
// Lookup the Edge Symbol Javascript Object from an element that is  
// an instance of a symbol. The symbol object can be used to invoke 
// symbol functions like play, stop etc.
var mySymbolObject = sym.getSymbol("myCounter");
mySymbolObject.stop();

});
//Edge binding end

Symbol.bindElementAction(compId, symbolName, "${_tbPlay}", "click", function(sym, e) {
// Lookup the Edge Symbol Javascript Object from an element that is  
// an instance of a symbol. The symbol object can be used to invoke 
// symbol functions like play, stop etc.
var mySymbolObject = sym.getSymbol("myCounter");
mySymbolObject.play();

});
//Edge binding end

Symbol.bindElementAction(compId, symbolName, "document", "compositionReady", function(sym, e) {
var timerValue = sym.getSymbol("myCounter").$("tbNumber").html();
sym.$("tbValue").html(timerValue);

});
//Edge binding end

Symbol.bindElementAction(compId, symbolName, "${_ForwardArrow}", "click", function(sym, e) {
// Lookup the Edge Symbol Javascript Object from an element that is  
// an instance of a symbol. The symbol object can be used to invoke 
// symbol functions like play, stop etc.
var theCounterSymbol = sym.getSymbol("myCounter");
var playPosition = theCounterSymbol.getPosition();
playPosition = playPosition + 2000;
if (playPosition < 10000) {
	theCounterSymbol.play(playPosition);
	}
	else {
	theCounterSymbol.play(0);
	}

});
//Edge binding end

Symbol.bindElementAction(compId, symbolName, "${_BackArrow}", "click", function(sym, e) {
// Lookup the Edge Symbol Javascript Object from an element that is  
// an instance of a symbol. The symbol object can be used to invoke 
// symbol functions like play, stop etc.
var theCounterSymbol = sym.getSymbol("myCounter");
var playPosition = theCounterSymbol.getPosition();
playPosition = playPosition - 2000;
if (playPosition > 0) {
	theCounterSymbol.play(playPosition);
	}
	else {
	theCounterSymbol.play(0);
	}

});
//Edge binding end



})("stage");
   //Edge symbol end:'stage'

//=========================================================

//Edge symbol: 'Counter'
(function(symbolName) {
Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 0, function(sym, e) {
sym.$("tbNumber").html("0")

});
//Edge binding end

Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 1000, function(sym, e) {
sym.$("tbNumber").html("1")

});
//Edge binding end

Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 2000, function(sym, e) {
sym.$("tbNumber").html("2")

});
//Edge binding end


Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 3000, function(sym, e) {
sym.$("tbNumber").html("3")

});
//Edge binding end

Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 4015, function(sym, e) {
sym.$("tbNumber").html("4")// insert code here

});
//Edge binding end

Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 5000, function(sym, e) {
sym.$("tbNumber").html("5")

});
//Edge binding end

Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 6000, function(sym, e) {
sym.$("tbNumber").html("6")

});
//Edge binding end

Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 7000, function(sym, e) {
sym.$("tbNumber").html("7")

});
//Edge binding end

Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 8000, function(sym, e) {
sym.$("tbNumber").html("8")

});
//Edge binding end

Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 9000, function(sym, e) {
sym.$("tbNumber").html("9")

});
//Edge binding end

Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 10000, function(sym, e) {
// play the timeline from the given position (ms or label)
sym.play(0);

});
//Edge binding end

Symbol.bindElementAction(compId, symbolName, "${_stopRed}", "click", function(sym, e) {
sym.stop();

});
//Edge binding end

Symbol.bindElementAction(compId, symbolName, "${_playGreen}", "click", function(sym, e) {
sym.play();

});
//Edge binding end



})("Counter");
   //Edge symbol end:'Counter'

})(jQuery, AdobeEdge, "EDGE-92925060");