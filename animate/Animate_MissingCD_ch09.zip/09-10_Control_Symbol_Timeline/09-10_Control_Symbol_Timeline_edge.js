/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
var im='images/';

var fonts = {};


var resources = [
];
var symbols = {
"stage": {
   version: "0.1.7",
   minimumCompatibleVersion: "0.1.7",
   build: "0.11.0.161",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: true,
   resizeInstances: false,
   content: {
         dom: [
         {
            id:'myCounter',
            type:'rect',
            rect:['109','60','0','0','undefined','undefined'],
            opacity:0.86986301369863,
            transform:[]
         },
         {
            id:'tbStop',
            type:'text',
            rect:['90','225','80','47','undefined','undefined'],
            cursor:['pointer'],
            text:"Stop",
            align:"auto",
            font:['Arial Black, Gadget, sans-serif',32,"rgba(0,0,0,1)","normal","none","normal"],
            transform:[]
         },
         {
            id:'tbPlay',
            type:'text',
            rect:['230','225','80','47','undefined','undefined'],
            cursor:['pointer'],
            text:"Play",
            align:"auto",
            font:['\'Arial Black\', Gadget, sans-serif',32,"rgba(0,0,0,1)","normal","none","normal"],
            transform:[]
         },
         {
            id:'ForwardArrow',
            type:'text',
            rect:['230','283','53','47','undefined','undefined'],
            cursor:['pointer'],
            text:"➡",
            align:"auto",
            font:['\'Arial Black\', Gadget, sans-serif',46,"rgba(0,0,0,1)","normal","none","normal"],
            transform:[]
         },
         {
            id:'BackArrow',
            type:'text',
            rect:['117','306','53','47','undefined','undefined'],
            cursor:['pointer'],
            text:"➡",
            align:"auto",
            font:['\'Arial Black\', Gadget, sans-serif',46,"rgba(0,0,0,1)","normal","none","normal"],
            transform:[[],['180']]
         }],
         symbolInstances: [
         {
            id:'myCounter',
            symbolName:'Counter'
         }
         ]
      },
   states: {
      "Base State": {
         "${_myCounter}": [
            ["style", "top", '60px'],
            ["style", "opacity", '0.86986301369863'],
            ["style", "left", '109px']
         ],
         "${_tbStop}": [
            ["style", "cursor", 'pointer'],
            ["style", "width", '80px'],
            ["style", "height", '47px'],
            ["style", "font-family", 'Arial Black, Gadget, sans-serif'],
            ["style", "left", '90px'],
            ["style", "font-size", '32px']
         ],
         "${_tbNumber}": [
            ["style", "height", '']
         ],
         "${_tbPlay}": [
            ["style", "top", '225px'],
            ["style", "cursor", 'pointer'],
            ["style", "left", '230px'],
            ["style", "width", '80px']
         ],
         "${_ForwardArrow}": [
            ["style", "top", '283px'],
            ["style", "cursor", 'pointer'],
            ["style", "width", '53px'],
            ["style", "left", '230px'],
            ["style", "font-size", '46px']
         ],
         "${_stage}": [
            ["style", "height", '400px'],
            ["color", "background-color", 'rgba(255,255,255,1.00)'],
            ["style", "width", '400px'],
            ["style", "overflow", 'hidden']
         ],
         "${_BackArrow}": [
            ["style", "top", '306px'],
            ["style", "cursor", 'pointer'],
            ["style", "left", '117px'],
            ["transform", "rotateZ", '180deg']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 0,
         autoPlay: true,
         timeline: [
         ]
      }
   }
},
"Counter": {
   version: "0.1.7",
   minimumCompatibleVersion: "0.1.7",
   build: "0.11.0.161",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: true,
   resizeInstances: false,
   content: {
   dom: [
   {
      rect: ['0','0','192px','122px','undefined','undefined'],
      transform: {},
      id: 'frame',
      stroke: [3,'rgb(0, 0, 0)','solid'],
      type: 'rect',
      fill: ['rgba(255,0,0,0.00)']
   },
   {
      rect: ['0','43','56','11','undefined','undefined'],
      id: 'leftDash',
      stroke: [0,'rgba(0,0,0,1)','none'],
      type: 'rect',
      fill: ['rgba(255,0,0,1.00)']
   },
   {
      rect: ['133','41','56','11','undefined','undefined'],
      transform: {},
      id: 'rightDash',
      stroke: [0,'rgba(0,0,0,1)','none'],
      type: 'rect',
      fill: ['rgba(255,0,0,1.00)']
   },
   {
      rect: ['74','-5','49','104','undefined','undefined'],
      transform: {},
      id: 'tbNumber',
      text: '0',
      font: ['Georgia, Times New Roman, Times, serif',76,'rgba(0,0,0,1)','normal','none',''],
      type: 'text'
   },
   {
      rect: ['29','82','35','27','undefined','undefined'],
      transform: {},
      type: 'rect',
      id: 'stopRed',
      stroke: [0,'rgb(0, 0, 0)','none'],
      cursor: ['pointer'],
      fill: ['rgba(255,0,0,1)']
   },
   {
      rect: ['133','82','35','27','undefined','undefined'],
      transform: {},
      type: 'rect',
      id: 'playGreen',
      stroke: [0,'rgb(0, 0, 0)','none'],
      cursor: ['pointer'],
      fill: ['rgba(0,255,0,1.00)']
   }],
   symbolInstances: [
   ]
   },
   states: {
      "Base State": {
         "${_leftDash}": [
            ["color", "background-color", 'rgba(255,0,0,1.00)'],
            ["style", "left", '8px'],
            ["style", "top", '41px']
         ],
         "${_stopRed}": [
            ["style", "top", '82px'],
            ["style", "left", '29px'],
            ["style", "cursor", 'pointer']
         ],
         "${_tbNumber}": [
            ["style", "top", '-5px'],
            ["style", "font-size", '76px'],
            ["style", "height", '104px'],
            ["style", "font-family", 'Georgia, Times New Roman, Times, serif'],
            ["style", "left", '74px'],
            ["style", "width", '49px']
         ],
         "${_playGreen}": [
            ["style", "top", '82px'],
            ["style", "cursor", 'pointer'],
            ["style", "left", '133px'],
            ["color", "background-color", 'rgba(0,255,0,1.00)']
         ],
         "${_frame}": [
            ["color", "background-color", 'rgba(255,0,0,0.00)'],
            ["style", "top", '0px'],
            ["style", "left", '0px'],
            ["style", "height", '122px'],
            ["style", "border-style", 'solid'],
            ["style", "border-width", '3px'],
            ["style", "width", '192px']
         ],
         "${_rightDash}": [
            ["color", "background-color", 'rgba(255,0,0,1)'],
            ["style", "left", '133px'],
            ["style", "top", '41px']
         ],
         "${symbolSelector}": [
            ["style", "height", '138.12154696133px'],
            ["style", "width", '200px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 10000,
         autoPlay: true,
         timeline: [
            { id: "eid1", tween: [ "style", "${_leftDash}", "left", '8px', { fromValue: '8px'}], position: 0, duration: 0 },
            { id: "eid2", tween: [ "style", "${_leftDash}", "top", '41px', { fromValue: '41px'}], position: 0, duration: 0 }         ]
      }
   }
}
};


Edge.registerCompositionDefn(compId, symbols, fonts, resources);

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     Edge.launchComposition(compId);
});
})(jQuery, AdobeEdge, "EDGE-92925060");
