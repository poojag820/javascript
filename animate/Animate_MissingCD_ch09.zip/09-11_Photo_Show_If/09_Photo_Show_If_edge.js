/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
var im='images/';

var fonts = {};


var resources = [
];
var symbols = {
"stage": {
   version: "0.1.7",
   minimumCompatibleVersion: "0.1.7",
   build: "0.11.0.161",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
         dom: [
         {
            id:'thePhotos',
            type:'rect',
            rect:['373','276','0','0','undefined','undefined']
         }],
         symbolInstances: [
         {
            id:'thePhotos',
            symbolName:'thePhotos'
         }
         ]
      },
   states: {
      "Base State": {
         "${_Stage}": [
            ["color", "background-color", 'rgba(255,255,255,1)'],
            ["style", "height", '640px'],
            ["style", "width", '853px']
         ],
         "${_thePhotos}": [
            ["style", "left", '1px'],
            ["style", "top", '1px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 0,
         autoPlay: true,
         timeline: [
            { id: "eid21", tween: [ "style", "${_thePhotos}", "left", '1px', { fromValue: '1px'}], position: 0, duration: 0 },
            { id: "eid22", tween: [ "style", "${_thePhotos}", "top", '1px', { fromValue: '1px'}], position: 0, duration: 0 }         ]
      }
   }
},
"goPrev": {
   version: "0.1.7",
   minimumCompatibleVersion: "0.1.7",
   build: "0.11.0.161",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
   dom: [
   {
      rect: [0,0,'424px','637px'],
      transform: [[0,0]],
      id: 'Rectangle',
      stroke: [0,'rgba(0,0,0,1)','none'],
      type: 'rect',
      fill: ['rgba(255,255,255,1.00)']
   },
   {
      type: 'image',
      id: 'arrowPrev',
      rect: [143,204,'135','247'],
      transform: [[0,0]],
      fill: ['rgba(0,0,0,0)','images/arrowPrev.png']
   }],
   symbolInstances: [
   ]
   },
   states: {
      "Base State": {
         "${_Rectangle}": [
            ["color", "background-color", 'rgba(255,255,255,1.00)'],
            ["style", "height", '637px'],
            ["style", "top", '0px'],
            ["style", "left", '0px'],
            ["style", "width", '424px']
         ],
         "${_arrowPrev}": [
            ["style", "left", '143px'],
            ["style", "top", '204px']
         ],
         "${symbolSelector}": [
            ["style", "height", '636px'],
            ["style", "width", '423px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 0,
         autoPlay: true,
         timeline: [
         ]
      }
   }
},
"goNext": {
   version: "0.1.7",
   minimumCompatibleVersion: "0.1.7",
   build: "0.11.0.161",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
   dom: [
   {
      rect: [2,0,'424px','639px'],
      transform: [[0,0]],
      id: 'Rectangle2',
      stroke: [0,'rgb(0, 0, 0)','none'],
      type: 'rect',
      fill: ['rgba(255,255,255,1)']
   },
   {
      transform: [[0,0]],
      id: 'arrowNext',
      type: 'image',
      rect: [171,196,'135','247'],
      fill: ['rgba(0,0,0,0)','images/arrowNext.png']
   }],
   symbolInstances: [
   ]
   },
   states: {
      "Base State": {
         "${_Rectangle2}": [
            ["style", "height", '639px'],
            ["style", "top", '0px'],
            ["style", "left", '2px'],
            ["style", "width", '424.20004272461px']
         ],
         "${_arrowNext}": [
            ["style", "left", '171px'],
            ["style", "top", '196px']
         ],
         "${symbolSelector}": [
            ["style", "height", '637px'],
            ["style", "width", '423px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 0,
         autoPlay: true,
         timeline: [
         ]
      }
   }
},
"thePhotos": {
   version: "0.1.7",
   minimumCompatibleVersion: "0.1.7",
   build: "0.11.0.161",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
   dom: [
   {
      rect: ['0','0','853','640','undefined','undefined'],
      id: 'mainImage',
      fill: ['rgba(0,0,0,0)','images/photo-01.jpg'],
      type: 'image',
      tag: 'img'
   },
   {
      id: 'goNext',
      type: 'rect',
      cursor: ['pointer'],
      rect: ['496','190','0','0','undefined','undefined']
   },
   {
      id: 'goPrev',
      type: 'rect',
      cursor: ['pointer'],
      rect: ['84','114','0','0','undefined','undefined']
   },
   {
      rect: ['609','519','211','50','undefined','undefined'],
      align: 'right',
      font: ['Arial, Helvetica, sans-serif',24,'rgba(255,255,255,1.00)','normal','none','normal'],
      id: 'tbCount',
      text: '1 of 22',
      textShadow: ['rgba(0,0,0,1.00)',5,5,8],
      type: 'text'
   }],
   symbolInstances: [
   {
      id: 'goPrev',
      symbolName: 'goPrev'
   },
   {
      id: 'goNext',
      symbolName: 'goNext'
   }   ]
   },
   states: {
      "Base State": {
         "${_goPrev}": [
            ["style", "top", '2px'],
            ["style", "display", 'block'],
            ["style", "opacity", '0'],
            ["style", "left", '6px'],
            ["style", "cursor", 'pointer']
         ],
         "${symbolSelector}": [
            ["style", "height", '639px'],
            ["style", "width", '852px']
         ],
         "${_tbCount}": [
            ["subproperty", "textShadow.blur", '8px'],
            ["subproperty", "textShadow.offsetH", '5px'],
            ["style", "text-align", 'right'],
            ["color", "color", 'rgba(255,255,255,1.00)'],
            ["subproperty", "textShadow.offsetV", '5px'],
            ["subproperty", "textShadow.color", 'rgba(0,0,0,1.00)']
         ],
         "${_goNext}": [
            ["style", "top", '2px'],
            ["style", "display", 'block'],
            ["style", "opacity", '0'],
            ["style", "left", '426px'],
            ["style", "cursor", 'pointer']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 0,
         autoPlay: true,
         timeline: [
            { id: "eid16", tween: [ "style", "${_goPrev}", "display", 'block', { fromValue: 'block'}], position: 0, duration: 0 },
            { id: "eid15", tween: [ "style", "${_goNext}", "display", 'block', { fromValue: 'block'}], position: 0, duration: 0 },
            { id: "eid20", tween: [ "style", "${_goPrev}", "opacity", '0', { fromValue: '0'}], position: 0, duration: 0 },
            { id: "eid14", tween: [ "style", "${_goPrev}", "top", '2px', { fromValue: '2px'}], position: 0, duration: 0 },
            { id: "eid19", tween: [ "style", "${_goNext}", "opacity", '0', { fromValue: '0'}], position: 0, duration: 0 },
            { id: "eid13", tween: [ "style", "${_goPrev}", "left", '6px', { fromValue: '6px'}], position: 0, duration: 0 },
            { id: "eid12", tween: [ "style", "${_goNext}", "top", '2px', { fromValue: '2px'}], position: 0, duration: 0 },
            { id: "eid11", tween: [ "style", "${_goNext}", "left", '426px', { fromValue: '426px'}], position: 0, duration: 0 }         ]
      }
   }
}
};


Edge.registerCompositionDefn(compId, symbols, fonts, resources);

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     Edge.launchComposition(compId);
});
})(jQuery, AdobeEdge, "EDGE-36173216");
