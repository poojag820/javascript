/***********************
* Adobe Edge Composition Actions
*
* Edit this file with caution, being careful to preserve 
* function signatures and comments starting with 'Edge' to maintain the 
* ability to interact with these actions from within Adobe Edge
*
***********************/
(function($, Edge, compId){
var Composition = Edge.Composition, Symbol = Edge.Symbol; // aliases for commonly used Edge classes

   //Edge symbol: 'stage'
   (function(symbolName) {
      
      
      

      

      

      Symbol.bindElementAction(compId, symbolName, "document", "compositionReady", function(sym, e) {
         $("#Stage").css("margin","auto");

      });
      //Edge binding end

   })("stage");
   //Edge symbol end:'stage'

   //=========================================================
   
   //Edge symbol: 'goPrev'
   (function(symbolName) {   
   
   })("goPrev");
   //Edge symbol end:'goPrev'

   //=========================================================
   
   //Edge symbol: 'goNext'
   (function(symbolName) {   
   
   })("goNext");
   //Edge symbol end:'goNext'

   //=========================================================
   
   //Edge symbol: 'theCars_1'
   (function(symbolName) {   
   
      Symbol.bindElementAction(compId, symbolName, "${_goPrev}", "mouseup", function(sym, e) {
         sym.$("goPrev").fadeTo('normal',0.0);

      });
         //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_goPrev}", "mousedown", function(sym, e) {
         sym.$("goPrev").fadeTo('normal',0.6);

      });
         //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_goPrev}", "click", function(sym, e) {
         var numOfPhotos = 22;
         var pic = sym.$("mainImage");
         var textCount = sym.$("tbCount");
         
         var imageSource = pic.attr('src');
         var imageCount = +(imageSource.slice(13,15));
         imageCount = imageCount-1;
         if (imageCount==0) {imageCount = numOfPhotos}
         var newCount = imageCount + ' of '+ numOfPhotos;
         if (imageCount<10) {imageCount = '0'+imageCount}
         imageSource = 'images/photo-'+imageCount + '.jpg';
         pic.attr('src',imageSource);
         textCount.html(newCount);

      });
         //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_goNext}", "mouseup", function(sym, e) {
         sym.$("goNext").fadeTo('normal',0.0);

      });
         //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_goNext}", "mousedown", function(sym, e) {
         sym.$("goNext").fadeTo('normal',0.6);

      });
         //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_goNext}", "click", function(sym, e) {
         var numOfPhotos = 22;
         var pic = sym.$("mainImage");
         var textCount = sym.$("tbCount");
         
         var imageSource = pic.attr('src');
         var imageCount = +(imageSource.slice(13,15));
         imageCount = imageCount+1;
         if (imageCount>numOfPhotos) {imageCount = 1};
         var newCount = imageCount + ' of '+numOfPhotos;
         if (imageCount<10) {imageCount = '0'+imageCount};
         imageSource = 'images/photo-'+imageCount + '.jpg';
         pic.attr('src',imageSource);
         textCount.html(newCount);

      });
         //Edge binding end

      })("thePhotos");
   //Edge symbol end:'thePhotos'

})(jQuery, AdobeEdge, "EDGE-36173216");