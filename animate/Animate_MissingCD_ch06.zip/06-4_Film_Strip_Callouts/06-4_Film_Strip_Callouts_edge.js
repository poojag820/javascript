/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
var im='images/';

var fonts = {};


var resources = [
];
var symbols = {
"stage": {
   version: "0.1.7",
   minimumCompatibleVersion: "0.1.7",
   build: "0.11.0.161",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
         dom: [
         {
            id:'flowerStrip',
            type:'image',
            rect:['0','0','2500','375','undefined','undefined'],
            fill:["rgba(0,0,0,0)",im+"flowerStrip375x2500.jpg"],
            transform:[]
         },
         {
            id:'NextFlower',
            type:'group',
            rect:['250px','375px','250','50','auto','auto'],
            c:[
            {
               id:'RectangleCopy',
               type:'rect',
               rect:['0px','0px','250px','50px','auto','auto'],
               fill:["rgba(192,192,192,1)"],
               stroke:[0,"rgba(0,0,0,1)","none"]
            },
            {
               id:'Text2',
               type:'text',
               rect:['61px','11px','150px','29px','auto','auto'],
               text:"Next Flower",
               align:"left",
               font:['Verdana, Geneva, sans-serif',24,"rgba(255,255,255,1.00)","normal","none","normal"],
               textShadow:["rgba(0,0,0,0.65)",3,3,3]
            }]
         },
         {
            id:'StartOver',
            type:'group',
            rect:['0','375','250','50','auto','auto'],
            c:[
            {
               id:'Rectangle',
               type:'rect',
               rect:['0px','0px','250px','50px','auto','auto'],
               fill:["rgba(192,192,192,1)"],
               stroke:[0,"rgba(0,0,0,1)","none"]
            },
            {
               id:'Text',
               type:'text',
               rect:['70px','11px','auto','auto','auto','auto'],
               text:"Start Over",
               font:['Verdana, Geneva, sans-serif',24,"rgba(255,255,255,1.00)","normal","none",""],
               textShadow:["rgba(0,0,0,0.65)",3,3,3]
            }]
         }],
         symbolInstances: [

         ]
      },
   states: {
      "Base State": {
         "${_StartOver}": [
            ["style", "cursor", 'auto']
         ],
         "${_flowerStrip}": [
            ["style", "left", '0px'],
            ["style", "top", '0px']
         ],
         "${_Text}": [
            ["subproperty", "textShadow.blur", '3px'],
            ["subproperty", "textShadow.offsetH", '3px'],
            ["style", "top", '11px'],
            ["subproperty", "textShadow.color", 'rgba(0,0,0,0.65)'],
            ["color", "color", 'rgba(255,255,255,1.00)'],
            ["subproperty", "textShadow.offsetV", '3px'],
            ["style", "left", '70px'],
            ["style", "font-family", 'Verdana, Geneva, sans-serif']
         ],
         "${_Stage}": [
            ["color", "background-color", 'rgba(0,0,0,1.00)'],
            ["style", "overflow", 'hidden'],
            ["style", "height", '425px'],
            ["style", "width", '500px']
         ],
         "${_Rectangle}": [
            ["style", "top", '0px'],
            ["style", "width", '250px']
         ],
         "${_Text2}": [
            ["subproperty", "textShadow.blur", '3px'],
            ["subproperty", "textShadow.offsetH", '3px'],
            ["color", "color", 'rgba(255,255,255,1.00)'],
            ["subproperty", "textShadow.offsetV", '3px'],
            ["style", "left", '61px'],
            ["style", "width", '149.98333740234px'],
            ["style", "top", '11px'],
            ["style", "height", '29px'],
            ["style", "font-family", 'Verdana, Geneva, sans-serif'],
            ["subproperty", "textShadow.color", 'rgba(0,0,0,0.65)']
         ],
         "${_RectangleCopy}": [
            ["style", "top", '0px'],
            ["style", "left", '0px'],
            ["style", "width", '250px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 7500,
         autoPlay: true,
         labels: {
            "poppy": 0,
            "rose": 1500,
            "daisy": 3000,
            "lilac": 4500,
            "tigerLily": 6000
         },
         timeline: [
            { id: "eid1", tween: [ "style", "${_flowerStrip}", "left", '-500px', { fromValue: '0px'}], position: 1000, duration: 500 },
            { id: "eid2", tween: [ "style", "${_flowerStrip}", "left", '-1000px', { fromValue: '-500px'}], position: 2500, duration: 500 },
            { id: "eid3", tween: [ "style", "${_flowerStrip}", "left", '-1500px', { fromValue: '-1000px'}], position: 4000, duration: 500 },
            { id: "eid4", tween: [ "style", "${_flowerStrip}", "left", '-2000px', { fromValue: '-1500px'}], position: 5500, duration: 500 },
            { id: "eid17", tween: [ "style", "${_flowerStrip}", "left", '0px', { fromValue: '-2000px'}], position: 7000, duration: 500 }         ]
      }
   }
}
};


Edge.registerCompositionDefn(compId, symbols, fonts, resources);

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     Edge.launchComposition(compId);
});
})(jQuery, AdobeEdge, "EDGE-11331110");
