/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
var im='images/';

var fonts = {};


var resources = [
];
var symbols = {
"stage": {
   version: "0.1.7",
   minimumCompatibleVersion: "0.1.7",
   build: "0.11.0.161",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: true,
   resizeInstances: false,
   content: {
         dom: [
         {
            id:'bike',
            display:'none',
            type:'image',
            rect:['0','0','600','400','undefined','undefined'],
            fill:["rgba(0,0,0,0)",im+"bike.jpg"]
         },
         {
            id:'bridge',
            display:'none',
            type:'image',
            rect:['0','0','600','400','undefined','undefined'],
            fill:["rgba(0,0,0,0)",im+"bridge.jpg"]
         },
         {
            id:'house',
            display:'none',
            type:'image',
            rect:['0','0','600','400','undefined','undefined'],
            fill:["rgba(0,0,0,0)",im+"house.jpg"]
         },
         {
            id:'squirrel',
            display:'none',
            type:'image',
            rect:['0','0','600','400','undefined','undefined'],
            fill:["rgba(0,0,0,0)",im+"squirrel.jpg"]
         },
         {
            id:'txtPhotos',
            type:'text',
            rect:['72','39','0','0','undefined','undefined'],
            text:"photos",
            font:['Arial Black, Gadget, sans-serif',20,"rgba(255,255,255,1.00)","normal","none",""],
            transform:[]
         },
         {
            id:'btnPhotos',
            type:'rect',
            rect:['41','38','0','0','undefined','undefined'],
            opacity:0.22
         },
         {
            id:'txtSquirrel',
            type:'text',
            rect:['67','90','0','0','undefined','undefined'],
            text:"squirrel",
            align:"auto",
            font:['\'Arial Black\', Gadget, sans-serif',20,"rgba(255,255,255,1.00)","normal","none","normal"],
            transform:[]
         },
         {
            id:'btnSquirrel',
            type:'rect',
            rect:['41','89','0','0','undefined','undefined'],
            opacity:0.22,
            transform:[]
         },
         {
            id:'txtHouse',
            type:'text',
            rect:['72','119','73','28','undefined','undefined'],
            text:"house",
            align:"auto",
            font:['\'Arial Black\', Gadget, sans-serif',20,"rgba(255,255,255,1.00)","normal","none","normal"],
            transform:[]
         },
         {
            id:'btnHouse',
            type:'rect',
            rect:['41','118','0','0','undefined','undefined'],
            opacity:0.22,
            transform:[]
         },
         {
            id:'txtBridge',
            type:'text',
            rect:['72','148','73','28','undefined','undefined'],
            text:"bridge",
            align:"auto",
            font:['\'Arial Black\', Gadget, sans-serif',20,"rgba(255,255,255,1.00)","normal","none","normal"],
            transform:[]
         },
         {
            id:'btnBridge',
            type:'rect',
            rect:['41','147','0','0','undefined','undefined'],
            opacity:0.22,
            transform:[]
         },
         {
            id:'txtBike',
            type:'text',
            rect:['83','177','52','28','undefined','undefined'],
            text:"bike",
            align:"auto",
            font:['\'Arial Black\', Gadget, sans-serif',20,"rgba(255,255,255,1.00)","normal","none","normal"],
            transform:[]
         },
         {
            id:'btnBike',
            type:'rect',
            rect:['0','87','0','0','undefined','undefined'],
            transform:[]
         }],
         symbolInstances: [
         {
            id:'btnBike',
            symbolName:'Button'
         },
         {
            id:'btnHouse',
            symbolName:'Button'
         },
         {
            id:'btnPhotos',
            symbolName:'Button'
         },
         {
            id:'btnSquirrel',
            symbolName:'Button'
         },
         {
            id:'btnBridge',
            symbolName:'Button'
         }
         ]
      },
   states: {
      "Base State": {
         "${_txtBridge}": [
            ["style", "top", '148px'],
            ["color", "color", 'rgba(255,255,255,1.00)'],
            ["style", "left", '72px'],
            ["style", "height", '28px']
         ],
         "${_btnHouse}": [
            ["style", "top", '118px'],
            ["style", "opacity", '0.22'],
            ["style", "left", '41px']
         ],
         "${_bridge}": [
            ["style", "display", 'none']
         ],
         "${_bike}": [
            ["style", "display", 'none']
         ],
         "${_txtPhotos}": [
            ["style", "top", '39px'],
            ["color", "color", 'rgba(255,255,255,1.00)'],
            ["style", "left", '72px'],
            ["style", "font-size", '20px']
         ],
         "${_stage}": [
            ["style", "height", '400px'],
            ["style", "width", '600px'],
            ["style", "overflow", 'hidden']
         ],
         "${_btnBike}": [
            ["style", "display", 'block'],
            ["style", "opacity", '0.22'],
            ["style", "left", '41px'],
            ["style", "top", '176px']
         ],
         "${_txtSquirrel}": [
            ["style", "top", '90px'],
            ["style", "left", '67px'],
            ["color", "color", 'rgba(255,255,255,1.00)']
         ],
         "${_txtBike}": [
            ["style", "top", '177px'],
            ["color", "color", 'rgba(255,255,255,1.00)'],
            ["style", "left", '83px'],
            ["style", "width", '52px']
         ],
         "${_btnPhotos}": [
            ["style", "opacity", '0.22']
         ],
         "${_btnSquirrel}": [
            ["style", "top", '89px'],
            ["style", "opacity", '0.22'],
            ["style", "left", '41px']
         ],
         "${_squirrel}": [
            ["style", "display", 'none']
         ],
         "${_txtHouse}": [
            ["style", "top", '119px'],
            ["color", "color", 'rgba(255,255,255,1.00)'],
            ["style", "left", '72px'],
            ["style", "width", '73px']
         ],
         "${_btnBridge}": [
            ["style", "top", '147px'],
            ["style", "opacity", '0.22'],
            ["style", "left", '41px']
         ],
         "${_house}": [
            ["style", "display", 'none']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 1500,
         autoPlay: false,
         labels: {
            "squirrel": 0,
            "house": 500,
            "bridge": 1000,
            "bike": 1500
         },
         timeline: [
            { id: "eid12", tween: [ "style", "${_btnBike}", "left", '41px', { fromValue: '41px'}], position: 0, duration: 0 },
            { id: "eid13", tween: [ "style", "${_btnBike}", "top", '176px', { fromValue: '176px'}], position: 0, duration: 0 },
            { id: "eid1", tween: [ "style", "${_squirrel}", "display", 'block', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid5", tween: [ "style", "${_squirrel}", "display", 'none', { fromValue: 'block'}], position: 500, duration: 0 },
            { id: "eid14", tween: [ "style", "${_btnBike}", "opacity", '0.22', { fromValue: '0.22'}], position: 0, duration: 0 },
            { id: "eid4", tween: [ "style", "${_house}", "display", 'block', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid6", tween: [ "style", "${_house}", "display", 'none', { fromValue: 'block'}], position: 1000, duration: 0 },
            { id: "eid3", tween: [ "style", "${_bike}", "display", 'block', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid2", tween: [ "style", "${_bridge}", "display", 'block', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid7", tween: [ "style", "${_bridge}", "display", 'none', { fromValue: 'block'}], position: 1500, duration: 0 }         ]
      }
   }
},
"Button": {
   version: "0.1.7",
   minimumCompatibleVersion: "0.1.7",
   build: "0.11.0.161",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: true,
   resizeInstances: false,
   content: {
   dom: [
   {
      rect: [0,0,135,29],
      id: 'Rectangle',
      stroke: [0,'rgba(0,0,0,1)','none'],
      type: 'rect',
      fill: ['rgba(255,255,255,1.00)',null]
   }],
   symbolInstances: [
   ]
   },
   states: {
      "Base State": {
         "${symbolSelector}": [
            ["style", "height", '29px'],
            ["style", "width", '135px']
         ],
         "${_Rectangle}": [
            ["color", "background-color", 'rgba(255,255,255,1.00)'],
            ["style", "width", '135px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 500,
         autoPlay: false,
         labels: {
            "normal": 0,
            "over": 500
         },
         timeline: [
            { id: "eid9", tween: [ "color", "${_Rectangle}", "background-color", 'rgba(0,0,0,1.00)', { animationColorSpace: 'RGB', valueTemplate: undefined, fromValue: 'rgba(255,255,255,1)'}], position: 0, duration: 500 }         ]
      }
   }
}
};


Edge.registerCompositionDefn(compId, symbols, fonts, resources);

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     Edge.launchComposition(compId);
});
})(jQuery, AdobeEdge, "EDGE-66796352");
