/***********************
* Adobe Edge Composition Actions
*
* Edit this file with caution, being careful to preserve 
* function signatures and comments starting with 'Edge' to maintain the 
* ability to interact with these actions from within Adobe Edge
*
***********************/
(function($, Edge, compId){
var Composition = Edge.Composition, Symbol = Edge.Symbol; // aliases for commonly used Edge classes

//Edge symbol: 'stage'
(function(symbolName) {


Symbol.bindElementAction(compId, symbolName, "${_btnPhotos}", "click", function(sym, e) {
// Toggles the symbols in submenu on and off
sym.$("btnSquirrel").toggle();
sym.$("txtSquirrel").toggle();
sym.$("btnHouse").toggle();
sym.$("txtHouse").toggle();
sym.$("btnBridge").toggle();
sym.$("txtBridge").toggle();
sym.$("btnBike").toggle();
sym.$("txtBike").toggle();

});
//Edge binding end

Symbol.bindElementAction(compId, symbolName, "document", "compositionReady", function(sym, e) {
// Show an Element.
//  (sym.$("name") resolves an Edge element name to a DOM
//  element that can be used with jQuery)
sym.$("squirrel").show();
// hide the elements in the submenu
sym.$("btnSquirrel").hide();
sym.$("txtSquirrel").hide();
sym.$("btnHouse").hide();
sym.$("txtHouse").hide();
sym.$("btnBridge").hide();
sym.$("txtBridge").hide();
sym.$("btnBike").hide();
sym.$("txtBike").hide();

});
//Edge binding end

Symbol.bindElementAction(compId, symbolName, "${_btnHouse}", "click", function(sym, e) {
// stop the timeline at the given position (ms or label)
sym.stop('house');
// hide the elements in the submenu
sym.$("btnSquirrel").hide();
sym.$("txtSquirrel").hide();
sym.$("btnHouse").hide();
sym.$("txtHouse").hide();
sym.$("btnBridge").hide();
sym.$("txtBridge").hide();
sym.$("btnBike").hide();
sym.$("txtBike").hide();

});
//Edge binding end

Symbol.bindElementAction(compId, symbolName, "${_btnSquirrel}", "click", function(sym, e) {
// stop the timeline at the given position (ms or label)
sym.stop('squirrel');
// hide the elements in the submenu
sym.$("btnSquirrel").hide();
sym.$("txtSquirrel").hide();
sym.$("btnHouse").hide();
sym.$("txtHouse").hide();
sym.$("btnBridge").hide();
sym.$("txtBridge").hide();
sym.$("btnBike").hide();
sym.$("txtBike").hide();

});
//Edge binding end

Symbol.bindElementAction(compId, symbolName, "${_btnBridge}", "click", function(sym, e) {
// stop the timeline at the given position (ms or label)
sym.stop('bridge');
// hide the elements in the submenu
sym.$("btnSquirrel").hide();
sym.$("txtSquirrel").hide();
sym.$("btnHouse").hide();
sym.$("txtHouse").hide();
sym.$("btnBridge").hide();
sym.$("txtBridge").hide();
sym.$("btnBike").hide();
sym.$("txtBike").hide();

});
//Edge binding end

Symbol.bindElementAction(compId, symbolName, "${_btnBike}", "click", function(sym, e) {
// stop the timeline at the given position (ms or label)
sym.stop('bike');
// hide the elements in the submenu
sym.$("btnSquirrel").hide();
sym.$("txtSquirrel").hide();
sym.$("btnHouse").hide();
sym.$("txtHouse").hide();
sym.$("btnBridge").hide();
sym.$("txtBridge").hide();
sym.$("btnBike").hide();
sym.$("txtBike").hide();

});
//Edge binding end



})("stage");
   //Edge symbol end:'stage'

//=========================================================

//Edge symbol: 'Button'
(function(symbolName) {
Symbol.bindElementAction(compId, symbolName, "${_Rectangle}", "mouseover", function(sym, e) {
// stop the timeline at the given position (ms or label)
sym.stop('over');
sym.$("Rectangle").css('cursor','pointer');

});
//Edge binding end

Symbol.bindElementAction(compId, symbolName, "${_Rectangle}", "mouseout", function(sym, e) {
// stop the timeline at the given position (ms or label)
sym.stop('normal');

});
//Edge binding end



})("Button");
   //Edge symbol end:'Button'

//=========================================================

//Edge symbol: 'SubMenu'
(function(symbolName) {
Symbol.bindElementAction(compId, symbolName, "${_btnSquirrel}", "click", function(sym, e) {
// stop the timeline at the given position (ms or label)
sym.stop('squirrel');

});
//Edge binding end

Symbol.bindElementAction(compId, symbolName, "${_btnhouse}", "click", function(sym, e) {
// stop the timeline at the given position (ms or label)
sym.stop('house');

});
//Edge binding end

Symbol.bindElementAction(compId, symbolName, "${_btnBridge}", "click", function(sym, e) {
// stop the timeline at the given position (ms or label)
sym.stop('bridge');

});
//Edge binding end

Symbol.bindElementAction(compId, symbolName, "${_btnBike}", "click", function(sym, e) {
// stop the timeline at the given position (ms or label)
sym.getComposition.stop('bike');

});
//Edge binding end



})("SubMenu");
   //Edge symbol end:'SubMenu'

})(jQuery, AdobeEdge, "EDGE-66796352");