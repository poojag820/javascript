/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
var im='images/';

var fonts = {};


var resources = [
];
var symbols = {
"stage": {
   version: "0.1.7",
   minimumCompatibleVersion: "0.1.7",
   build: "0.11.0.161",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
         dom: [
         {
            id:'Home',
            type:'group',
            rect:['40','50','160','40','auto','auto'],
            c:[
            {
               id:'tbHome',
               type:'text',
               rect:['42px','3px','auto','auto','auto','auto'],
               text:"Home",
               font:['Arial Black, Gadget, sans-serif',[24,""],"rgba(0,0,0,1)","normal","none",""]
            },
            {
               id:'btnHome',
               type:'rect',
               rect:['0px','0px','auto','auto','auto','auto']
            }]
         },
         {
            id:'Contacts',
            type:'group',
            rect:['40px','109px','160','40','auto','auto'],
            c:[
            {
               id:'tbContacts',
               type:'text',
               rect:['20px','3px','auto','auto','auto','auto'],
               opacity:1,
               text:"Contacts",
               align:"left",
               font:['\'Arial Black\', Gadget, sans-serif',24,"rgba(0,0,0,1)","normal","none","normal"]
            },
            {
               id:'btnContacts',
               type:'rect',
               rect:['0px','0px','auto','auto','auto','auto']
            }]
         },
         {
            id:'Books',
            type:'group',
            rect:['40','169px','160','40','auto','auto'],
            c:[
            {
               id:'tbBooks',
               type:'text',
               rect:['39px','3px','auto','auto','auto','auto'],
               text:"Books",
               align:"left",
               font:['\'Arial Black\', Gadget, sans-serif',24,"rgba(0,0,0,1)","normal","none","normal"]
            },
            {
               id:'btnBooks',
               type:'rect',
               rect:['0px','0px','auto','auto','auto','auto']
            }]
         }],
         symbolInstances: [
         {
            id:'btnContacts',
            symbolName:'Button'
         },
         {
            id:'btnBooks',
            symbolName:'Button'
         },
         {
            id:'btnHome',
            symbolName:'Button'
         }
         ]
      },
   states: {
      "Base State": {
         "${_btnHome}": [
            ["style", "top", '0px'],
            ["style", "opacity", '0.75'],
            ["style", "left", '0px']
         ],
         "${_btnBooks}": [
            ["style", "top", '0px'],
            ["style", "opacity", '0.75'],
            ["style", "left", '0px']
         ],
         "${_btnContacts}": [
            ["style", "top", '0px'],
            ["style", "opacity", '0.75'],
            ["style", "left", '0px']
         ],
         "${_tbHome}": [
            ["style", "top", '3px'],
            ["style", "font-family", 'Arial Black, Gadget, sans-serif'],
            ["style", "left", '42px']
         ],
         "${_Contacts}": [
            ["style", "top", '109px'],
            ["style", "left", '40px']
         ],
         "${_Books}": [
            ["style", "top", '168.78px']
         ],
         "${_tbBooks}": [
            ["style", "left", '39px'],
            ["style", "top", '3px']
         ],
         "${_tbContacts}": [
            ["style", "top", '3px'],
            ["style", "opacity", '1'],
            ["style", "left", '20px']
         ],
         "${_Stage}": [
            ["style", "height", '400px'],
            ["color", "background-color", 'rgba(255,255,255,1)'],
            ["style", "width", '550px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 0,
         autoPlay: true,
         timeline: [
            { id: "eid6", tween: [ "style", "${_btnHome}", "opacity", '0.75', { fromValue: '0.75'}], position: 0, duration: 0 },
            { id: "eid7", tween: [ "style", "${_btnContacts}", "opacity", '0.75', { fromValue: '0.75'}], position: 0, duration: 0 },
            { id: "eid8", tween: [ "style", "${_btnBooks}", "opacity", '0.75', { fromValue: '0.75'}], position: 0, duration: 0 }         ]
      }
   }
},
"Button": {
   version: "0.1.7",
   minimumCompatibleVersion: "0.1.7",
   build: "0.11.0.161",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
   dom: [
   {
      rect: ['0px','0px','160px','40px','auto','auto'],
      borderRadius: ['15px 15px','15px 15px','15px 15px','15px 15px'],
      id: 'RoundRect',
      stroke: [0,'rgba(0,0,0,1)','none'],
      type: 'rect',
      fill: ['rgba(45,129,80,1)']
   }],
   symbolInstances: [
   ]
   },
   states: {
      "Base State": {
         "${_RoundRect}": [
            ["color", "background-color", 'rgba(45,129,80,1.00)'],
            ["style", "border-top-left-radius", [15,15], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["style", "border-bottom-right-radius", [15,15], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["style", "border-top-right-radius", [15,15], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["style", "width", '160px'],
            ["style", "top", '0px'],
            ["style", "border-bottom-left-radius", [15,15], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["style", "height", '40px'],
            ["style", "left", '0px']
         ],
         "${symbolSelector}": [
            ["style", "height", '40px'],
            ["style", "width", '160px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 2250,
         autoPlay: false,
         labels: {
            "normal": 0,
            "over": 1000,
            "down": 2000
         },
         timeline: [
            { id: "eid3", tween: [ "color", "${_RoundRect}", "background-color", 'rgba(45,129,80,1.00)', { animationColorSpace: 'RGB', valueTemplate: undefined, fromValue: 'rgba(45,129,80,1.00)'}], position: 0, duration: 0 },
            { id: "eid4", tween: [ "color", "${_RoundRect}", "background-color", 'rgba(64,197,120,1.00)', { animationColorSpace: 'RGB', valueTemplate: undefined, fromValue: 'rgba(45,129,80,1.00)'}], position: 1000, duration: 0 },
            { id: "eid9", tween: [ "color", "${_RoundRect}", "background-color", 'rgba(210,225,60,1.00)', { animationColorSpace: 'RGB', valueTemplate: undefined, fromValue: 'rgba(64,197,120,1.00)'}], position: 2000, duration: 0 }         ]
      }
   }
}
};


Edge.registerCompositionDefn(compId, symbols, fonts, resources);

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     Edge.launchComposition(compId);
});
})(jQuery, AdobeEdge, "EDGE-970095");
