/***********************
* Adobe Edge Composition Actions
*
* Edit this file with caution, being careful to preserve 
* function signatures and comments starting with 'Edge' to maintain the 
* ability to interact with these actions from within Adobe Edge
*
***********************/
(function($, Edge, compId){
var Composition = Edge.Composition, Symbol = Edge.Symbol; // aliases for commonly used Edge classes

//Edge symbol: 'stage'
(function(symbolName) {




Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 2750, function(sym, e) {
// play the timeline from the given position (ms or label)
sym.play(0
);

});
//Edge binding end







})("stage");
   //Edge symbol end:'stage'

//=========================================================

//Edge symbol: 'Antenna'
(function(symbolName) {







})("Antenna");
   //Edge symbol end:'Antenna'

//=========================================================

//Edge symbol: 'Body'
(function(symbolName) {







})("Body");
   //Edge symbol end:'Body'

//=========================================================

//Edge symbol: 'Leg'
(function(symbolName) {







})("Leg");
   //Edge symbol end:'Leg'

//=========================================================

//Edge symbol: 'Roach'
(function(symbolName) {



Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 1000, function(sym, e) {
// play the timeline from the given position (ms or label)
sym.play(0);

});
//Edge binding end






})("Roach");
   //Edge symbol end:'Roach'

})(jQuery, AdobeEdge, "EDGE-65759929");