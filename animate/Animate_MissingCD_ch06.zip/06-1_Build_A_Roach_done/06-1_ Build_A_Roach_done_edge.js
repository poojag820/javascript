/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
var im='images/';

var fonts = {};


var resources = [
];
var symbols = {
"stage": {
   version: "0.1.7",
   minimumCompatibleVersion: "0.1.7",
   build: "0.11.0.153",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: true,
   resizeInstances: false,
   content: {
         dom: [
         {
            id:'fredRoach',
            type:'rect',
            rect:['','-1160','0','0','auto','auto'],
            transform:[[],[],[],['0.2','0.2']]
         },
         {
            id:'joeRoach',
            type:'rect',
            rect:['','','0','0','auto','auto'],
            transform:[[],['-46'],[],['0.14','0.14']]
         },
         {
            id:'richardRoach',
            type:'rect',
            rect:['228','205','0','0','auto','auto']
         }],
         symbolInstances: [
         {
            id:'fredRoach',
            symbolName:'Roach'
         },
         {
            id:'richardRoach',
            symbolName:'Roach'
         },
         {
            id:'joeRoach',
            symbolName:'Roach'
         }
         ]
      },
   states: {
      "Base State": {
         "${_fredRoach}": [
            ["style", "-webkit-transform-origin", [50,50], {valueTemplate:'@@0@@% @@1@@%'} ],
            ["style", "-moz-transform-origin", [50,50],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "-ms-transform-origin", [50,50],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "msTransformOrigin", [50,50],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "-o-transform-origin", [50,50],{valueTemplate:'@@0@@% @@1@@%'}],
            ["transform", "scaleY", '0.2'],
            ["transform", "rotateZ", '0deg'],
            ["transform", "scaleX", '0.2'],
            ["style", "left", '-68px'],
            ["style", "top", '153.99px']
         ],
         "${_stage}": [
            ["style", "height", '400px'],
            ["color", "background-color", 'rgba(255,255,255,1.00)'],
            ["style", "width", '468px'],
            ["style", "overflow", 'hidden']
         ],
         "${_joeRoach}": [
            ["style", "top", '-81px'],
            ["transform", "scaleY", '0.14'],
            ["transform", "rotateZ", '-46deg'],
            ["transform", "scaleX", '0.14'],
            ["style", "left", '223px']
         ],
         "${_richardRoach}": [
            ["style", "top", '181px'],
            ["transform", "scaleY", '0.11'],
            ["transform", "rotateZ", '-42deg'],
            ["transform", "scaleX", '0.11'],
            ["style", "left", '227.21px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 2750,
         autoPlay: true,
         timeline: [
            { id: "eid154", tween: [ "style", "${_fredRoach}", "top", '-79px', { fromValue: '153.99px'}], position: 0, duration: 1076 },
            { id: "eid157", tween: [ "style", "${_fredRoach}", "top", '-61px', { fromValue: '-79px'}], position: 1076, duration: 493 },
            { id: "eid160", tween: [ "style", "${_fredRoach}", "top", '3px', { fromValue: '-61px'}], position: 1569, duration: 430 },
            { id: "eid162", tween: [ "style", "${_fredRoach}", "top", '187.9px', { fromValue: '3px'}], position: 2000, duration: 250 },
            { id: "eid170", tween: [ "style", "${_fredRoach}", "top", '191.46px', { fromValue: '187.9px'}], position: 2250, duration: 98 },
            { id: "eid172", tween: [ "style", "${_fredRoach}", "top", '180.46px', { fromValue: '191.46px'}], position: 2348, duration: 188 },
            { id: "eid174", tween: [ "style", "${_fredRoach}", "top", '155.26px', { fromValue: '180.46px'}], position: 2536, duration: 213 },
            { id: "eid229", tween: [ "style", "${_richardRoach}", "left", '148.21px', { fromValue: '227.21px'}], position: 0, duration: 308 },
            { id: "eid230", tween: [ "style", "${_richardRoach}", "left", '140.96px', { fromValue: '148.21px'}], position: 308, duration: 138 },
            { id: "eid240", tween: [ "style", "${_richardRoach}", "left", '184.96px', { fromValue: '140.96px'}], position: 447, duration: 242 },
            { id: "eid243", tween: [ "style", "${_richardRoach}", "left", '304.95px', { fromValue: '184.96px'}], position: 689, duration: 425 },
            { id: "eid246", tween: [ "style", "${_richardRoach}", "left", '307.95px', { fromValue: '304.95px'}], position: 1114, duration: 454 },
            { id: "eid249", tween: [ "style", "${_richardRoach}", "left", '308.95px', { fromValue: '307.95px'}], position: 1569, duration: 332 },
            { id: "eid252", tween: [ "style", "${_richardRoach}", "left", '203.95px', { fromValue: '308.95px'}], position: 1901, duration: 348 },
            { id: "eid254", tween: [ "style", "${_richardRoach}", "left", '226.76px', { fromValue: '203.95px'}], position: 2250, duration: 499 },
            { id: "eid153", tween: [ "style", "${_fredRoach}", "left", '70px', { fromValue: '-68px'}], position: 0, duration: 1076 },
            { id: "eid156", tween: [ "style", "${_fredRoach}", "left", '217.99px', { fromValue: '70px'}], position: 1076, duration: 493 },
            { id: "eid159", tween: [ "style", "${_fredRoach}", "left", '289.99px', { fromValue: '217.99px'}], position: 1569, duration: 430 },
            { id: "eid164", tween: [ "style", "${_fredRoach}", "left", '295.99px', { fromValue: '289.99px'}], position: 2000, duration: 250 },
            { id: "eid169", tween: [ "style", "${_fredRoach}", "left", '211.99px', { fromValue: '295.99px'}], position: 2250, duration: 98 },
            { id: "eid171", tween: [ "style", "${_fredRoach}", "left", '-20px', { fromValue: '211.99px'}], position: 2348, duration: 188 },
            { id: "eid173", tween: [ "style", "${_fredRoach}", "left", '-63px', { fromValue: '-20px'}], position: 2536, duration: 213 },
            { id: "eid149", tween: [ "transform", "${_fredRoach}", "scaleY", '0.2', { fromValue: '0.2'}], position: 269, duration: 0 },
            { id: "eid177", tween: [ "transform", "${_fredRoach}", "scaleY", '0.198', { fromValue: '0.2'}], position: 2536, duration: 213 },
            { id: "eid231", tween: [ "style", "${_richardRoach}", "top", '126.07px', { fromValue: '181px'}], position: 0, duration: 308 },
            { id: "eid232", tween: [ "style", "${_richardRoach}", "top", '57.39px', { fromValue: '126.07px'}], position: 308, duration: 138 },
            { id: "eid241", tween: [ "style", "${_richardRoach}", "top", '41.39px', { fromValue: '57.39px'}], position: 447, duration: 242 },
            { id: "eid244", tween: [ "style", "${_richardRoach}", "top", '40.11px', { fromValue: '41.39px'}], position: 689, duration: 425 },
            { id: "eid247", tween: [ "style", "${_richardRoach}", "top", '97.12px', { fromValue: '40.11px'}], position: 1114, duration: 454 },
            { id: "eid250", tween: [ "style", "${_richardRoach}", "top", '166.12px', { fromValue: '97.12px'}], position: 1569, duration: 332 },
            { id: "eid253", tween: [ "style", "${_richardRoach}", "top", '151.9px', { fromValue: '166.12px'}], position: 1901, duration: 348 },
            { id: "eid255", tween: [ "style", "${_richardRoach}", "top", '177.45px', { fromValue: '151.9px'}], position: 2250, duration: 499 },
            { id: "eid148", tween: [ "transform", "${_fredRoach}", "scaleX", '0.2', { fromValue: '0.2'}], position: 269, duration: 0 },
            { id: "eid176", tween: [ "transform", "${_fredRoach}", "scaleX", '0.198', { fromValue: '0.2'}], position: 2536, duration: 213 },
            { id: "eid235", tween: [ "transform", "${_richardRoach}", "rotateZ", '-9deg', { fromValue: '-42deg'}], position: 308, duration: 138 },
            { id: "eid236", tween: [ "transform", "${_richardRoach}", "rotateZ", '47deg', { fromValue: '-9deg'}], position: 447, duration: 242 },
            { id: "eid239", tween: [ "transform", "${_richardRoach}", "rotateZ", '84deg', { fromValue: '47deg'}], position: 689, duration: 425 },
            { id: "eid242", tween: [ "transform", "${_richardRoach}", "rotateZ", '162deg', { fromValue: '84deg'}], position: 1114, duration: 454 },
            { id: "eid245", tween: [ "transform", "${_richardRoach}", "rotateZ", '180deg', { fromValue: '162deg'}], position: 1569, duration: 332 },
            { id: "eid248", tween: [ "transform", "${_richardRoach}", "rotateZ", '281deg', { fromValue: '180deg'}], position: 1901, duration: 348 },
            { id: "eid251", tween: [ "transform", "${_richardRoach}", "rotateZ", '-42deg', { fromValue: '281deg'}], position: 2250, duration: 499 },
            { id: "eid178", tween: [ "style", "${_joeRoach}", "left", '139.01px', { fromValue: '223px'}], position: 0, duration: 221 },
            { id: "eid181", tween: [ "style", "${_joeRoach}", "left", '48.07px', { fromValue: '139.01px'}], position: 221, duration: 226 },
            { id: "eid184", tween: [ "style", "${_joeRoach}", "left", '-19.74px', { fromValue: '48.07px'}], position: 447, duration: 209 },
            { id: "eid190", tween: [ "style", "${_joeRoach}", "left", '-49.74px', { fromValue: '-19.74px'}], position: 656, duration: 254 },
            { id: "eid193", tween: [ "style", "${_joeRoach}", "left", '-93.74px', { fromValue: '-49.74px'}], position: 910, duration: 165 },
            { id: "eid197", tween: [ "style", "${_joeRoach}", "left", '-89.74px', { fromValue: '-93.74px'}], position: 1076, duration: 232 },
            { id: "eid200", tween: [ "style", "${_joeRoach}", "left", '-16.74px', { fromValue: '-89.74px'}], position: 1308, duration: 176 },
            { id: "eid203", tween: [ "style", "${_joeRoach}", "left", '72.29px', { fromValue: '-16.74px'}], position: 1484, duration: 117 },
            { id: "eid205", tween: [ "style", "${_joeRoach}", "left", '123.29px', { fromValue: '72.29px'}], position: 1602, duration: 254 },
            { id: "eid208", tween: [ "style", "${_joeRoach}", "left", '72.24px', { fromValue: '123.29px'}], position: 1856, duration: 492 },
            { id: "eid211", tween: [ "style", "${_joeRoach}", "left", '237.24px', { fromValue: '72.24px'}], position: 2348, duration: 188 },
            { id: "eid214", tween: [ "style", "${_joeRoach}", "left", '213.24px', { fromValue: '237.24px'}], position: 2536, duration: 213 },
            { id: "eid179", tween: [ "style", "${_joeRoach}", "top", '-103px', { fromValue: '-81px'}], position: 0, duration: 221 },
            { id: "eid182", tween: [ "style", "${_joeRoach}", "top", '-105px', { fromValue: '-103px'}], position: 221, duration: 226 },
            { id: "eid185", tween: [ "style", "${_joeRoach}", "top", '-65px', { fromValue: '-105px'}], position: 447, duration: 209 },
            { id: "eid191", tween: [ "style", "${_joeRoach}", "top", '51.93px', { fromValue: '-65px'}], position: 656, duration: 254 },
            { id: "eid194", tween: [ "style", "${_joeRoach}", "top", '94.92px', { fromValue: '51.93px'}], position: 910, duration: 165 },
            { id: "eid198", tween: [ "style", "${_joeRoach}", "top", '183.92px', { fromValue: '94.92px'}], position: 1076, duration: 232 },
            { id: "eid201", tween: [ "style", "${_joeRoach}", "top", '185.92px', { fromValue: '183.92px'}], position: 1308, duration: 176 },
            { id: "eid204", tween: [ "style", "${_joeRoach}", "top", '94.92px', { fromValue: '185.92px'}], position: 1484, duration: 117 },
            { id: "eid206", tween: [ "style", "${_joeRoach}", "top", '53.35px', { fromValue: '94.92px'}], position: 1602, duration: 254 },
            { id: "eid209", tween: [ "style", "${_joeRoach}", "top", '18.35px', { fromValue: '53.35px'}], position: 1856, duration: 492 },
            { id: "eid212", tween: [ "style", "${_joeRoach}", "top", '-66.65px', { fromValue: '18.35px'}], position: 2348, duration: 188 },
            { id: "eid215", tween: [ "style", "${_joeRoach}", "top", '-102.65px', { fromValue: '-66.65px'}], position: 2536, duration: 213 },
            { id: "eid155", tween: [ "transform", "${_fredRoach}", "rotateZ", '30deg', { fromValue: '0deg'}], position: 0, duration: 1076 },
            { id: "eid158", tween: [ "transform", "${_fredRoach}", "rotateZ", '104deg', { fromValue: '30deg'}], position: 1076, duration: 493 },
            { id: "eid161", tween: [ "transform", "${_fredRoach}", "rotateZ", '158deg', { fromValue: '104deg'}], position: 1569, duration: 430 },
            { id: "eid163", tween: [ "transform", "${_fredRoach}", "rotateZ", '182deg', { fromValue: '158deg'}], position: 2000, duration: 250 },
            { id: "eid165", tween: [ "transform", "${_fredRoach}", "rotateZ", '265deg', { fromValue: '182deg'}], position: 2250, duration: 98 },
            { id: "eid175", tween: [ "transform", "${_fredRoach}", "rotateZ", '360deg', { fromValue: '265deg'}], position: 2348, duration: 401 },
            { id: "eid180", tween: [ "transform", "${_joeRoach}", "rotateZ", '-93deg', { fromValue: '-46deg'}], position: 0, duration: 221 },
            { id: "eid183", tween: [ "transform", "${_joeRoach}", "rotateZ", '-126deg', { fromValue: '-93deg'}], position: 221, duration: 226 },
            { id: "eid186", tween: [ "transform", "${_joeRoach}", "rotateZ", '-168deg', { fromValue: '-126deg'}], position: 447, duration: 209 },
            { id: "eid192", tween: [ "transform", "${_joeRoach}", "rotateZ", '-185deg', { fromValue: '-168deg'}], position: 656, duration: 254 },
            { id: "eid195", tween: [ "transform", "${_joeRoach}", "rotateZ", '-127deg', { fromValue: '-185deg'}], position: 910, duration: 165 },
            { id: "eid196", tween: [ "transform", "${_joeRoach}", "rotateZ", '-189deg', { fromValue: '-127deg'}], position: 1076, duration: 232 },
            { id: "eid199", tween: [ "transform", "${_joeRoach}", "rotateZ", '-250deg', { fromValue: '-189deg'}], position: 1308, duration: 176 },
            { id: "eid202", tween: [ "transform", "${_joeRoach}", "rotateZ", '-296deg', { fromValue: '-250deg'}], position: 1484, duration: 117 },
            { id: "eid207", tween: [ "transform", "${_joeRoach}", "rotateZ", '-403deg', { fromValue: '-296deg'}], position: 1602, duration: 746 },
            { id: "eid210", tween: [ "transform", "${_joeRoach}", "rotateZ", '-305deg', { fromValue: '-403deg'}], position: 2348, duration: 188 },
            { id: "eid213", tween: [ "transform", "${_joeRoach}", "rotateZ", '-406deg', { fromValue: '-305deg'}], position: 2536, duration: 213 },
            { id: "eid109", trigger: [ function executeSymbolFunction(e, data) { this._executeSymbolAction(e, data); }, ['play', '${_fredRoach}', [] ], ""], position: 0 },
            { id: "eid216", trigger: [ function executeSymbolFunction(e, data) { this._executeSymbolAction(e, data); }, ['stop', '${_fredRoach}', [] ], ""], position: 2750 }         ]
      }
   }
},
"Antenna": {
   version: "0.1.7",
   minimumCompatibleVersion: "0.1.7",
   build: "0.11.0.153",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: true,
   resizeInstances: false,
   content: {
   dom: [
   {
      transform: [[0,0],[0,0],[0],[1,1]],
      borderRadius: ['0px 0px','29px 88px','29px 88px','0px 0px'],
      rect: [3,0,33,182],
      id: 'RoundRect',
      stroke: [0,'rgba(0,0,0,1)','none'],
      type: 'rect',
      fill: ['rgba(0,0,0,1.00)',null]
   },
   {
      rect: [0,null,33,182],
      borderRadius: ['0px 0px','29px 88px','29px 88px','0px 0px'],
      transform: [[0,0]],
      id: 'RoundRectCopy',
      stroke: [0,'rgba(0,0,0,1)','none'],
      type: 'rect',
      fill: ['rgba(255,255,255,1.00)',null]
   }],
   symbolInstances: [
   ]
   },
   states: {
      "Base State": {
         "${_RoundRectCopy}": [
            ["color", "background-color", 'rgba(255,255,255,1.00)'],
            ["style", "border-top-left-radius", [0,0], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["style", "border-bottom-right-radius", [29,88], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["style", "left", '0px'],
            ["style", "border-bottom-left-radius", [0,0], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["style", "border-top-right-radius", [29,88], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["style", "width", '33px']
         ],
         "${_RoundRect}": [
            ["color", "background-color", 'rgba(0,0,0,1.00)'],
            ["style", "border-top-left-radius", [0,0], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["style", "border-bottom-right-radius", [29,88], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["style", "left", '3px'],
            ["style", "border-bottom-left-radius", [0,0], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["style", "border-top-right-radius", [29,88], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["style", "width", '33px']
         ],
         "${symbolSelector}": [
            ["style", "height", '182px'],
            ["style", "width", '36px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 1500,
         autoPlay: true,
         timeline: [
         ]
      }
   }
},
"Body": {
   version: "0.1.7",
   minimumCompatibleVersion: "0.1.7",
   build: "0.11.0.153",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: true,
   resizeInstances: false,
   content: {
   dom: [
   {
      transform: [[0,0],[0,0],[0],[1,1]],
      borderRadius: ['45px 86px','45px 86px','45px 86px','45px 86px'],
      rect: [0,0,100,200],
      id: 'RoundRect2',
      stroke: [0,'rgb(0, 0, 0)','none'],
      type: 'rect',
      fill: ['rgba(70,60,27,1.00)',null]
   }],
   symbolInstances: [
   ]
   },
   states: {
      "Base State": {
         "${symbolSelector}": [
            ["style", "height", '200px'],
            ["style", "width", '100px']
         ],
         "${_RoundRect2}": [
            ["color", "background-color", 'rgba(70,60,27,1.00)'],
            ["style", "border-top-left-radius", [45,86], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["style", "border-bottom-right-radius", [45,86], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["style", "border-top-right-radius", [45,86], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["style", "width", '100px'],
            ["style", "top", '0px'],
            ["style", "border-bottom-left-radius", [45,86], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["style", "height", '200px'],
            ["style", "left", '0px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 1500,
         autoPlay: true,
         timeline: [
         ]
      }
   }
},
"Leg": {
   version: "0.1.7",
   minimumCompatibleVersion: "0.1.7",
   build: "0.11.0.153",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: true,
   resizeInstances: false,
   content: {
   dom: [
   {
      rect: [6,1,6,42],
      transform: [[0,0],[-18]],
      id: 'Rectangle3Copy2',
      stroke: [0,'rgb(0, 0, 0)','none'],
      type: 'rect',
      fill: ['rgba(0,0,0,1)']
   },
   {
      rect: [21,59,6,53],
      borderRadius: ['0px 10px','0px 10px','0px 10px','0px 10px'],
      transform: [[0,0],[-33]],
      id: 'Rectangle3Copy',
      stroke: [0,'rgb(0, 0, 0)','none'],
      type: 'rect',
      fill: ['rgba(0,0,0,1)']
   },
   {
      rect: [10,39,6,26],
      transform: [[0,0],[9]],
      id: 'Rectangle3',
      stroke: [0,'rgb(0, 0, 0)','none'],
      type: 'rect',
      fill: ['rgba(0,0,0,1)']
   }],
   symbolInstances: [
   ]
   },
   states: {
      "Base State": {
         "${_Rectangle3Copy2}": [
            ["style", "top", '1.65px'],
            ["style", "left", '6.16px'],
            ["transform", "rotateZ", '-18deg']
         ],
         "${_Rectangle3}": [
            ["style", "height", '26px'],
            ["style", "top", '39.61px'],
            ["style", "left", '10.87px'],
            ["transform", "rotateZ", '9deg']
         ],
         "${_Rectangle3Copy}": [
            ["style", "top", '59.46px'],
            ["style", "border-top-left-radius", [0,10], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["style", "left", '21.07px'],
            ["transform", "rotateZ", '-33deg'],
            ["style", "height", '53px'],
            ["style", "border-bottom-right-radius", [0,10], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["style", "border-top-right-radius", [0,10], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["style", "border-bottom-left-radius", [0,10], {valueTemplate:'@@0@@px @@1@@px'} ]
         ],
         "${symbolSelector}": [
            ["style", "height", '107.988646px'],
            ["style", "width", '38.478173px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 0,
         autoPlay: true,
         timeline: [
         ]
      }
   }
},
"Roach": {
   version: "0.1.7",
   minimumCompatibleVersion: "0.1.7",
   build: "0.11.0.153",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: true,
   resizeInstances: false,
   content: {
   dom: [
   {
      id: 'legLeftRear',
      type: 'rect',
      transform: [[0,0],[56]],
      rect: [87,254,0,0]
   },
   {
      id: 'legLeftMiddle',
      type: 'rect',
      transform: [[0,0],[-109]],
      rect: [73,101,0,0]
   },
   {
      id: 'legLeftFront',
      type: 'rect',
      transform: [[0,0],[-106]],
      rect: [75,98,0,0]
   },
   {
      id: 'legRightRear',
      type: 'rect',
      transform: [[0,0],[-49]],
      rect: [157,252,0,0]
   },
   {
      id: 'legRightMiddle',
      type: 'rect',
      transform: [[0,0],[-52]],
      rect: [161,214,0,0]
   },
   {
      id: 'legRightFront',
      type: 'rect',
      transform: [[0,0],[-134]],
      rect: [159,206,0,0]
   },
   {
      id: 'antennaRight',
      type: 'rect',
      transform: [[0,0],[192],{},[0.6538,0.6538]],
      rect: [142,-18,0,0]
   },
   {
      id: 'antennaLeft',
      type: 'rect',
      transform: [[0,0],[-22],{},[0.5439,0.5439]],
      rect: [85,-41,0,0]
   },
   {
      id: 'bugBody',
      type: 'rect',
      transform: [[0,0]],
      rect: [84,143,0,0]
   },
   {
      id: 'bugHead',
      type: 'rect',
      transform: [[0,0],{},{},[0.6699,0.49]],
      rect: [84,18,0,0]
   },
   {
      rect: [210,99,11,9],
      transform: [[0,0]],
      id: 'Rectangle',
      stroke: [0,'rgba(0,0,0,1)','none'],
      type: 'rect',
      fill: ['rgba(192,192,192,1)']
   },
   {
      rect: [274,251,11,9],
      transform: [[0,0]],
      id: 'RectangleCopy',
      stroke: [0,'rgba(0,0,0,1)','none'],
      type: 'rect',
      fill: ['rgba(192,192,192,1)']
   },
   {
      rect: [268,292,11,9],
      transform: [[0,0]],
      id: 'RectangleCopy2',
      stroke: [0,'rgba(0,0,0,1)','none'],
      type: 'rect',
      fill: ['rgba(192,192,192,1)']
   },
   {
      rect: [47,94,11,9],
      transform: [[0,0]],
      id: 'RectangleCopy3',
      stroke: [0,'rgba(0,0,0,1)','none'],
      type: 'rect',
      fill: ['rgba(192,192,192,1)']
   },
   {
      rect: [11,278,11,9],
      transform: [[0,0]],
      id: 'RectangleCopy4',
      stroke: [0,'rgba(0,0,0,1)','none'],
      type: 'rect',
      fill: ['rgba(192,192,192,1)']
   },
   {
      rect: [16,347,11,9],
      transform: [[0,0]],
      id: 'RectangleCopy5',
      stroke: [0,'rgba(0,0,0,1)','none'],
      type: 'rect',
      fill: ['rgba(192,192,192,1)']
   }],
   symbolInstances: [
   {
      id: 'legLeftMiddle',
      symbolName: 'Leg'
   },
   {
      id: 'bugHead',
      symbolName: 'Body'
   },
   {
      id: 'legLeftRear',
      symbolName: 'Leg'
   },
   {
      id: 'legRightMiddle',
      symbolName: 'Leg'
   },
   {
      id: 'antennaLeft',
      symbolName: 'Antenna'
   },
   {
      id: 'legRightFront',
      symbolName: 'Leg'
   },
   {
      id: 'bugBody',
      symbolName: 'Body'
   },
   {
      id: 'legLeftFront',
      symbolName: 'Leg'
   },
   {
      id: 'antennaRight',
      symbolName: 'Antenna'
   },
   {
      id: 'legRightRear',
      symbolName: 'Leg'
   }   ]
   },
   states: {
      "Base State": {
         "${_bugBody}": [
            ["style", "left", '84px'],
            ["style", "top", '143px']
         ],
         "${_bugHead}": [
            ["transform", "scaleX", '0.669'],
            ["style", "left", '83.5px'],
            ["transform", "scaleY", '0.49'],
            ["style", "top", '18px']
         ],
         "${_antennaLeft}": [
            ["style", "top", '-41.49px'],
            ["transform", "scaleY", '0.543'],
            ["transform", "rotateZ", '-22deg'],
            ["transform", "scaleX", '0.543'],
            ["style", "left", '84.8px']
         ],
         "${_legRightFront}": [
            ["style", "-webkit-transform-origin", [8.75,6.3], {valueTemplate:'@@0@@% @@1@@%'} ],
            ["style", "-moz-transform-origin", [8.75,6.3],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "-ms-transform-origin", [8.75,6.3],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "msTransformOrigin", [8.75,6.3],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "-o-transform-origin", [8.75,6.3],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "top", '205.26px'],
            ["style", "left", '158.68px'],
            ["transform", "rotateZ", '-134deg']
         ],
         "${_RectangleCopy5}": [
            ["style", "-webkit-transform-origin", [95.95,54.62], {valueTemplate:'@@0@@% @@1@@%'} ],
            ["style", "-moz-transform-origin", [95.95,54.62],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "-ms-transform-origin", [95.95,54.62],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "msTransformOrigin", [95.95,54.62],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "-o-transform-origin", [95.95,54.62],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "left", '15.34px'],
            ["style", "top", '347.3px']
         ],
         "${_legRightMiddle}": [
            ["style", "-webkit-transform-origin", [8.89,6.55], {valueTemplate:'@@0@@% @@1@@%'} ],
            ["style", "-moz-transform-origin", [8.89,6.55],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "-ms-transform-origin", [8.89,6.55],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "msTransformOrigin", [8.89,6.55],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "-o-transform-origin", [8.89,6.55],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "top", '213.99px'],
            ["style", "left", '160.62px'],
            ["transform", "rotateZ", '-52deg']
         ],
         "${_RectangleCopy}": [
            ["style", "top", '251.05px'],
            ["style", "left", '274.49px']
         ],
         "${symbolSelector}": [
            ["style", "height", '352.135484px'],
            ["style", "width", '263.901905px']
         ],
         "${_Rectangle}": [
            ["style", "left", '210px'],
            ["style", "top", '99px']
         ],
         "${_legRightRear}": [
            ["style", "-webkit-transform-origin", [0,0], {valueTemplate:'@@0@@% @@1@@%'} ],
            ["style", "-moz-transform-origin", [0,0],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "-ms-transform-origin", [0,0],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "msTransformOrigin", [0,0],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "-o-transform-origin", [0,0],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "top", '251.21px'],
            ["style", "left", '156.63px'],
            ["transform", "rotateZ", '-49deg']
         ],
         "${_RectangleCopy3}": [
            ["style", "-webkit-transform-origin", [95.95,54.62], {valueTemplate:'@@0@@% @@1@@%'} ],
            ["style", "-moz-transform-origin", [95.95,54.62],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "-ms-transform-origin", [95.95,54.62],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "msTransformOrigin", [95.95,54.62],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "-o-transform-origin", [95.95,54.62],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "left", '47.33px'],
            ["style", "top", '94.3px']
         ],
         "${_legLeftRear}": [
            ["style", "-webkit-transform-origin", [14.19,5.51], {valueTemplate:'@@0@@% @@1@@%'} ],
            ["style", "-moz-transform-origin", [14.19,5.51],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "-ms-transform-origin", [14.19,5.51],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "msTransformOrigin", [14.19,5.51],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "-o-transform-origin", [14.19,5.51],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "top", '253.11px'],
            ["style", "left", '87.6px'],
            ["transform", "rotateZ", '56deg']
         ],
         "${_legLeftFront}": [
            ["style", "-webkit-transform-origin", [100,100], {valueTemplate:'@@0@@% @@1@@%'} ],
            ["style", "-moz-transform-origin", [100,100],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "-ms-transform-origin", [100,100],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "msTransformOrigin", [100,100],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "-o-transform-origin", [100,100],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "top", '97.09px'],
            ["style", "left", '75.55px'],
            ["transform", "rotateZ", '-10deg']
         ],
         "${_RectangleCopy2}": [
            ["style", "-webkit-transform-origin", [95.95,54.62], {valueTemplate:'@@0@@% @@1@@%'} ],
            ["style", "-moz-transform-origin", [95.95,54.62],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "-ms-transform-origin", [95.95,54.62],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "msTransformOrigin", [95.95,54.62],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "-o-transform-origin", [95.95,54.62],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "left", '268.56px'],
            ["style", "top", '292.81px']
         ],
         "${_antennaRight}": [
            ["style", "top", '-18.49px'],
            ["transform", "scaleY", '0.653'],
            ["transform", "rotateZ", '192deg'],
            ["transform", "scaleX", '0.653'],
            ["style", "left", '141.77px']
         ],
         "${_RectangleCopy4}": [
            ["style", "-webkit-transform-origin", [95.95,54.62], {valueTemplate:'@@0@@% @@1@@%'} ],
            ["style", "-moz-transform-origin", [95.95,54.62],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "-ms-transform-origin", [95.95,54.62],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "msTransformOrigin", [95.95,54.62],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "-o-transform-origin", [95.95,54.62],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "left", '10.34px'],
            ["style", "top", '278.3px']
         ],
         "${_legLeftMiddle}": [
            ["style", "-webkit-transform-origin", [100,100], {valueTemplate:'@@0@@% @@1@@%'} ],
            ["style", "-moz-transform-origin", [100,100],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "-ms-transform-origin", [100,100],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "msTransformOrigin", [100,100],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "-o-transform-origin", [100,100],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "top", '100.12px'],
            ["style", "left", '73.39px'],
            ["transform", "rotateZ", '-109deg']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 1000,
         autoPlay: true,
         timeline: [
            { id: "eid13", tween: [ "transform", "${_legRightMiddle}", "rotateZ", '-34deg', { fromValue: '-52deg'}], position: 0, duration: 333 },
            { id: "eid18", tween: [ "transform", "${_legRightMiddle}", "rotateZ", '-63deg', { fromValue: '-34deg'}], position: 333, duration: 333 },
            { id: "eid27", tween: [ "transform", "${_legRightMiddle}", "rotateZ", '-33deg', { fromValue: '-63deg'}], position: 666, duration: 333 },
            { id: "eid11", tween: [ "transform", "${_legLeftRear}", "rotateZ", '84deg', { fromValue: '56deg'}], position: 0, duration: 333 },
            { id: "eid15", tween: [ "transform", "${_legLeftRear}", "rotateZ", '61deg', { fromValue: '84deg'}], position: 333, duration: 333 },
            { id: "eid24", tween: [ "transform", "${_legLeftRear}", "rotateZ", '81deg', { fromValue: '61deg'}], position: 666, duration: 333 },
            { id: "eid12", tween: [ "transform", "${_legRightRear}", "rotateZ", '-28deg', { fromValue: '-49deg'}], position: 0, duration: 483 },
            { id: "eid19", tween: [ "transform", "${_legRightRear}", "rotateZ", '-56deg', { fromValue: '-28deg'}], position: 483, duration: 391 },
            { id: "eid26", tween: [ "transform", "${_legRightRear}", "rotateZ", '-23deg', { fromValue: '-56deg'}], position: 874, duration: 125 },
            { id: "eid8", tween: [ "transform", "${_legLeftFront}", "rotateZ", '-56deg', { fromValue: '-10deg'}], position: 0, duration: 500 },
            { id: "eid14", tween: [ "transform", "${_legLeftFront}", "rotateZ", '-4deg', { fromValue: '-56deg'}], position: 500, duration: 250 },
            { id: "eid22", tween: [ "transform", "${_legLeftFront}", "rotateZ", '-51deg', { fromValue: '-4deg'}], position: 750, duration: 148 },
            { id: "eid31", tween: [ "transform", "${_legLeftFront}", "rotateZ", '-8deg', { fromValue: '-51deg'}], position: 898, duration: 101 },
            { id: "eid9", tween: [ "transform", "${_legRightFront}", "rotateZ", '-113deg', { fromValue: '-134deg'}], position: 0, duration: 333 },
            { id: "eid17", tween: [ "transform", "${_legRightFront}", "rotateZ", '-94deg', { fromValue: '-113deg'}], position: 333, duration: 333 },
            { id: "eid25", tween: [ "transform", "${_legRightFront}", "rotateZ", '-135deg', { fromValue: '-94deg'}], position: 666, duration: 208 },
            { id: "eid33", tween: [ "transform", "${_legRightFront}", "rotateZ", '-131deg', { fromValue: '-135deg'}], position: 874, duration: 125 },
            { id: "eid10", tween: [ "transform", "${_legLeftMiddle}", "rotateZ", '-88deg', { fromValue: '-109deg'}], position: 0, duration: 177 },
            { id: "eid16", tween: [ "transform", "${_legLeftMiddle}", "rotateZ", '-108deg', { fromValue: '-88deg'}], position: 177, duration: 198 },
            { id: "eid23", tween: [ "transform", "${_legLeftMiddle}", "rotateZ", '-73deg', { fromValue: '-108deg'}], position: 376, duration: 623 }         ]
      }
   }
}
};


Edge.registerCompositionDefn(compId, symbols, fonts, resources);

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     Edge.launchComposition(compId);
});
})(jQuery, AdobeEdge, "EDGE-65759929");
