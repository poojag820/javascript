/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
var im='images/';

var fonts = {};


var resources = [
];
var symbols = {
"stage": {
   version: "0.1.7",
   minimumCompatibleVersion: "0.1.7",
   build: "0.11.0.161",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
         dom: [
         {
            id:'flowerStrip',
            type:'image',
            rect:['0','0','2500','375','undefined','undefined'],
            fill:["rgba(0,0,0,0)",im+"flowerStrip375x2500.jpg"],
            transform:[]
         },
         {
            id:'NextFlower',
            type:'group',
            rect:['250px','375px','250','50','auto','auto'],
            cursor:['pointer'],
            c:[
            {
               id:'RectangleCopy',
               type:'rect',
               rect:['0px','0px','250px','50px','auto','auto'],
               fill:["rgba(192,192,192,1)"],
               stroke:[0,"rgba(0,0,0,1)","none"]
            },
            {
               id:'Text2',
               type:'text',
               rect:['61px','11px','150px','29px','auto','auto'],
               text:"Next Flower",
               align:"left",
               font:['Verdana, Geneva, sans-serif',24,"rgba(255,255,255,1.00)","normal","none","normal"],
               textShadow:["rgba(0,0,0,0.65)",3,3,3]
            }]
         },
         {
            id:'StartOver',
            type:'group',
            rect:['0','375','250','50','auto','auto'],
            cursor:['pointer'],
            c:[
            {
               id:'Rectangle',
               type:'rect',
               rect:['0px','0px','250px','50px','auto','auto'],
               fill:["rgba(192,192,192,1)"],
               stroke:[0,"rgba(0,0,0,1)","none"]
            },
            {
               id:'Text',
               type:'text',
               rect:['70px','11px','auto','auto','auto','auto'],
               text:"Start Over",
               font:['Verdana, Geneva, sans-serif',24,"rgba(255,255,255,1.00)","normal","none",""],
               textShadow:["rgba(0,0,0,0.65)",3,3,3]
            }]
         },
         {
            id:'hsPoppy',
            type:'rect',
            rect:['119','114','auto','auto','auto','auto']
         },
         {
            id:'hsRose',
            display:'none',
            type:'rect',
            rect:['184px','137px','auto','auto','auto','auto'],
            opacity:0.94,
            transform:[[],[],[],['2.437','2.233']]
         },
         {
            id:'coDaisy',
            display:'none',
            type:'group',
            rect:['268','319','203','50','auto','auto'],
            c:[
            {
               id:'bgDaisy',
               type:'rect',
               rect:['0px','0px','203px','50px','auto','auto'],
               opacity:0.5,
               fill:["rgba(255,255,255,1)"],
               stroke:[0,"rgb(0, 0, 0)","none"]
            },
            {
               id:'tbDaisy',
               type:'text',
               rect:['15px','0px','183px','auto','auto','auto'],
               text:"It's a Daisy",
               align:"left",
               font:['\'Arial Black\', Gadget, sans-serif',30,"rgba(255,255,255,1)","normal","none","normal"],
               textShadow:["rgba(0,0,0,0.65)",4,4,6]
            }]
         },
         {
            id:'coLilac',
            display:'none',
            type:'group',
            rect:['285','63','216','50','auto','auto'],
            c:[
            {
               id:'bgLilac',
               type:'rect',
               rect:['0px','0px','216px','50px','auto','auto'],
               opacity:0.5,
               fill:["rgba(255,255,255,1)"],
               stroke:[0,"rgb(0, 0, 0)","none"]
            },
            {
               id:'tbLilac',
               type:'text',
               rect:['7px','4px','201px','42px','auto','auto'],
               text:"Lovely Lilac",
               align:"left",
               font:['\'Arial Black\', Gadget, sans-serif',30,"rgba(255,255,255,1)","normal","none","normal"],
               textShadow:["rgba(0,0,0,0.65)",4,4,6]
            }]
         },
         {
            id:'coTigerLily',
            display:'none',
            type:'group',
            rect:['145','19','216','64','auto','auto'],
            c:[
            {
               id:'bgTigerLily',
               type:'rect',
               rect:['0px','0px','216px','64px','auto','auto'],
               opacity:0.5,
               fill:["rgba(255,255,255,1)"],
               stroke:[0,"rgb(0, 0, 0)","none"]
            },
            {
               id:'tbTigerLily',
               type:'text',
               rect:['16px','12px','191px','42px','auto','auto'],
               text:"Tiger Lilies",
               align:"left",
               font:['\'Arial Black\', Gadget, sans-serif',30,"rgba(255,255,255,1)","normal","none","normal"],
               textShadow:["rgba(0,0,0,0.65)",4,4,6]
            }]
         },
         {
            id:'coRose',
            display:'none',
            type:'group',
            rect:['230','5','225','50','auto','auto'],
            c:[
            {
               id:'bgRose',
               type:'rect',
               rect:['0px','0px','225px','50px','auto','auto'],
               opacity:0.5,
               fill:["rgba(255,255,255,1)"],
               stroke:[0,"rgb(0, 0, 0)","none"]
            },
            {
               id:'tbRose',
               type:'text',
               rect:['15px','4px','202px','40px','auto','auto'],
               text:"A Pink Rose",
               align:"left",
               font:['\'Arial Black\', Gadget, sans-serif',30,"rgba(255,255,255,1)","normal","none","normal"],
               textShadow:["rgba(0,0,0,0.65)",4,4,6]
            }]
         },
         {
            id:'coPoppy',
            display:'none',
            type:'group',
            rect:['217','64','258','50','auto','auto'],
            c:[
            {
               id:'bgPoppy',
               type:'rect',
               rect:['0px','0px','258px','50px','auto','auto'],
               opacity:0.5,
               fill:["rgba(255,255,255,1)"],
               stroke:[0,"rgb(0, 0, 0)","none"]
            },
            {
               id:'tbPoppy',
               type:'text',
               rect:['10px','0px','240px','50px','auto','auto'],
               text:"Iceland Poppy",
               font:['Arial Black, Gadget, sans-serif',30,"rgba(255,255,255,1.00)","normal","none",""],
               textShadow:["rgba(0,0,0,0.65)",4,4,6]
            }]
         },
         {
            id:'hsDaisy',
            display:'none',
            type:'rect',
            rect:['197px','129px','auto','auto','auto','auto'],
            transform:[[],[],[],['2.704','2.67']]
         },
         {
            id:'hsLilac',
            display:'none',
            type:'rect',
            rect:['149px','124px','auto','auto','auto','auto'],
            transform:[[],[],[],['2.704','3.153']]
         },
         {
            id:'hsTigerLily',
            display:'none',
            type:'rect',
            rect:['99px','129px','auto','auto','auto','auto'],
            transform:[[],[],[],['1.33','1.405']]
         },
         {
            id:'hsTigerLily2',
            display:'none',
            type:'rect',
            rect:['342px','163px','auto','auto','auto','auto'],
            transform:[[],[],[],['1.582','1.75']]
         }],
         symbolInstances: [
         {
            id:'hsPoppy',
            symbolName:'hotspot'
         },
         {
            id:'hsLilac',
            symbolName:'hotspot'
         },
         {
            id:'hsTigerLily2',
            symbolName:'hotspot'
         },
         {
            id:'hsRose',
            symbolName:'hotspot'
         },
         {
            id:'hsTigerLily',
            symbolName:'hotspot'
         },
         {
            id:'hsDaisy',
            symbolName:'hotspot'
         }
         ]
      },
   states: {
      "Base State": {
         "${_NextFlower}": [
            ["style", "cursor", 'pointer']
         ],
         "${_tbLilac}": [
            ["style", "top", '4px'],
            ["subproperty", "textShadow.offsetH", '4px'],
            ["subproperty", "textShadow.blur", '6px'],
            ["subproperty", "textShadow.offsetV", '4px'],
            ["style", "height", '41.82421875px'],
            ["subproperty", "textShadow.color", 'rgba(0,0,0,0.65)'],
            ["style", "left", '6.88px'],
            ["style", "width", '201.41667175293px']
         ],
         "${_coPoppy}": [
            ["style", "display", 'none']
         ],
         "${_Text2}": [
            ["subproperty", "textShadow.blur", '3px'],
            ["subproperty", "textShadow.offsetH", '3px'],
            ["color", "color", 'rgba(255,255,255,1.00)'],
            ["subproperty", "textShadow.offsetV", '3px'],
            ["style", "left", '61px'],
            ["style", "width", '149.98333740234px'],
            ["style", "top", '11px'],
            ["style", "height", '29px'],
            ["style", "font-family", 'Verdana, Geneva, sans-serif'],
            ["subproperty", "textShadow.color", 'rgba(0,0,0,0.65)']
         ],
         "${_hsPoppy}": [
            ["style", "display", 'block']
         ],
         "${_StartOver}": [
            ["style", "cursor", 'pointer']
         ],
         "${_hsRose}": [
            ["style", "top", '137.46px'],
            ["transform", "scaleY", '2.23332'],
            ["transform", "scaleX", '2.43735'],
            ["style", "opacity", '0.94'],
            ["style", "left", '183.54px'],
            ["style", "display", 'none']
         ],
         "${_RectangleCopy}": [
            ["style", "top", '0px'],
            ["style", "left", '0px'],
            ["style", "width", '250px']
         ],
         "${_flowerStrip}": [
            ["style", "left", '0px'],
            ["style", "top", '0px']
         ],
         "${_hsTigerLily}": [
            ["style", "top", '128.97px'],
            ["transform", "scaleY", '1.40507'],
            ["transform", "scaleX", '1.33045'],
            ["style", "left", '99.27px'],
            ["style", "display", 'none']
         ],
         "${_Rectangle}": [
            ["style", "top", '0px'],
            ["style", "width", '250px']
         ],
         "${_hsTigerLily2}": [
            ["style", "top", '162.81px'],
            ["transform", "scaleY", '1.74968'],
            ["transform", "scaleX", '1.58221'],
            ["style", "left", '341.64px'],
            ["style", "display", 'none']
         ],
         "${_Stage}": [
            ["color", "background-color", 'rgba(0,0,0,1.00)'],
            ["style", "overflow", 'hidden'],
            ["style", "height", '425px'],
            ["style", "width", '500px']
         ],
         "${_coTigerLily}": [
            ["style", "display", 'none']
         ],
         "${_bgLilac}": [
            ["style", "top", '0.02px'],
            ["style", "height", '50px'],
            ["style", "opacity", '0.5'],
            ["style", "left", '0px'],
            ["style", "width", '215.55000305176px']
         ],
         "${_tbDaisy}": [
            ["subproperty", "textShadow.blur", '6px'],
            ["subproperty", "textShadow.offsetH", '4px'],
            ["style", "top", '0px'],
            ["subproperty", "textShadow.offsetV", '4px'],
            ["subproperty", "textShadow.color", 'rgba(0,0,0,0.65)'],
            ["style", "left", '15px'],
            ["style", "width", '183.4921875px']
         ],
         "${_Text}": [
            ["style", "top", '11px'],
            ["subproperty", "textShadow.offsetH", '3px'],
            ["subproperty", "textShadow.blur", '3px'],
            ["subproperty", "textShadow.color", 'rgba(0,0,0,0.65)'],
            ["color", "color", 'rgba(255,255,255,1.00)'],
            ["style", "font-family", 'Verdana, Geneva, sans-serif'],
            ["style", "left", '70px'],
            ["subproperty", "textShadow.offsetV", '3px']
         ],
         "${_tbPoppy}": [
            ["subproperty", "textShadow.blur", '6px'],
            ["subproperty", "textShadow.offsetH", '4px'],
            ["color", "color", 'rgba(255,255,255,1.00)'],
            ["subproperty", "textShadow.offsetV", '4px'],
            ["style", "left", '10.07px'],
            ["style", "font-size", '30px'],
            ["style", "top", '0px'],
            ["style", "width", '240.2166595459px'],
            ["style", "display", 'block'],
            ["style", "font-family", 'Arial Black, Gadget, sans-serif'],
            ["style", "height", '50px'],
            ["subproperty", "textShadow.color", 'rgba(0,0,0,0.65)']
         ],
         "${_bgRose}": [
            ["style", "top", '0px'],
            ["style", "opacity", '0.5'],
            ["style", "left", '0px']
         ],
         "${_tbTigerLily}": [
            ["subproperty", "textShadow.blur", '6px'],
            ["subproperty", "textShadow.offsetH", '4px'],
            ["style", "top", '12.33px'],
            ["subproperty", "textShadow.offsetV", '4px'],
            ["style", "height", '42.21484375px'],
            ["subproperty", "textShadow.color", 'rgba(0,0,0,0.65)'],
            ["style", "left", '16.18px'],
            ["style", "width", '190.51666259766px']
         ],
         "${_bgTigerLily}": [
            ["style", "top", '0px'],
            ["style", "opacity", '0.5'],
            ["style", "left", '0px']
         ],
         "${_tbRose}": [
            ["subproperty", "textShadow.blur", '6px'],
            ["subproperty", "textShadow.offsetH", '4px'],
            ["style", "top", '4px'],
            ["subproperty", "textShadow.offsetV", '4px'],
            ["style", "height", '40.34375px'],
            ["subproperty", "textShadow.color", 'rgba(0,0,0,0.65)'],
            ["style", "left", '15px'],
            ["style", "width", '202.25px']
         ],
         "${_bgDaisy}": [
            ["style", "top", '0px'],
            ["style", "opacity", '0.5'],
            ["style", "left", '0px']
         ],
         "${_bgPoppy}": [
            ["style", "top", '0px'],
            ["style", "opacity", '0.5'],
            ["style", "left", '0px'],
            ["style", "height", '50px']
         ],
         "${_hsLilac}": [
            ["style", "top", '124.46px'],
            ["transform", "scaleY", '3.15268'],
            ["transform", "scaleX", '2.70416'],
            ["style", "left", '148.77px'],
            ["style", "display", 'none']
         ],
         "${_coDaisy}": [
            ["style", "display", 'none']
         ],
         "${_coLilac}": [
            ["style", "display", 'none']
         ],
         "${_hsDaisy}": [
            ["style", "top", '128.91px'],
            ["transform", "scaleY", '2.66994'],
            ["transform", "scaleX", '2.70416'],
            ["style", "left", '197.23px'],
            ["style", "display", 'none']
         ],
         "${_coRose}": [
            ["style", "display", 'none']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 7500,
         autoPlay: true,
         labels: {
            "poppy": 0,
            "rose": 1500,
            "daisy": 3000,
            "lilac": 4500,
            "tigerLilly": 6000
         },
         timeline: [
            { id: "eid116", tween: [ "style", "${_hsPoppy}", "display", 'block', { fromValue: 'block'}], position: 0, duration: 0 },
            { id: "eid117", tween: [ "style", "${_hsPoppy}", "display", 'none', { fromValue: 'block'}], position: 1000, duration: 0 },
            { id: "eid124", tween: [ "style", "${_hsTigerLily2}", "display", 'block', { fromValue: 'none'}], position: 6000, duration: 0 },
            { id: "eid126", tween: [ "style", "${_hsTigerLily2}", "display", 'none', { fromValue: 'block'}], position: 7000, duration: 0 },
            { id: "eid128", tween: [ "style", "${_tbPoppy}", "display", 'block', { fromValue: 'block'}], position: 0, duration: 0 },
            { id: "eid131", tween: [ "style", "${_coRose}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid120", tween: [ "style", "${_hsDaisy}", "display", 'block', { fromValue: 'none'}], position: 3000, duration: 0 },
            { id: "eid121", tween: [ "style", "${_hsDaisy}", "display", 'none', { fromValue: 'block'}], position: 4000, duration: 0 },
            { id: "eid132", tween: [ "style", "${_coDaisy}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid133", tween: [ "style", "${_coLilac}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid1", tween: [ "style", "${_flowerStrip}", "left", '-500px', { fromValue: '0px'}], position: 1000, duration: 500 },
            { id: "eid2", tween: [ "style", "${_flowerStrip}", "left", '-1000px', { fromValue: '-500px'}], position: 2500, duration: 500 },
            { id: "eid3", tween: [ "style", "${_flowerStrip}", "left", '-1500px', { fromValue: '-1000px'}], position: 4000, duration: 500 },
            { id: "eid4", tween: [ "style", "${_flowerStrip}", "left", '-2000px', { fromValue: '-1500px'}], position: 5500, duration: 500 },
            { id: "eid17", tween: [ "style", "${_flowerStrip}", "left", '0px', { fromValue: '-2000px'}], position: 7000, duration: 500 },
            { id: "eid118", tween: [ "style", "${_hsRose}", "display", 'block', { fromValue: 'none'}], position: 1500, duration: 0 },
            { id: "eid119", tween: [ "style", "${_hsRose}", "display", 'none', { fromValue: 'block'}], position: 2500, duration: 0 },
            { id: "eid129", tween: [ "style", "${_coPoppy}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid134", tween: [ "style", "${_coTigerLily}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid122", tween: [ "style", "${_hsLilac}", "display", 'block', { fromValue: 'none'}], position: 4500, duration: 0 },
            { id: "eid123", tween: [ "style", "${_hsLilac}", "display", 'none', { fromValue: 'block'}], position: 5500, duration: 0 },
            { id: "eid125", tween: [ "style", "${_hsTigerLily}", "display", 'block', { fromValue: 'none'}], position: 6000, duration: 0 },
            { id: "eid127", tween: [ "style", "${_hsTigerLily}", "display", 'none', { fromValue: 'block'}], position: 7000, duration: 0 }         ]
      }
   }
},
"hotspot": {
   version: "0.1.7",
   minimumCompatibleVersion: "0.1.7",
   build: "0.11.0.161",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
   dom: [
   {
      type: 'rect',
      rect: ['0px','0px','92px','104px','auto','auto'],
      id: 'Rectangle2',
      stroke: [0,'rgba(0,0,0,1)','none'],
      cursor: ['help'],
      fill: ['rgba(255,255,255,1.00)']
   }],
   symbolInstances: [
   ]
   },
   states: {
      "Base State": {
         "${symbolSelector}": [
            ["style", "height", '103.55000305176px'],
            ["style", "width", '92.449996948242px']
         ],
         "${_Rectangle2}": [
            ["color", "background-color", 'rgba(255,255,255,1.00)'],
            ["style", "top", '0px'],
            ["style", "opacity", '0'],
            ["style", "left", '0px'],
            ["style", "cursor", 'help']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 0,
         autoPlay: true,
         timeline: [
         ]
      }
   }
}
};


Edge.registerCompositionDefn(compId, symbols, fonts, resources);

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     Edge.launchComposition(compId);
});
})(jQuery, AdobeEdge, "EDGE-11331110");
