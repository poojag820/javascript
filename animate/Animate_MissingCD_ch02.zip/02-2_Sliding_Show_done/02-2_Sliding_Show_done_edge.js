/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
var im='images/';

var fonts = {};


var resources = [
];
var symbols = {
"stage": {
   version: "0.1.7",
   minimumCompatibleVersion: "0.1.7",
   build: "0.11.0.153",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
         dom: [
         {
            id:'Text',
            type:'text',
            rect:['84px','172px','431px','55px','auto','auto'],
            opacity:1,
            text:"Thanks for watching!",
            font:['Arial Black, Gadget, sans-serif',37,"rgba(0,0,0,1)","normal","none",""]
         },
         {
            id:'bike',
            type:'image',
            rect:['0','0','600px','400px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"bike.jpg",'0px','0px']
         },
         {
            id:'farmhouse',
            type:'image',
            rect:['0','0','600px','400px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"farmhouse.jpg",'0px','0px']
         },
         {
            id:'squirrel',
            type:'image',
            rect:['0','0','600px','400px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"squirrel.jpg",'0px','0px']
         }],
         symbolInstances: [

         ]
      },
   states: {
      "Base State": {
         "${_farmhouse}": [
            ["style", "top", '0px'],
            ["style", "opacity", '1'],
            ["style", "left", '0px']
         ],
         "${_Text}": [
            ["style", "top", '172px'],
            ["style", "opacity", '0'],
            ["style", "width", '431.03332519531px'],
            ["style", "height", '55.125px'],
            ["style", "font-family", 'Arial Black, Gadget, sans-serif'],
            ["style", "left", '84px'],
            ["style", "font-size", '37px']
         ],
         "${_Stage}": [
            ["color", "background-color", 'rgba(255,255,255,1)'],
            ["style", "overflow", 'hidden'],
            ["style", "height", '400px'],
            ["style", "width", '600px']
         ],
         "${_squirrel}": [
            ["style", "top", '0px'],
            ["style", "opacity", '1'],
            ["style", "left", '0px']
         ],
         "${_bike}": [
            ["style", "top", '0px'],
            ["style", "opacity", '1'],
            ["style", "left", '0px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 10500,
         autoPlay: true,
         timeline: [
            { id: "eid6", tween: [ "style", "${_bike}", "top", '0px', { fromValue: '0px'}], position: 0, duration: 0 },
            { id: "eid17", tween: [ "style", "${_bike}", "top", '0px', { fromValue: '0px'}], position: 8000, duration: 0 },
            { id: "eid31", tween: [ "style", "${_farmhouse}", "opacity", '0.2', { fromValue: '1'}], position: 5000, duration: 1000 },
            { id: "eid1", tween: [ "style", "${_squirrel}", "left", '0px', { fromValue: '0px'}], position: 0, duration: 0 },
            { id: "eid9", tween: [ "style", "${_squirrel}", "left", '638px', { fromValue: '0px'}], position: 2000, duration: 1000 },
            { id: "eid30", tween: [ "style", "${_farmhouse}", "top", '0px', { fromValue: '0px'}], position: 5000, duration: 1000 },
            { id: "eid3", tween: [ "style", "${_bike}", "left", '0px', { fromValue: '0px'}], position: 0, duration: 0 },
            { id: "eid20", tween: [ "style", "${_bike}", "left", '638px', { fromValue: '0px'}], position: 8000, duration: 1000 },
            { id: "eid4", tween: [ "style", "${_squirrel}", "top", '0px', { fromValue: '0px'}], position: 0, duration: 0 },
            { id: "eid8", tween: [ "style", "${_squirrel}", "top", '0px', { fromValue: '0px'}], position: 2000, duration: 0 },
            { id: "eid29", tween: [ "style", "${_farmhouse}", "left", '638px', { fromValue: '0px'}], position: 5000, duration: 1000 },
            { id: "eid32", tween: [ "style", "${_Text}", "opacity", '0', { fromValue: '0'}], position: 0, duration: 0 },
            { id: "eid33", tween: [ "style", "${_Text}", "opacity", '1', { fromValue: '0'}], position: 9000, duration: 500 },
            { id: "eid34", tween: [ "style", "${_Text}", "opacity", '1', { fromValue: '1'}], position: 10000, duration: 0 },
            { id: "eid23", tween: [ "style", "${_Text}", "opacity", '0', { fromValue: '1'}], position: 10000, duration: 500 },
            { id: "eid21", tween: [ "style", "${_bike}", "opacity", '0.18', { fromValue: '1'}], position: 8000, duration: 1000 },
            { id: "eid24", tween: [ "style", "${_squirrel}", "opacity", '1', { fromValue: '1'}], position: 0, duration: 0 },
            { id: "eid25", tween: [ "style", "${_squirrel}", "opacity", '0.20000000298023224', { fromValue: '1'}], position: 2000, duration: 1000 }         ]
      }
   }
}
};


Edge.registerCompositionDefn(compId, symbols, fonts, resources);

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     Edge.launchComposition(compId);
});
})(jQuery, AdobeEdge, "EDGE-11098683");
