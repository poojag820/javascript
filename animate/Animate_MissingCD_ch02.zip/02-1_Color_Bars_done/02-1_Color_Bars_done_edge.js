/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
var im='images/';

var fonts = {};


var resources = [
];
var symbols = {
"stage": {
   version: "0.1.7",
   minimumCompatibleVersion: "0.1.7",
   build: "0.11.0.153",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
         dom: [
         {
            id:'Red',
            type:'rect',
            rect:['-491px','0px','550px','100px','auto','auto'],
            fill:["rgba(255,0,0,1.00)"],
            stroke:[0,"rgba(0,0,0,1)","none"],
            transform:[[],[],['50deg']]
         },
         {
            id:'Green',
            type:'rect',
            rect:['490px','100px','550px','100px','auto','auto'],
            fill:["rgba(0,255,0,1.00)"],
            stroke:[0,"rgba(0,0,0,1)","none"],
            transform:[[],[],['50deg']]
         },
         {
            id:'Blue',
            type:'rect',
            rect:['-491px','200px','550px','100px','auto','auto'],
            fill:["rgba(0,0,255,1.00)"],
            stroke:[0,"rgba(0,0,0,1)","none"],
            transform:[[],[],['50deg']]
         },
         {
            id:'Yellow',
            type:'rect',
            rect:['490px','300px','550px','100px','auto','auto'],
            fill:["rgba(255,255,0,1.00)"],
            stroke:[0,"rgba(0,0,0,1)","none"],
            transform:[[],[],['50deg']]
         }],
         symbolInstances: [

         ]
      },
   states: {
      "Base State": {
         "${_Red}": [
            ["color", "background-color", 'rgba(255,0,0,1.00)'],
            ["style", "top", '0px'],
            ["transform", "skewX", '50deg'],
            ["style", "height", '100px'],
            ["style", "opacity", '1'],
            ["style", "left", '-491.19px'],
            ["style", "width", '549.97003096242px']
         ],
         "${_Blue}": [
            ["color", "background-color", 'rgba(0,0,255,1.00)'],
            ["style", "top", '200px'],
            ["transform", "skewX", '50deg'],
            ["style", "height", '100px'],
            ["style", "opacity", '1'],
            ["style", "left", '-491.41px'],
            ["style", "width", '549.97003096242px']
         ],
         "${_Yellow}": [
            ["style", "top", '300px'],
            ["color", "background-color", 'rgba(255,255,0,1.00)'],
            ["transform", "skewX", '50deg'],
            ["style", "height", '100px'],
            ["style", "opacity", '1'],
            ["style", "left", '489.59px'],
            ["style", "width", '549.97003096242px']
         ],
         "${_Stage}": [
            ["color", "background-color", 'rgba(255,255,255,1)'],
            ["style", "height", '400px'],
            ["style", "width", '550px']
         ],
         "${_Green}": [
            ["style", "top", '100px'],
            ["color", "background-color", 'rgba(0,255,0,1.00)'],
            ["transform", "skewX", '50deg'],
            ["style", "height", '100px'],
            ["style", "opacity", '1'],
            ["style", "left", '489.59px'],
            ["style", "width", '549.97003096242px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 4000,
         autoPlay: true,
         timeline: [
            { id: "eid18", tween: [ "style", "${_Blue}", "width", '549.97003096242px', { fromValue: '549.97003096242px'}], position: 0, duration: 0 },
            { id: "eid24", tween: [ "style", "${_Blue}", "opacity", '1', { fromValue: '1'}], position: 0, duration: 0 },
            { id: "eid44", tween: [ "style", "${_Blue}", "opacity", '0.5', { fromValue: '1'}], position: 2000, duration: 1000 },
            { id: "eid56", tween: [ "style", "${_Blue}", "opacity", '0', { fromValue: '0.5'}], position: 3000, duration: 1000 },
            { id: "eid1", tween: [ "style", "${_Red}", "top", '0px', { fromValue: '0px'}], position: 0, duration: 0 },
            { id: "eid38", tween: [ "style", "${_Green}", "height", '300px', { fromValue: '100px'}], position: 0, duration: 3000 },
            { id: "eid50", tween: [ "style", "${_Green}", "height", '500px', { fromValue: '300px'}], position: 3000, duration: 1000 },
            { id: "eid15", tween: [ "style", "${_Blue}", "top", '200px', { fromValue: '200px'}], position: 0, duration: 0 },
            { id: "eid5", tween: [ "style", "${_Red}", "opacity", '1', { fromValue: '1'}], position: 0, duration: 0 },
            { id: "eid46", tween: [ "style", "${_Red}", "opacity", '0.5', { fromValue: '1'}], position: 2000, duration: 1000 },
            { id: "eid58", tween: [ "style", "${_Red}", "opacity", '0', { fromValue: '0.5'}], position: 3000, duration: 1000 },
            { id: "eid27", tween: [ "style", "${_Red}", "left", '59.59px', { fromValue: '-491.19px'}], position: 0, duration: 2000 },
            { id: "eid41", tween: [ "style", "${_Red}", "left", '178.76px', { fromValue: '59.59px'}], position: 2000, duration: 1000 },
            { id: "eid53", tween: [ "style", "${_Red}", "left", '297.93px', { fromValue: '178.76px'}], position: 3000, duration: 1000 },
            { id: "eid20", tween: [ "style", "${_Yellow}", "width", '549.97003096242px', { fromValue: '549.97003096242px'}], position: 0, duration: 0 },
            { id: "eid36", tween: [ "style", "${_Blue}", "height", '300px', { fromValue: '100px'}], position: 0, duration: 3000 },
            { id: "eid48", tween: [ "style", "${_Blue}", "height", '500px', { fromValue: '300px'}], position: 3000, duration: 1000 },
            { id: "eid17", tween: [ "style", "${_Yellow}", "top", '300px', { fromValue: '300px'}], position: 0, duration: 0 },
            { id: "eid31", tween: [ "style", "${_Yellow}", "left", '-59.55px', { fromValue: '489.59px'}], position: 0, duration: 2000 },
            { id: "eid43", tween: [ "style", "${_Yellow}", "left", '59.63px', { fromValue: '-59.55px'}], position: 2000, duration: 1000 },
            { id: "eid55", tween: [ "style", "${_Yellow}", "left", '178.79px', { fromValue: '59.63px'}], position: 3000, duration: 1000 },
            { id: "eid19", tween: [ "style", "${_Green}", "width", '549.97003096242px', { fromValue: '549.97003096242px'}], position: 0, duration: 0 },
            { id: "eid25", tween: [ "style", "${_Green}", "opacity", '1', { fromValue: '1'}], position: 0, duration: 0 },
            { id: "eid45", tween: [ "style", "${_Green}", "opacity", '0.5', { fromValue: '1'}], position: 2000, duration: 1000 },
            { id: "eid57", tween: [ "style", "${_Green}", "opacity", '0', { fromValue: '0.5'}], position: 3000, duration: 1000 },
            { id: "eid42", tween: [ "style", "${_Yellow}", "height", '300px', { fromValue: '100px'}], position: 0, duration: 3000 },
            { id: "eid54", tween: [ "style", "${_Yellow}", "height", '500px', { fromValue: '300px'}], position: 3000, duration: 1000 },
            { id: "eid40", tween: [ "style", "${_Red}", "height", '300px', { fromValue: '100px'}], position: 0, duration: 3000 },
            { id: "eid52", tween: [ "style", "${_Red}", "height", '500px', { fromValue: '300px'}], position: 3000, duration: 1000 },
            { id: "eid29", tween: [ "style", "${_Green}", "left", '-66.44px', { fromValue: '489.59px'}], position: 0, duration: 2000 },
            { id: "eid39", tween: [ "style", "${_Green}", "left", '52.74px', { fromValue: '-66.44px'}], position: 2000, duration: 1000 },
            { id: "eid51", tween: [ "style", "${_Green}", "left", '171.91px', { fromValue: '52.74px'}], position: 3000, duration: 1000 },
            { id: "eid30", tween: [ "style", "${_Blue}", "left", '53.63px', { fromValue: '-491.41px'}], position: 0, duration: 2000 },
            { id: "eid37", tween: [ "style", "${_Blue}", "left", '172.79px', { fromValue: '53.63px'}], position: 2000, duration: 1000 },
            { id: "eid49", tween: [ "style", "${_Blue}", "left", '291.96px', { fromValue: '172.79px'}], position: 3000, duration: 1000 },
            { id: "eid26", tween: [ "style", "${_Yellow}", "opacity", '1', { fromValue: '1'}], position: 0, duration: 0 },
            { id: "eid47", tween: [ "style", "${_Yellow}", "opacity", '0.5', { fromValue: '1'}], position: 2000, duration: 1000 },
            { id: "eid59", tween: [ "style", "${_Yellow}", "opacity", '0', { fromValue: '0.5'}], position: 3000, duration: 1000 },
            { id: "eid16", tween: [ "style", "${_Green}", "top", '100px', { fromValue: '100px'}], position: 0, duration: 0 },
            { id: "eid3", tween: [ "style", "${_Red}", "width", '549.97003096242px', { fromValue: '549.97003096242px'}], position: 0, duration: 0 }         ]
      }
   }
}
};


Edge.registerCompositionDefn(compId, symbols, fonts, resources);

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     Edge.launchComposition(compId);
});
})(jQuery, AdobeEdge, "EDGE-2645126");
