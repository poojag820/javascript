/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
var im='images/';

var fonts = {};


var resources = [
];
var symbols = {
"stage": {
   version: "0.1.7",
   minimumCompatibleVersion: "0.1.7",
   build: "0.11.0.153",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
         dom: [
         {
            id:'Text',
            display:'none',
            type:'text',
            rect:['84px','172px','431px','55px','auto','auto'],
            opacity:1,
            text:"Thanks for watching!",
            font:['Arial Black, Gadget, sans-serif',37,"rgba(0,0,0,1)","normal","none",""]
         },
         {
            id:'bike',
            display:'none',
            type:'image',
            rect:['0','0','600px','400px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"bike.jpg",'0px','0px']
         },
         {
            id:'farmhouse',
            display:'none',
            type:'image',
            rect:['0','0','600px','400px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"farmhouse.jpg",'0px','0px']
         },
         {
            id:'squirrel',
            type:'image',
            rect:['0','0','600px','400px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"squirrel.jpg",'0px','0px']
         }],
         symbolInstances: [

         ]
      },
   states: {
      "Base State": {
         "${_farmhouse}": [
            ["style", "top", '0px'],
            ["style", "opacity", '1'],
            ["style", "left", '0px'],
            ["style", "display", 'none']
         ],
         "${_Text}": [
            ["style", "top", '172px'],
            ["style", "display", 'none'],
            ["style", "opacity", '1'],
            ["style", "width", '431.03332519531px'],
            ["style", "height", '55.125px'],
            ["style", "font-family", 'Arial Black, Gadget, sans-serif'],
            ["style", "left", '84px'],
            ["style", "font-size", '37px']
         ],
         "${_Stage}": [
            ["color", "background-color", 'rgba(255,255,255,1)'],
            ["style", "overflow", 'hidden'],
            ["style", "height", '400px'],
            ["style", "width", '600px']
         ],
         "${_squirrel}": [
            ["style", "top", '0px'],
            ["style", "opacity", '1'],
            ["style", "left", '0px'],
            ["style", "display", 'block']
         ],
         "${_bike}": [
            ["style", "top", '0px'],
            ["style", "opacity", '1'],
            ["style", "left", '0px'],
            ["style", "display", 'none']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 7000,
         autoPlay: true,
         timeline: [
            { id: "eid37", tween: [ "style", "${_bike}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid41", tween: [ "style", "${_bike}", "display", 'block', { fromValue: 'none'}], position: 2000, duration: 0 },
            { id: "eid42", tween: [ "style", "${_bike}", "display", 'none', { fromValue: 'block'}], position: 4000, duration: 0 },
            { id: "eid36", tween: [ "style", "${_farmhouse}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid43", tween: [ "style", "${_farmhouse}", "display", 'block', { fromValue: 'none'}], position: 4000, duration: 0 },
            { id: "eid44", tween: [ "style", "${_farmhouse}", "display", 'none', { fromValue: 'block'}], position: 6000, duration: 0 },
            { id: "eid39", tween: [ "style", "${_squirrel}", "display", 'block', { fromValue: 'block'}], position: 0, duration: 0 },
            { id: "eid40", tween: [ "style", "${_squirrel}", "display", 'none', { fromValue: 'block'}], position: 2000, duration: 0 },
            { id: "eid38", tween: [ "style", "${_Text}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid45", tween: [ "style", "${_Text}", "display", 'block', { fromValue: 'none'}], position: 6000, duration: 0 },
            { id: "eid47", tween: [ "style", "${_Text}", "display", 'none', { fromValue: 'block'}], position: 7000, duration: 0 }         ]
      }
   }
}
};


Edge.registerCompositionDefn(compId, symbols, fonts, resources);

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     Edge.launchComposition(compId);
});
})(jQuery, AdobeEdge, "EDGE-11098683");
