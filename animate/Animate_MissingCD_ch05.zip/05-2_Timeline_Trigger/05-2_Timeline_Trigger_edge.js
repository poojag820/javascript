/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
var im='images/';

var fonts = {};


var resources = [
];
var symbols = {
"stage": {
   version: "0.1.7",
   minimumCompatibleVersion: "0.1.7",
   build: "0.11.0.153",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: true,
   resizeInstances: false,
   content: {
         dom: [
         {
            id:'num_1',
            type:'text',
            rect:['270','187','0','0','auto','auto'],
            text:"1",
            font:['Arial Black, Gadget, sans-serif',24,"rgba(0,0,0,1)","normal","none",""]
         },
         {
            id:'num_2',
            type:'text',
            rect:['33','40','119','305','auto','auto'],
            text:"2",
            align:"auto",
            font:['\'Arial Black\', Gadget, sans-serif',238,"rgba(0,0,0,1)","normal","none","normal"]
         },
         {
            id:'num_3',
            type:'text',
            rect:['77','59','111','293','auto','auto'],
            text:"3",
            align:"auto",
            font:['\'Arial Black\', Gadget, sans-serif',238,"rgba(0,0,0,1)","normal","none","normal"]
         },
         {
            id:'num_4',
            type:'text',
            rect:['240','53','119','293','auto','auto'],
            text:"4",
            align:"auto",
            font:['\'Arial Black\', Gadget, sans-serif',238,"rgba(0,0,0,1)","normal","none","normal"],
            transform:[]
         },
         {
            id:'num_5',
            type:'text',
            rect:['244','53','111','293','auto','auto'],
            text:"5",
            align:"auto",
            font:['\'Arial Black\', Gadget, sans-serif',238,"rgba(0,0,0,1)","normal","none","normal"],
            transform:[]
         }],
         symbolInstances: [

         ]
      },
   states: {
      "Base State": {
         "${_num_3}": [
            ["style", "top", '53px'],
            ["style", "opacity", '0'],
            ["style", "left", '244px']
         ],
         "${_num_5}": [
            ["style", "top", '53px'],
            ["style", "opacity", '0'],
            ["style", "left", '244px']
         ],
         "${_num_1}": [
            ["style", "top", '32px'],
            ["style", "opacity", '1'],
            ["style", "left", '220px'],
            ["style", "font-size", '238px']
         ],
         "${_num_2}": [
            ["style", "top", '47px'],
            ["style", "opacity", '0'],
            ["style", "left", '240px']
         ],
         "${_stage}": [
            ["color", "background-color", 'rgba(255,255,255,1)'],
            ["style", "width", '600px'],
            ["style", "height", '400px'],
            ["style", "overflow", 'hidden']
         ],
         "${_num_4}": [
            ["style", "top", '53px'],
            ["style", "opacity", '0'],
            ["style", "left", '240px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 2500,
         autoPlay: true,
         timeline: [
            { id: "eid30", tween: [ "style", "${_num_1}", "opacity", '1', { fromValue: '1'}], position: 0, duration: 0 },
            { id: "eid20", tween: [ "style", "${_num_1}", "opacity", '0', { fromValue: '1'}], position: 500, duration: 0 },
            { id: "eid28", tween: [ "style", "${_num_5}", "opacity", '0', { fromValue: '0'}], position: 0, duration: 0 },
            { id: "eid31", tween: [ "style", "${_num_5}", "opacity", '1', { fromValue: '1'}], position: 2000, duration: 0 },
            { id: "eid27", tween: [ "style", "${_num_5}", "opacity", '0', { fromValue: '1'}], position: 2500, duration: 0 },
            { id: "eid29", tween: [ "style", "${_num_4}", "opacity", '0', { fromValue: '0'}], position: 0, duration: 0 },
            { id: "eid25", tween: [ "style", "${_num_4}", "opacity", '1', { fromValue: '1'}], position: 1500, duration: 0 },
            { id: "eid32", tween: [ "style", "${_num_4}", "opacity", '0', { fromValue: '0'}], position: 2000, duration: 0 },
            { id: "eid16", tween: [ "style", "${_num_3}", "opacity", '0', { fromValue: '0'}], position: 0, duration: 0 },
            { id: "eid22", tween: [ "style", "${_num_3}", "opacity", '1', { fromValue: '1'}], position: 1000, duration: 0 },
            { id: "eid23", tween: [ "style", "${_num_3}", "opacity", '0', { fromValue: '0'}], position: 1500, duration: 0 },
            { id: "eid8", tween: [ "style", "${_num_2}", "opacity", '0', { fromValue: '0'}], position: 0, duration: 0 },
            { id: "eid19", tween: [ "style", "${_num_2}", "opacity", '1', { fromValue: '1'}], position: 500, duration: 0 },
            { id: "eid21", tween: [ "style", "${_num_2}", "opacity", '0', { fromValue: '0'}], position: 1000, duration: 0 }         ]
      }
   }
}
};


Edge.registerCompositionDefn(compId, symbols, fonts, resources);

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     Edge.launchComposition(compId);
});
})(jQuery, AdobeEdge, "EDGE-54416510");
