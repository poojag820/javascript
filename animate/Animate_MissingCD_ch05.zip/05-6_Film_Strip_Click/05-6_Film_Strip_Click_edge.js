/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
var im='images/';

var fonts = {};


var resources = [
];
var symbols = {
"stage": {
   version: "0.1.7",
   minimumCompatibleVersion: "0.1.7",
   build: "0.11.0.153",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
         dom: [
         {
            id:'flowerStrip',
            type:'image',
            rect:['px','px','2500','375','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"flowerStrip375x2500.jpg"],
            transform:[]
         },
         {
            id:'btnStop',
            type:'image',
            rect:['176','375','166','50','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"btnStop.png"]
         },
         {
            id:'btnReverse',
            type:'image',
            rect:['8','391','166','50','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"btnBack.png"]
         },
         {
            id:'btnPlay',
            type:'image',
            rect:['417','375','166','50','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"btnNext.png"]
         }],
         symbolInstances: [

         ]
      },
   states: {
      "Base State": {
         "${_flowerStrip}": [
            ["style", "left", '0px'],
            ["style", "top", '0px']
         ],
         "${_btnStop}": [
            ["style", "left", '167px']
         ],
         "${_btnPlay}": [
            ["style", "left", '334px']
         ],
         "${_btnReverse}": [
            ["style", "left", '0px'],
            ["style", "top", '375px']
         ],
         "${_Stage}": [
            ["color", "background-color", 'rgba(0,0,0,1.00)'],
            ["style", "width", '500px'],
            ["style", "height", '425px'],
            ["style", "overflow", 'hidden']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 7500,
         autoPlay: true,
         timeline: [
            { id: "eid1", tween: [ "style", "${_flowerStrip}", "left", '-500px', { fromValue: '0px'}], position: 1000, duration: 500 },
            { id: "eid2", tween: [ "style", "${_flowerStrip}", "left", '-1000px', { fromValue: '-500px'}], position: 2500, duration: 500 },
            { id: "eid3", tween: [ "style", "${_flowerStrip}", "left", '-1500px', { fromValue: '-1000px'}], position: 4000, duration: 500 },
            { id: "eid4", tween: [ "style", "${_flowerStrip}", "left", '-2000px', { fromValue: '-1500px'}], position: 5500, duration: 500 },
            { id: "eid17", tween: [ "style", "${_flowerStrip}", "left", '0px', { fromValue: '-2000px'}], position: 7000, duration: 500 }         ]
      }
   }
}
};


Edge.registerCompositionDefn(compId, symbols, fonts, resources);

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     Edge.launchComposition(compId);
});
})(jQuery, AdobeEdge, "EDGE-11331110");
