/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
var im='images/';

var fonts = {};


var resources = [
];
var symbols = {
"stage": {
   version: "0.1.7",
   minimumCompatibleVersion: "0.1.7",
   build: "0.11.0.153",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: true,
   resizeInstances: false,
   content: {
         dom: [
         {
            id:'bike',
            type:'image',
            rect:['0','0','600','400','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"bike.jpg"]
         },
         {
            id:'house',
            type:'image',
            rect:['0','0','600','400','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"farmhouse.jpg"]
         },
         {
            id:'squirrel',
            type:'image',
            rect:['0','0','600','400','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"squirrel.jpg"]
         }],
         symbolInstances: [

         ]
      },
   states: {
      "Base State": {
         "${_stage}": [
            ["color", "background-color", 'rgba(255,255,255,1)'],
            ["style", "overflow", 'hidden'],
            ["style", "height", '400px'],
            ["style", "width", '600px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 0,
         autoPlay: true,
         timeline: [
         ]
      }
   }
}
};


Edge.registerCompositionDefn(compId, symbols, fonts, resources);

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     Edge.launchComposition(compId);
});
})(jQuery, AdobeEdge, "EDGE-54513230");
