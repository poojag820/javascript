/***********************
* Adobe Edge Composition Actions
*
* Edit this file with caution, being careful to preserve 
* function signatures and comments starting with 'Edge' to maintain the 
* ability to interact with these actions from within Adobe Edge
*
***********************/
(function($, Edge, compId){
var Composition = Edge.Composition, Symbol = Edge.Symbol; // aliases for commonly used Edge classes

//Edge symbol: 'stage'
(function(symbolName) {











Symbol.bindTimelineAction(compId, symbolName, "Default Timeline", "complete", function(sym, e) {
// play the timeline from the given position (ms or label)
sym.play(0);

});
//Edge binding end

Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 1500, function(sym, e) {
// Show an Element.
//  (sym.$("name") resolves an Edge element name to a DOM
//  element that can be used with jQuery)
sym.$("Great").show();

});
//Edge binding end

Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 0, function(sym, e) {
// Hide an Element.
//  (sym.$("name") resolves an Edge element name to a DOM
//  element that can be used with jQuery)
sym.$("Great").hide();

});
//Edge binding end

Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 2000, function(sym, e) {
// Hide an Element.
//  (sym.$("name") resolves an Edge element name to a DOM
//  element that can be used with jQuery)
sym.$("Great").hide();
});
//Edge binding end


})("stage");
   //Edge symbol end:'stage'

})(jQuery, AdobeEdge, "EDGE-54416510");