/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
var im='images/';

var fonts = {};


var resources = [
];
var symbols = {
"stage": {
   version: "0.1.7",
   minimumCompatibleVersion: "0.1.7",
   build: "0.11.0.153",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: true,
   resizeInstances: false,
   content: {
         dom: [
         {
            id:'bike',
            type:'image',
            rect:['0','0','600','400','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"bike.jpg"]
         },
         {
            id:'house',
            type:'image',
            rect:['0','0','600','400','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"farmhouse.jpg"]
         },
         {
            id:'squirrel',
            type:'image',
            rect:['0','0','600','400','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"squirrel.jpg"]
         }],
         symbolInstances: [

         ]
      },
   states: {
      "Base State": {
         "${_squirrel}": [
            ["style", "left", '0px'],
            ["style", "top", '0px']
         ],
         "${_bike}": [
            ["style", "left", '0px'],
            ["style", "top", '0px']
         ],
         "${_stage}": [
            ["color", "background-color", 'rgba(255,255,255,1)'],
            ["style", "width", '600px'],
            ["style", "height", '400px'],
            ["style", "overflow", 'hidden']
         ],
         "${_house}": [
            ["style", "left", '0px'],
            ["style", "top", '0px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 2010,
         autoPlay: true,
         labels: {
            "squirrel": 0,
            "house": 1000,
            "bike": 2010
         },
         timeline: [
            { id: "eid5", tween: [ "style", "${_bike}", "left", '0px', { fromValue: '0px'}], position: 0, duration: 0 },
            { id: "eid2", tween: [ "style", "${_squirrel}", "top", '0px', { fromValue: '0px'}], position: 0, duration: 0 },
            { id: "eid3", tween: [ "style", "${_house}", "left", '0px', { fromValue: '0px'}], position: 0, duration: 0 },
            { id: "eid10", tween: [ "style", "${_house}", "left", '616px', { fromValue: '0px'}], position: 2010, duration: 0 },
            { id: "eid1", tween: [ "style", "${_squirrel}", "left", '0px', { fromValue: '0px'}], position: 0, duration: 0 },
            { id: "eid9", tween: [ "style", "${_squirrel}", "left", '623px', { fromValue: '0px'}], position: 1000, duration: 0 },
            { id: "eid6", tween: [ "style", "${_bike}", "top", '0px', { fromValue: '0px'}], position: 0, duration: 0 },
            { id: "eid4", tween: [ "style", "${_house}", "top", '0px', { fromValue: '0px'}], position: 0, duration: 0 }         ]
      }
   }
}
};


Edge.registerCompositionDefn(compId, symbols, fonts, resources);

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     Edge.launchComposition(compId);
});
})(jQuery, AdobeEdge, "EDGE-54559776");
