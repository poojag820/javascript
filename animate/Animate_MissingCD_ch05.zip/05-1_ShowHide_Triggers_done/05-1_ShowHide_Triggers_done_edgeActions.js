/***********************
* Adobe Edge Composition Actions
*
* Edit this file with caution, being careful to preserve 
* function signatures and comments starting with 'Edge' to maintain the 
* ability to interact with these actions from within Adobe Edge
*
***********************/
(function($, Edge, compId){
var Composition = Edge.Composition, Symbol = Edge.Symbol; // aliases for commonly used Edge classes

   //Edge symbol: 'stage'
   (function(symbolName) {
      
      
      Symbol.bindElementAction(compId, symbolName, "${_Box}", "click", function(sym, e) {
         // insert code for mouse click here
         // Hide an Element.
         //  (sym.$("name") resolves an Edge element name to a DOM
         //  element that can be used with jQuery)
         sym.$("Box").hide();
         // Show an Element.
         //  (sym.$("name") resolves an Edge element name to a DOM
         //  element that can be used with jQuery)
         sym.$("BringBack").show();
         

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_BringBack}", "click", function(sym, e) {
         // insert code for mouse click here
         // Show an Element.
         //  (sym.$("name") resolves an Edge element name to a DOM
         //  element that can be used with jQuery)
         sym.$("Box").show();
         // Hide an Element.
         //  (sym.$("name") resolves an Edge element name to a DOM
         //  element that can be used with jQuery)
         sym.$("BringBack").hide();
         

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "document", "compositionReady", function(sym, e) {
         // insert code to be run when the composition is fully loaded here
         // Hide an Element.
         //  (sym.$("name") resolves an Edge element name to a DOM
         //  element that can be used with jQuery)
         sym.$("BringBack").hide();

      });
      //Edge binding end

   })("stage");
   //Edge symbol end:'stage'

})(jQuery, AdobeEdge, "EDGE-3337948");