/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
var im='images/';

var fonts = {};


var resources = [
];
var symbols = {
"stage": {
   version: "0.1.7",
   minimumCompatibleVersion: "0.1.7",
   build: "0.11.0.153",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
         dom: [
         {
            id:'World',
            type:'image',
            rect:['29px','407px','480px','480px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"planet_earth.png",'0px','0px']
         },
         {
            id:'HelloWorld',
            type:'text',
            rect:['49px','45px','auto','auto','auto','auto'],
            opacity:0,
            text:"Hello World",
            align:"left",
            font:['Arial Black, Gadget, sans-serif',72,"rgba(143,169,250,1.00)","normal","none","normal"]
         }],
         symbolInstances: [

         ]
      },
   states: {
      "Base State": {
         "${_Stage}": [
            ["color", "background-color", 'rgba(30,45,90,1.00)'],
            ["style", "overflow", 'visible'],
            ["style", "height", '400px'],
            ["style", "width", '550px']
         ],
         "${_World}": [
            ["style", "left", '29.13px'],
            ["style", "top", '407px']
         ],
         "${_HelloWorld}": [
            ["style", "top", '45.32px'],
            ["style", "opacity", '0'],
            ["color", "color", 'rgba(143,169,250,1.00)'],
            ["style", "font-family", 'Arial Black, Gadget, sans-serif'],
            ["style", "left", '49px'],
            ["style", "font-size", '72px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 4000,
         autoPlay: true,
         timeline: [
            { id: "eid10", tween: [ "style", "${_HelloWorld}", "opacity", '1', { fromValue: '0.000000'}], position: 2000, duration: 1000 },
            { id: "eid11", tween: [ "style", "${_HelloWorld}", "opacity", '0', { fromValue: '1'}], position: 3000, duration: 1000 },
            { id: "eid8", tween: [ "style", "${_World}", "top", '39.53px', { fromValue: '407px'}], position: 1000, duration: 2000 },
            { id: "eid7", tween: [ "style", "${_World}", "left", '29.43px', { fromValue: '29.13px'}], position: 1000, duration: 2000 }         ]
      }
   }
}
};


Edge.registerCompositionDefn(compId, symbols, fonts, resources);

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     Edge.launchComposition(compId);
});
})(jQuery, AdobeEdge, "EDGE-2306333");
