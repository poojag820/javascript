/***********************
* Adobe Edge Composition Actions
*
* Edit this file with caution, being careful to preserve 
* function signatures and comments starting with 'Edge' to maintain the 
* ability to interact with these actions from within Adobe Edge
*
***********************/
(function($, Edge, compId){
var Composition = Edge.Composition, Symbol = Edge.Symbol; // aliases for commonly used Edge classes

   //Edge symbol: 'stage'
   (function(symbolName) {
      
      
      

      

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 1000, function(sym, e) {
         sym.stop();

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 1750, function(sym, e) {
         sym.stop(0);

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 0, function(sym, e) {
         sym.stop();

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_edge_pr7}", "click", function(sym, e) {
         sym.play('edgePR7');

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_edge_pr7_lg}", "click", function(sym, e) {
         sym.play();

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_edgePR7blurb}", "click", function(sym, e) {
         sym.play();

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 2750, function(sym, e) {
         sym.stop();

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 3500, function(sym, e) {
         sym.stop(0);

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_flash6}", "click", function(sym, e) {
         sym.play('flash6');

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_flash6_lg}", "click", function(sym, e) {
         sym.play();
         

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_flash6blurb}", "click", function(sym, e) {
         sym.play();

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 4750, function(sym, e) {
         sym.stop();

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 5500, function(sym, e) {
         sym.stop(0);

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_of2011}", "click", function(sym, e) {
         sym.play('office2011');
         

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_office2011_lg}", "click", function(sym, e) {
         sym.play();

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_office2011blurb}", "click", function(sym, e) {
         sym.play();

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 6750, function(sym, e) {
         sym.stop();

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 7500, function(sym, e) {
         sym.stop(0);

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_fl5}", "click", function(sym, e) {
         sym.play('flash5');

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_flash5_lg}", "click", function(sym, e) {
         sym.play();

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_flash5blurb}", "click", function(sym, e) {
         sym.play();
         

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_fl3_lg}", "click", function(sym, e) {
         sym.play();

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 8750, function(sym, e) {
         sym.stop();

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 9500, function(sym, e) {
         sym.stop(0);

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_flash3blurb}", "click", function(sym, e) {
         sym.play();
         

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_fl3}", "click", function(sym, e) {
         sym.play('flash3');

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 10750, function(sym, e) {
         sym.stop();

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 11500, function(sym, e) {
         sym.stop(0);

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_wrd07strtr}", "click", function(sym, e) {
         sym.play("word07strt");
         

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_wrd07strtr_lg}", "click", function(sym, e) {
         sym.play();

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 12750, function(sym, e) {
         sym.stop();

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 13500, function(sym, e) {
         sym.stop(0);

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_edge_pr5_lg}", "click", function(sym, e) {
         sym.play();

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_edgePR5blurb}", "click", function(sym, e) {
         sym.play();
         // insert code for mouse click here

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_edge_pr5}", "click", function(sym, e) {
         sym.play("edgePR5");
         

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 14750, function(sym, e) {
         sym.stop();

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 15500, function(sym, e) {
         sym.stop(0);

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_pe8MM}", "click", function(sym, e) {
         sym.play('premiere');
         

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_pe8MM_lg}", "click", function(sym, e) {
         sym.play();

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_premiereblurb}", "click", function(sym, e) {
         sym.play();

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 16750, function(sym, e) {
         sym.stop();

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 17500, function(sym, e) {
         sym.stop(0);
         // insert code here

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_office2007blurb}", "click", function(sym, e) {
         sym.play();

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_of07_lg}", "click", function(sym, e) {
         sym.play();

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_of07}", "click", function(sym, e) {
         sym.play('office2007');

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 18750, function(sym, e) {
         sym.stop();

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 19500, function(sym, e) {
         sym.stop(0);

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_edge_pr3}", "click", function(sym, e) {
         sym.play('edgePR3');

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_edge_pr3_lg}", "click", function(sym, e) {
         sym.play();

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_edgePR3blurb}", "click", function(sym, e) {
         sym.play();

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 20750, function(sym, e) {
         sym.stop();

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 21500, function(sym, e) {
         sym.stop(0);
         // insert code here

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_sketchupblurb}", "click", function(sym, e) {
         sym.play();

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_skMM_lg}", "click", function(sym, e) {
         sym.play();

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_skMM}", "click", function(sym, e) {
         sym.play('sketchup');
         

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 22750, function(sym, e) {
         sym.stop();

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 23500, function(sym, e) {
         sym.stop(0);

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_wrd07}", "click", function(sym, e) {
         sym.play('word');

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_wordblurb}", "click", function(sym, e) {
         sym.play();
         

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_wrd07_lg}", "click", function(sym, e) {
         sym.play();
         // insert code for mouse click here

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_flash5_5}", "click", function(sym, e) {
         sym.play('flash5_5');
         

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 24750, function(sym, e) {
         sym.stop();

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 25500, function(sym, e) {
         sym.stop(0);

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_flash5_5blurb}", "click", function(sym, e) {
         sym.play();
         

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_flash5_5_lg}", "click", function(sym, e) {
         sym.play();
         

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_fl4}", "click", function(sym, e) {
         sym.play('flash4');

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 26750, function(sym, e) {
         sym.stop();
         

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 27500, function(sym, e) {
         sym.stop(0);

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_flash4blurb}", "click", function(sym, e) {
         sym.play();

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_fl4_lg}", "click", function(sym, e) {
         sym.play();

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_digphto}", "click", function(sym, e) {
         sym.play('digiPhoto');
         

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_digiPhotoblurb}", "click", function(sym, e) {
         sym.play();
         

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_digphto_lg}", "click", function(sym, e) {
         sym.play();

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 28750, function(sym, e) {
         sym.stop();

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 29500, function(sym, e) {
         sym.stop(0);

      });
      //Edge binding end

   })("stage");
   //Edge symbol end:'stage'

   //=========================================================
   
   //Edge symbol: 'edgePR3'
   (function(symbolName) {   
   
      Symbol.bindElementAction(compId, symbolName, "${_buy}", "click", function(sym, e) {
         window.open("http://astore.amazon.com/boliroadgall-20/detail/B006OBBQFW", "_self");
         

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_bg}", "click", function(sym, e) {
         sym.play();

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_title}", "click", function(sym, e) {
         sym.play();

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_blurb}", "click", function(sym, e) {
         sym.play();

      });
      //Edge binding end

   })("edgePR3blurb");
   //Edge symbol end:'edgePR3blurb'

   //=========================================================
   
   //Edge symbol: 'edgePR3_1'
   (function(symbolName) {   
   
      Symbol.bindElementAction(compId, symbolName, "${_buy}", "click", function(sym, e) {
         window.open("http://astore.amazon.com/boliroadgall-20/detail/1449316255", "_self");
         

      });
         //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_bg}", "click", function(sym, e) {
         sym.play();

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_title}", "click", function(sym, e) {
         sym.play();

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_blurb}", "click", function(sym, e) {
         sym.play();

      });
      //Edge binding end

      })("flash6blurb");
   //Edge symbol end:'flash6blurb'

   //=========================================================
   
   //Edge symbol: 'flash6blurb_1'
   (function(symbolName) {   
   
      Symbol.bindElementAction(compId, symbolName, "${_buy}", "click", function(sym, e) {
         window.open("http://astore.amazon.com/boliroadgall-20/detail/1449393357", "_self");
         

      });
         //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_bg}", "click", function(sym, e) {
         sym.play();

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_title}", "click", function(sym, e) {
         sym.play();

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_blurb}", "click", function(sym, e) {
         sym.play();

      });
      //Edge binding end

      })("office2011blurb");
   //Edge symbol end:'office2011blurb'

   //=========================================================
   
   //Edge symbol: 'office2011blurb_1'
   (function(symbolName) {   
   
      Symbol.bindElementAction(compId, symbolName, "${_buy}", "click", function(sym, e) {
         window.open("http://astore.amazon.com/boliroadgall-20/detail/1449380255", "_self");
         

      });
         //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_bg}", "click", function(sym, e) {
         sym.play();

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_title}", "click", function(sym, e) {
         sym.play();

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_blurb}", "click", function(sym, e) {
         sym.play();

      });
      //Edge binding end

      })("flash5blurb");
   //Edge symbol end:'flash5blurb'

   //=========================================================
   
   //Edge symbol: 'flash6blurb_1'
   (function(symbolName) {   
   
      Symbol.bindElementAction(compId, symbolName, "${_buy}", "click", function(sym, e) {
         window.open("http://astore.amazon.com/boliroadgall-20/detail/0596510446", "_self");
         

      });
         //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_bg}", "click", function(sym, e) {
         sym.play();

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_title}", "click", function(sym, e) {
         sym.play();

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_blurb}", "click", function(sym, e) {
         sym.play();

      });
      //Edge binding end

      })("flash3blurb");
   //Edge symbol end:'flash3blurb'

   //=========================================================
   
   //Edge symbol: 'office2011blurb_1'
   (function(symbolName) {   
   
      Symbol.bindElementAction(compId, symbolName, "${_buy}", "click", function(sym, e) {
         window.open("http://astore.amazon.com/boliroadgall-20/detail/0596528302", "_self");
         

      });
         //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_bg}", "click", function(sym, e) {
         sym.play();

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_title}", "click", function(sym, e) {
         sym.play();

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_blurb}", "click", function(sym, e) {
         sym.play();

      });
      //Edge binding end

      })("word2007strtblurb");
   //Edge symbol end:'word2007strtblurb'

   //=========================================================
   
   //Edge symbol: 'edgePR3blurb_1'
   (function(symbolName) {   
   
      Symbol.bindElementAction(compId, symbolName, "${_buy}", "click", function(sym, e) {
         window.open("http://astore.amazon.com/boliroadgall-20/detail/1449330304", "_self");
         

      });
         //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_bg}", "click", function(sym, e) {
         sym.play();

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_title}", "click", function(sym, e) {
         sym.play();

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_blurb}", "click", function(sym, e) {
         sym.play();

      });
      //Edge binding end

      })("edgePR5blurb");
   //Edge symbol end:'edgePR5blurb'

   //=========================================================
   
   //Edge symbol: 'flash6blurb_1'
   (function(symbolName) {   
   
      Symbol.bindElementAction(compId, symbolName, "${_buy}", "click", function(sym, e) {
         window.open("http://astore.amazon.com/boliroadgall-20/detail/0596803362", "_self");
         

      });
         //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_bg}", "click", function(sym, e) {
         sym.play();

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_title}", "click", function(sym, e) {
         sym.play();

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_blurb}", "click", function(sym, e) {
         sym.play();

      });
      //Edge binding end

      })("premiereblurb");
   //Edge symbol end:'premiereblurb'

   //=========================================================
   
   //Edge symbol: 'premiereblurb_1'
   (function(symbolName) {   
   
      Symbol.bindElementAction(compId, symbolName, "${_buy}", "click", function(sym, e) {
         window.open("http://astore.amazon.com/boliroadgall-20/detail/0596514220", "_self");
         

      });
         //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_bg}", "click", function(sym, e) {
         sym.play();

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_title}", "click", function(sym, e) {
         sym.play();

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_blurb}", "click", function(sym, e) {
         sym.play();

      });
      //Edge binding end

      })("office2007blurb");
   //Edge symbol end:'office2007blurb'

   //=========================================================
   
   //Edge symbol: 'premiereblurb_1'
   (function(symbolName) {   
   
      Symbol.bindElementAction(compId, symbolName, "${_buy}", "click", function(sym, e) {
         window.open("http://astore.amazon.com/boliroadgall-20/detail/0596521464", "_self");
         

      });
         //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_bg}", "click", function(sym, e) {
         sym.play();

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_title}", "click", function(sym, e) {
         sym.play();

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_blurb}", "click", function(sym, e) {
         sym.play();

      });
      //Edge binding end

      })("sketchupblurb");
   //Edge symbol end:'sketchupblurb'

   //=========================================================
   
   //Edge symbol: 'sketchupblurb_1'
   (function(symbolName) {   
   
      Symbol.bindElementAction(compId, symbolName, "${_buy}", "click", function(sym, e) {
         window.open("http://astore.amazon.com/boliroadgall-20/detail/059652739X", "_self");
         

      });
         //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_bg}", "click", function(sym, e) {
         sym.play();

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_title}", "click", function(sym, e) {
         sym.play();

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_blurb}", "click", function(sym, e) {
         sym.play();

      });
      //Edge binding end

      })("wordblurb");
   //Edge symbol end:'wordblurb'

   //=========================================================
   
   //Edge symbol: 'wordblurb_1'
   (function(symbolName) {   
   
      Symbol.bindElementAction(compId, symbolName, "${_buy}", "click", function(sym, e) {
         window.open("http://astore.amazon.com/boliroadgall-20/detail/B005EI864U", "_self");
         

      });
         //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_bg}", "click", function(sym, e) {
         sym.play();

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_title}", "click", function(sym, e) {
         sym.play();

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_blurb}", "click", function(sym, e) {
         sym.play();

      });
      //Edge binding end

      })("flash5_5blurb");
   //Edge symbol end:'flash5_5blurb'

   //=========================================================
   
   //Edge symbol: 'flash5_5blurb_1'
   (function(symbolName) {   
   
      Symbol.bindElementAction(compId, symbolName, "${_buy}", "click", function(sym, e) {
         window.open("http://astore.amazon.com/boliroadgall-20/detail/0596522940", "_self");
         

      });
         //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_bg}", "click", function(sym, e) {
         sym.play();

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_title}", "click", function(sym, e) {
         sym.play();

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_blurb}", "click", function(sym, e) {
         sym.play();

      });
      //Edge binding end

      })("flash4blurb");
   //Edge symbol end:'flash4blurb'

   //=========================================================
   
   //Edge symbol: 'flash5blurb_1'
   (function(symbolName) {   
   
      Symbol.bindElementAction(compId, symbolName, "${_buy}", "click", function(sym, e) {
         window.open("http://astore.amazon.com/boliroadgall-20/detail/0596008414", "_self");
         

      });
         //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_bg}", "click", function(sym, e) {
         sym.play();

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_title}", "click", function(sym, e) {
         sym.play();

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_blurb}", "click", function(sym, e) {
         sym.play();

      });
      //Edge binding end

      })("digiPhotoblurb");
   //Edge symbol end:'digiPhotoblurb'

})(jQuery, AdobeEdge, "EDGE-3521704");