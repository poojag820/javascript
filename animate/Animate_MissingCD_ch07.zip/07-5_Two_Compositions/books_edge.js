/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
var im='images/';

var fonts = {};


var resources = [
];
var symbols = {
"stage": {
   version: "0.1.7",
   minimumCompatibleVersion: "0.1.7",
   build: "0.11.0.161",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
         dom: [
         {
            id:'digphto',
            type:'image',
            rect:['760','429','125','164','undefined','undefined'],
            fill:["rgba(0,0,0,0)",im+"digphto.jpg"],
            transform:[]
         },
         {
            id:'edge_pr3',
            type:'image',
            rect:['575','33','125','164','undefined','undefined'],
            cursor:['pointer'],
            fill:["rgba(0,0,0,0)",im+"edge_pr3.jpg"],
            transform:[]
         },
         {
            id:'fl3',
            type:'image',
            rect:['19','429','125','164','undefined','undefined'],
            cursor:['pointer'],
            fill:["rgba(0,0,0,0)",im+"fl3.jpg"],
            transform:[]
         },
         {
            id:'fl4',
            type:'image',
            rect:['760','234','125','164','undefined','undefined'],
            cursor:['pointer'],
            fill:["rgba(0,0,0,0)",im+"fl4.jpg"],
            transform:[]
         },
         {
            id:'fl5',
            type:'image',
            rect:['204','234','125','164','undefined','undefined'],
            cursor:['pointer'],
            fill:["rgba(0,0,0,0)",im+"fl5.jpg"],
            transform:[]
         },
         {
            id:'flash5_5',
            type:'image',
            rect:['760','33','125','164','undefined','undefined'],
            cursor:['pointer'],
            fill:["rgba(0,0,0,0)",im+"flash5_5.jpg"],
            transform:[]
         },
         {
            id:'edge_pr7',
            type:'image',
            rect:['19','33','125','164','undefined','undefined'],
            cursor:['pointer'],
            fill:["rgba(0,0,0,0)",im+"edge_pr7.jpg"]
         },
         {
            id:'flash6',
            type:'image',
            rect:['204','33','125','164','undefined','undefined'],
            cursor:['pointer'],
            fill:["rgba(0,0,0,0)",im+"flash6.jpg",'0%','-0.6%']
         },
         {
            id:'edge_pr5',
            type:'image',
            rect:['389','33','125','164','undefined','undefined'],
            cursor:['pointer'],
            fill:["rgba(0,0,0,0)",im+"edge_pr5.jpg"]
         },
         {
            id:'pe8MM',
            type:'image',
            rect:['389','234','125','164','undefined','undefined'],
            cursor:['pointer'],
            fill:["rgba(0,0,0,0)",im+"pe8MM.jpg"],
            transform:[]
         },
         {
            id:'of07',
            type:'image',
            rect:['389','429','125','164','undefined','undefined'],
            cursor:['pointer'],
            fill:["rgba(0,0,0,0)",im+"of07.jpg"],
            transform:[]
         },
         {
            id:'of2011',
            type:'image',
            rect:['19','234','125','164','undefined','undefined'],
            cursor:['pointer'],
            fill:["rgba(0,0,0,0)",im+"of2011.jpg"],
            transform:[]
         },
         {
            id:'skMM',
            type:'image',
            rect:['574','234','125','164','undefined','undefined'],
            cursor:['pointer'],
            fill:["rgba(0,0,0,0)",im+"skMM.jpg"],
            transform:[]
         },
         {
            id:'wrd07',
            type:'image',
            rect:['575','429','125','164','undefined','undefined'],
            cursor:['pointer'],
            fill:["rgba(0,0,0,0)",im+"wrd07.jpg"],
            transform:[]
         },
         {
            id:'wrd07strtr',
            type:'image',
            rect:['204','429','125','164','undefined','undefined'],
            cursor:['pointer'],
            fill:["rgba(0,0,0,0)",im+"wrd07strtr.jpg"],
            transform:[]
         },
         {
            id:'blackRect',
            display:'none',
            type:'rect',
            rect:['0','0','903px','620px','undefined','undefined'],
            opacity:0.645904541015625,
            fill:["rgba(0,0,0,1.00)"],
            stroke:[0,"rgb(0, 0, 0)","none"],
            transform:[]
         },
         {
            id:'digiPhotoblurb',
            display:'none',
            type:'rect',
            rect:['49','70','0','0','undefined','undefined'],
            cursor:['pointer']
         },
         {
            id:'digphto_lg',
            display:'none',
            type:'image',
            rect:['475','70','365','479','undefined','undefined'],
            cursor:['pointer'],
            fill:["rgba(0,0,0,0)",im+"digphto_lg.jpg"]
         },
         {
            id:'flash4blurb',
            display:'none',
            type:'rect',
            rect:['49','70','0','0','undefined','undefined'],
            cursor:['pointer']
         },
         {
            id:'fl4_lg',
            display:'none',
            type:'image',
            rect:['475','70','365','479','undefined','undefined'],
            cursor:['pointer'],
            fill:["rgba(0,0,0,0)",im+"fl4_lg.jpg"]
         },
         {
            id:'flash5_5blurb',
            display:'none',
            type:'rect',
            rect:['49','70','0','0','undefined','undefined'],
            cursor:['pointer']
         },
         {
            id:'flash5_5_lg',
            display:'none',
            type:'image',
            rect:['475','70','365','479','undefined','undefined'],
            cursor:['pointer'],
            fill:["rgba(0,0,0,0)",im+"flash5_5_lg.jpg"]
         },
         {
            id:'wordblurb',
            display:'none',
            type:'rect',
            rect:['49','70','0','0','undefined','undefined'],
            cursor:['pointer']
         },
         {
            id:'wrd07_lg',
            display:'none',
            type:'image',
            rect:['475','70','365','479','undefined','undefined'],
            cursor:['pointer'],
            fill:["rgba(0,0,0,0)",im+"wrd07_lg.jpg"]
         },
         {
            id:'sketchupblurb',
            display:'none',
            type:'rect',
            rect:['49','70','0','0','undefined','undefined'],
            cursor:['pointer']
         },
         {
            id:'skMM_lg',
            display:'none',
            type:'image',
            rect:['475','70','365','479','undefined','undefined'],
            cursor:['pointer'],
            fill:["rgba(0,0,0,0)",im+"skMM_lg.jpg"]
         },
         {
            id:'edgePR3blurb',
            display:'none',
            type:'rect',
            rect:['49','70','0','0','undefined','undefined'],
            cursor:['pointer']
         },
         {
            id:'edge_pr3_lg',
            display:'none',
            type:'image',
            rect:['475','70','365','479','undefined','undefined'],
            fill:["rgba(0,0,0,0)",im+"edge_pr3_lg.jpg"]
         },
         {
            id:'office2007blurb',
            display:'none',
            type:'rect',
            rect:['49','70','0','0','undefined','undefined'],
            cursor:['pointer']
         },
         {
            id:'of07_lg',
            display:'none',
            type:'image',
            rect:['475','70','365','479','undefined','undefined'],
            cursor:['pointer'],
            fill:["rgba(0,0,0,0)",im+"of07_lg.jpg"]
         },
         {
            id:'premiereblurb',
            display:'none',
            type:'rect',
            rect:['475','70','0','0','undefined','undefined'],
            cursor:['pointer']
         },
         {
            id:'pe8MM_lg',
            display:'none',
            type:'image',
            rect:['49','70','365','479','undefined','undefined'],
            cursor:['pointer'],
            fill:["rgba(0,0,0,0)",im+"pe8MM_lg.jpg"]
         },
         {
            id:'edgePR5blurb',
            display:'none',
            type:'rect',
            rect:['49','70','0','0','undefined','undefined'],
            cursor:['pointer']
         },
         {
            id:'edge_pr5_lg',
            display:'none',
            type:'image',
            rect:['475','70','365','479','undefined','undefined'],
            cursor:['pointer'],
            fill:["rgba(0,0,0,0)",im+"edge_pr5_lg.jpg"]
         },
         {
            id:'word2007strtblurb2',
            display:'none',
            type:'rect',
            rect:['475','70','0','0','undefined','undefined'],
            cursor:['pointer']
         },
         {
            id:'wrd07strtr_lg',
            display:'none',
            type:'image',
            rect:['49','70','365','479','undefined','undefined'],
            cursor:['pointer'],
            fill:["rgba(0,0,0,0)",im+"wrd07strtr_lg.jpg"]
         },
         {
            id:'flash3blurb',
            display:'none',
            type:'rect',
            rect:['475','70','0','0','undefined','undefined'],
            cursor:['pointer']
         },
         {
            id:'fl3_lg',
            display:'none',
            type:'image',
            rect:['49','70','365','479','undefined','undefined'],
            cursor:['pointer'],
            fill:["rgba(0,0,0,0)",im+"fl3_lg.jpg"]
         },
         {
            id:'flash5blurb',
            display:'none',
            type:'rect',
            rect:['475','70','0','0','undefined','undefined'],
            cursor:['pointer']
         },
         {
            id:'flash5_lg',
            display:'none',
            type:'image',
            rect:['49','70','365','479','undefined','undefined'],
            cursor:['pointer'],
            fill:["rgba(0,0,0,0)",im+"fl5_lg.jpg"]
         },
         {
            id:'office2011blurb',
            display:'none',
            type:'rect',
            rect:['475','70','0','0','undefined','undefined'],
            cursor:['pointer']
         },
         {
            id:'office2011_lg',
            display:'none',
            type:'image',
            rect:['49','70','365','479','undefined','undefined'],
            cursor:['pointer'],
            fill:["rgba(0,0,0,0)",im+"of2011_lg.jpg"]
         },
         {
            id:'flash6blurb',
            display:'none',
            type:'rect',
            rect:['475','70','0','0','undefined','undefined'],
            cursor:['pointer']
         },
         {
            id:'flash6_lg',
            display:'none',
            type:'image',
            rect:['42','60','358px','469px','undefined','undefined'],
            cursor:['pointer'],
            fill:["rgba(0,0,0,0)",im+"flash6_lg.jpg"],
            transform:[]
         },
         {
            id:'edgePR7blurb',
            display:'none',
            type:'rect',
            rect:['491','60','0','0','undefined','undefined'],
            cursor:['pointer']
         },
         {
            id:'edge_pr7_lg',
            display:'none',
            type:'image',
            rect:['19','33','125px','164px','undefined','undefined'],
            cursor:['pointer'],
            fill:["rgba(0,0,0,0)",im+"edge_pr7_lg.jpg"],
            transform:[]
         }],
         symbolInstances: [
         {
            id:'flash3blurb',
            symbolName:'flash3blurb'
         },
         {
            id:'edgePR5blurb',
            symbolName:'edgePR5blurb'
         },
         {
            id:'edgePR3blurb',
            symbolName:'edgePR3blurb'
         },
         {
            id:'edgePR7blurb',
            symbolName:'edgePR3blurb'
         },
         {
            id:'digiPhotoblurb',
            symbolName:'digiPhotoblurb'
         },
         {
            id:'premiereblurb',
            symbolName:'premiereblurb'
         },
         {
            id:'office2011blurb',
            symbolName:'office2011blurb'
         },
         {
            id:'office2007blurb',
            symbolName:'office2007blurb'
         },
         {
            id:'word2007strtblurb2',
            symbolName:'word2007strtblurb'
         },
         {
            id:'sketchupblurb',
            symbolName:'sketchupblurb'
         },
         {
            id:'flash6blurb',
            symbolName:'flash6blurb'
         },
         {
            id:'wordblurb',
            symbolName:'wordblurb'
         },
         {
            id:'flash4blurb',
            symbolName:'flash4blurb'
         },
         {
            id:'flash5blurb',
            symbolName:'flash5blurb'
         },
         {
            id:'flash5_5blurb',
            symbolName:'flash5_5blurb'
         }
         ]
      },
   states: {
      "Base State": {
         "${_word2007strtblurb2}": [
            ["style", "display", 'none'],
            ["style", "opacity", '0.1'],
            ["style", "cursor", 'pointer']
         ],
         "${_fl3_lg}": [
            ["style", "top", '429px'],
            ["style", "left", '19px'],
            ["style", "height", '164px'],
            ["style", "display", 'none'],
            ["style", "opacity", '0.1'],
            ["style", "cursor", 'pointer'],
            ["style", "width", '124.66666666667px']
         ],
         "${_wordblurb}": [
            ["style", "display", 'none'],
            ["style", "opacity", '0.1'],
            ["style", "cursor", 'pointer'],
            ["style", "-webkit-transform-origin", [50,53], {valueTemplate:'@@0@@% @@1@@%'} ],
            ["style", "-moz-transform-origin", [50,53],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "-ms-transform-origin", [50,53],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "msTransformOrigin", [50,53],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "-o-transform-origin", [50,53],{valueTemplate:'@@0@@% @@1@@%'}]
         ],
         "${_edge_pr5_lg}": [
            ["style", "top", '33px'],
            ["style", "left", '389px'],
            ["style", "display", 'none'],
            ["style", "height", '164.04109589041px'],
            ["style", "opacity", '0.1'],
            ["style", "cursor", 'pointer'],
            ["style", "width", '125px']
         ],
         "${_flash5_5}": [
            ["style", "top", '33px'],
            ["style", "cursor", 'pointer'],
            ["style", "left", '760px']
         ],
         "${_edge_pr7}": [
            ["style", "cursor", 'pointer']
         ],
         "${_flash5_lg}": [
            ["style", "top", '234px'],
            ["style", "left", '204px'],
            ["style", "display", 'none'],
            ["style", "height", '164.41441441441px'],
            ["style", "opacity", '0.12443942322451'],
            ["style", "cursor", 'pointer'],
            ["style", "width", '125px']
         ],
         "${_pe8MM}": [
            ["style", "top", '234px'],
            ["style", "left", '389px'],
            ["style", "cursor", 'pointer']
         ],
         "${_flash4blurb}": [
            ["style", "display", 'none'],
            ["style", "opacity", '0.1'],
            ["style", "cursor", 'pointer']
         ],
         "${_digiPhotoblurb}": [
            ["style", "display", 'none'],
            ["style", "opacity", '0.1'],
            ["style", "cursor", 'pointer']
         ],
         "${_flash6}": [
            ["style", "background-position", [0,-0.6], {valueTemplate:'@@0@@% @@1@@%'} ],
            ["style", "cursor", 'pointer']
         ],
         "${_flash6_lg}": [
            ["style", "top", '33px'],
            ["style", "left", '204px'],
            ["style", "display", 'none'],
            ["style", "height", '163.99617004395px'],
            ["style", "opacity", '0.20215992647059'],
            ["style", "cursor", 'pointer'],
            ["style", "width", '125.1825775602px']
         ],
         "${_wrd07_lg}": [
            ["style", "top", '429px'],
            ["style", "left", '575px'],
            ["style", "height", '164px'],
            ["style", "display", 'none'],
            ["style", "opacity", '0.1'],
            ["style", "cursor", 'pointer'],
            ["style", "width", '124.36666666667px']
         ],
         "${_flash3blurb}": [
            ["style", "display", 'none'],
            ["style", "opacity", '0.1'],
            ["style", "cursor", 'pointer']
         ],
         "${_flash5_5blurb}": [
            ["style", "display", 'none'],
            ["style", "opacity", '0.1'],
            ["style", "cursor", 'pointer']
         ],
         "${_premiereblurb}": [
            ["style", "display", 'none'],
            ["style", "opacity", '0.1'],
            ["style", "cursor", 'pointer']
         ],
         "${_edge_pr7_lg}": [
            ["style", "top", '33px'],
            ["style", "left", '19px'],
            ["style", "display", 'none'],
            ["style", "height", '164.04109589041px'],
            ["style", "cursor", 'pointer'],
            ["style", "width", '125px']
         ],
         "${_skMM}": [
            ["style", "top", '234px'],
            ["style", "cursor", 'pointer'],
            ["style", "left", '574px']
         ],
         "${_office2011_lg}": [
            ["style", "top", '234px'],
            ["style", "left", '19px'],
            ["style", "display", 'none'],
            ["style", "height", '163.79310344828px'],
            ["style", "opacity", '0.20032169117647'],
            ["style", "cursor", 'pointer'],
            ["style", "width", '125px']
         ],
         "${_wrd07strtr}": [
            ["style", "top", '429px'],
            ["style", "cursor", 'pointer'],
            ["style", "left", '204px']
         ],
         "${_digphto_lg}": [
            ["style", "top", '429px'],
            ["style", "left", '760px'],
            ["style", "height", '164.04109589041px'],
            ["style", "display", 'none'],
            ["style", "opacity", '0.1'],
            ["style", "cursor", 'pointer'],
            ["style", "width", '125px']
         ],
         "${_flash5blurb}": [
            ["style", "display", 'none'],
            ["style", "opacity", '0.086488970588235'],
            ["style", "cursor", 'pointer']
         ],
         "${_blackRect}": [
            ["color", "background-color", 'rgba(0,0,0,1.00)'],
            ["style", "top", '0px'],
            ["style", "display", 'none'],
            ["style", "overflow", 'visible'],
            ["style", "height", '620px'],
            ["style", "opacity", '0'],
            ["style", "left", '0px'],
            ["style", "width", '903px']
         ],
         "${_fl5}": [
            ["style", "top", '234px'],
            ["style", "cursor", 'pointer'],
            ["style", "left", '204px']
         ],
         "${_edgePR7blurb}": [
            ["transform", "scaleY", '0.98'],
            ["style", "left", '484px'],
            ["transform", "scaleX", '0.98'],
            ["style", "opacity", '0'],
            ["style", "cursor", 'pointer'],
            ["style", "display", 'none']
         ],
         "${_edgePR3blurb}": [
            ["style", "display", 'none'],
            ["style", "opacity", '0.1'],
            ["style", "cursor", 'pointer']
         ],
         "${_digphto}": [
            ["style", "left", '760px'],
            ["style", "top", '429px']
         ],
         "${_wrd07strtr_lg}": [
            ["style", "top", '429px'],
            ["style", "left", '204px'],
            ["style", "height", '164px'],
            ["style", "display", 'none'],
            ["style", "opacity", '0.1'],
            ["style", "cursor", 'pointer'],
            ["style", "width", '125.64516129032px']
         ],
         "${_fl4}": [
            ["style", "top", '234px'],
            ["style", "cursor", 'pointer'],
            ["style", "left", '760px']
         ],
         "${_sketchupblurb}": [
            ["style", "display", 'none'],
            ["style", "opacity", '0.1'],
            ["style", "cursor", 'pointer']
         ],
         "${_flash6blurb}": [
            ["style", "display", 'none'],
            ["style", "opacity", '0.12904411764706'],
            ["style", "cursor", 'pointer']
         ],
         "${_pe8MM_lg}": [
            ["style", "top", '234px'],
            ["style", "left", '389px'],
            ["style", "height", '164.13551401869px'],
            ["style", "display", 'none'],
            ["style", "opacity", '0.1'],
            ["style", "cursor", 'pointer'],
            ["style", "width", '125px']
         ],
         "${_fl3}": [
            ["style", "top", '429px'],
            ["style", "cursor", 'pointer'],
            ["style", "left", '19px']
         ],
         "${_of07_lg}": [
            ["style", "top", '429px'],
            ["style", "left", '389px'],
            ["style", "height", '164.04109589041px'],
            ["style", "display", 'none'],
            ["style", "opacity", '0.1'],
            ["style", "cursor", 'pointer'],
            ["style", "width", '125px']
         ],
         "${_of07}": [
            ["style", "top", '429px'],
            ["style", "cursor", 'pointer'],
            ["style", "left", '389px']
         ],
         "${_edge_pr3_lg}": [
            ["style", "top", '33px'],
            ["style", "display", 'none'],
            ["style", "height", '163.99082568807px'],
            ["style", "opacity", '0.1'],
            ["style", "left", '575px'],
            ["style", "width", '125px']
         ],
         "${_edgePR5blurb}": [
            ["style", "display", 'none'],
            ["style", "opacity", '0.1'],
            ["style", "cursor", 'pointer']
         ],
         "${_fl4_lg}": [
            ["style", "top", '234px'],
            ["style", "left", '760px'],
            ["style", "height", '164.31924882629px'],
            ["style", "display", 'none'],
            ["style", "opacity", '0.1'],
            ["style", "cursor", 'pointer'],
            ["style", "width", '125px']
         ],
         "${_flash5_5_lg}": [
            ["style", "top", '33px'],
            ["style", "left", '760px'],
            ["style", "height", '164.04109589041px'],
            ["style", "display", 'none'],
            ["style", "opacity", '0.1'],
            ["style", "cursor", 'pointer'],
            ["style", "width", '125px']
         ],
         "${_edge_pr5}": [
            ["style", "cursor", 'pointer']
         ],
         "${_edge_pr3}": [
            ["style", "top", '33px'],
            ["style", "cursor", 'pointer'],
            ["style", "left", '575px']
         ],
         "${_office2007blurb}": [
            ["style", "display", 'none'],
            ["style", "opacity", '0.1'],
            ["style", "cursor", 'pointer']
         ],
         "${_office2011blurb}": [
            ["style", "display", 'none'],
            ["style", "opacity", '0.11957720588235'],
            ["style", "cursor", 'pointer']
         ],
         "${_Stage}": [
            ["style", "height", '620px'],
            ["color", "background-color", 'rgba(255,255,255,1)'],
            ["style", "width", '903px']
         ],
         "${_skMM_lg}": [
            ["style", "top", '234px'],
            ["style", "left", '574px'],
            ["style", "height", '163.75px'],
            ["style", "display", 'none'],
            ["style", "opacity", '0.1'],
            ["style", "cursor", 'pointer'],
            ["style", "width", '125px']
         ],
         "${_of2011}": [
            ["style", "top", '234px'],
            ["style", "cursor", 'pointer'],
            ["style", "left", '19px']
         ],
         "${_wrd07}": [
            ["style", "top", '429px'],
            ["style", "cursor", 'pointer'],
            ["style", "left", '575px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 29500,
         autoPlay: true,
         labels: {
            "edgePR7": 250,
            "flash6": 2000,
            "office2011": 4000,
            "flash5": 6000,
            "flash3": 8000,
            "word07strt": 10000,
            "edgePR5": 12000,
            "premiere": 14000,
            "office2007": 16000,
            "edgePR3": 18000,
            "sketchup": 20000,
            "word": 22000,
            "flash5_5": 24000,
            "flash4": 26000,
            "digiPhoto": 28000
         },
         timeline: [
            { id: "eid53", tween: [ "style", "${_edge_pr7_lg}", "left", '42px', { fromValue: '19px'}], position: 250, duration: 750 },
            { id: "eid58", tween: [ "style", "${_edge_pr7_lg}", "left", '19px', { fromValue: '42px'}], position: 1000, duration: 750 },
            { id: "eid421", tween: [ "style", "${_wrd07_lg}", "width", '365px', { fromValue: '124.36666666667px'}], position: 22000, duration: 750 },
            { id: "eid428", tween: [ "style", "${_wrd07_lg}", "width", '124.36666666667px', { fromValue: '365px'}], position: 22750, duration: 750 },
            { id: "eid367", tween: [ "style", "${_edgePR3blurb}", "opacity", '1', { fromValue: '0.1'}], position: 18000, duration: 750 },
            { id: "eid368", tween: [ "style", "${_edgePR3blurb}", "opacity", '0.1', { fromValue: '1'}], position: 18750, duration: 750 },
            { id: "eid166", tween: [ "style", "${_flash5blurb}", "opacity", '1', { fromValue: '0.086488970588235'}], position: 6000, duration: 750 },
            { id: "eid163", tween: [ "style", "${_flash5blurb}", "opacity", '0.086488970588235', { fromValue: '1'}], position: 6750, duration: 750 },
            { id: "eid108", tween: [ "style", "${_flash6blurb}", "opacity", '0.95', { fromValue: '0.12904411764706'}], position: 2000, duration: 750 },
            { id: "eid110", tween: [ "style", "${_flash6blurb}", "opacity", '0.12904411764706', { fromValue: '0.95'}], position: 2750, duration: 750 },
            { id: "eid506", tween: [ "style", "${_flash4blurb}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid509", tween: [ "style", "${_flash4blurb}", "display", 'block', { fromValue: 'none'}], position: 26000, duration: 0 },
            { id: "eid512", tween: [ "style", "${_flash4blurb}", "display", 'none', { fromValue: 'block'}], position: 27500, duration: 0 },
            { id: "eid73", tween: [ "style", "${_flash6_lg}", "top", '70px', { fromValue: '33px'}], position: 2000, duration: 750 },
            { id: "eid98", tween: [ "style", "${_flash6_lg}", "top", '33px', { fromValue: '70px'}], position: 2750, duration: 750 },
            { id: "eid347", tween: [ "style", "${_of07_lg}", "width", '365px', { fromValue: '125px'}], position: 16000, duration: 750 },
            { id: "eid354", tween: [ "style", "${_of07_lg}", "width", '125px', { fromValue: '365px'}], position: 16750, duration: 750 },
            { id: "eid396", tween: [ "style", "${_skMM_lg}", "left", '475px', { fromValue: '574px'}], position: 20000, duration: 750 },
            { id: "eid401", tween: [ "style", "${_skMM_lg}", "left", '574px', { fromValue: '475px'}], position: 20750, duration: 750 },
            { id: "eid248", tween: [ "style", "${_edge_pr5_lg}", "opacity", '1', { fromValue: '0.1'}], position: 12000, duration: 750 },
            { id: "eid252", tween: [ "style", "${_edge_pr5_lg}", "opacity", '0.1', { fromValue: '1'}], position: 12750, duration: 750 },
            { id: "eid77", tween: [ "style", "${_flash6_lg}", "width", '365px', { fromValue: '125.1825775602px'}], position: 2000, duration: 750 },
            { id: "eid99", tween: [ "style", "${_flash6_lg}", "width", '125.1825775602px', { fromValue: '365px'}], position: 2750, duration: 750 },
            { id: "eid398", tween: [ "style", "${_skMM_lg}", "top", '70px', { fromValue: '234px'}], position: 20000, duration: 750 },
            { id: "eid405", tween: [ "style", "${_skMM_lg}", "top", '234px', { fromValue: '70px'}], position: 20750, duration: 750 },
            { id: "eid67", tween: [ "transform", "${_edgePR7blurb}", "scaleY", '0.98', { fromValue: '0.98'}], position: 1000, duration: 0 },
            { id: "eid50", tween: [ "style", "${_blackRect}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid55", tween: [ "style", "${_blackRect}", "display", 'block', { fromValue: 'none'}], position: 250, duration: 0 },
            { id: "eid69", tween: [ "style", "${_blackRect}", "display", 'none', { fromValue: 'block'}], position: 1750, duration: 0 },
            { id: "eid90", tween: [ "style", "${_blackRect}", "display", 'block', { fromValue: 'none'}], position: 2000, duration: 0 },
            { id: "eid93", tween: [ "style", "${_blackRect}", "display", 'none', { fromValue: 'block'}], position: 3500, duration: 0 },
            { id: "eid169", tween: [ "style", "${_blackRect}", "display", 'block', { fromValue: 'none'}], position: 4000, duration: 0 },
            { id: "eid172", tween: [ "style", "${_blackRect}", "display", 'none', { fromValue: 'block'}], position: 5500, duration: 0 },
            { id: "eid173", tween: [ "style", "${_blackRect}", "display", 'block', { fromValue: 'none'}], position: 6000, duration: 0 },
            { id: "eid176", tween: [ "style", "${_blackRect}", "display", 'none', { fromValue: 'block'}], position: 7500, duration: 0 },
            { id: "eid259", tween: [ "style", "${_blackRect}", "display", 'block', { fromValue: 'none'}], position: 8000, duration: 0 },
            { id: "eid262", tween: [ "style", "${_blackRect}", "display", 'none', { fromValue: 'block'}], position: 9500, duration: 0 },
            { id: "eid255", tween: [ "style", "${_blackRect}", "display", 'block', { fromValue: 'none'}], position: 10000, duration: 0 },
            { id: "eid258", tween: [ "style", "${_blackRect}", "display", 'none', { fromValue: 'block'}], position: 11500, duration: 0 },
            { id: "eid263", tween: [ "style", "${_blackRect}", "display", 'block', { fromValue: 'none'}], position: 12000, duration: 0 },
            { id: "eid266", tween: [ "style", "${_blackRect}", "display", 'none', { fromValue: 'block'}], position: 13500, duration: 0 },
            { id: "eid293", tween: [ "style", "${_blackRect}", "display", 'block', { fromValue: 'none'}], position: 14000, duration: 0 },
            { id: "eid296", tween: [ "style", "${_blackRect}", "display", 'none', { fromValue: 'block'}], position: 15500, duration: 0 },
            { id: "eid336", tween: [ "style", "${_blackRect}", "display", 'block', { fromValue: 'none'}], position: 16000, duration: 0 },
            { id: "eid339", tween: [ "style", "${_blackRect}", "display", 'none', { fromValue: 'block'}], position: 17500, duration: 0 },
            { id: "eid448", tween: [ "style", "${_blackRect}", "display", 'block', { fromValue: 'none'}], position: 18000, duration: 0 },
            { id: "eid451", tween: [ "style", "${_blackRect}", "display", 'none', { fromValue: 'block'}], position: 19500, duration: 0 },
            { id: "eid452", tween: [ "style", "${_blackRect}", "display", 'block', { fromValue: 'none'}], position: 20000, duration: 0 },
            { id: "eid455", tween: [ "style", "${_blackRect}", "display", 'none', { fromValue: 'block'}], position: 21500, duration: 0 },
            { id: "eid456", tween: [ "style", "${_blackRect}", "display", 'block', { fromValue: 'none'}], position: 22000, duration: 0 },
            { id: "eid459", tween: [ "style", "${_blackRect}", "display", 'none', { fromValue: 'block'}], position: 23500, duration: 0 },
            { id: "eid576", tween: [ "style", "${_blackRect}", "display", 'block', { fromValue: 'none'}], position: 24000, duration: 0 },
            { id: "eid579", tween: [ "style", "${_blackRect}", "display", 'none', { fromValue: 'block'}], position: 25500, duration: 0 },
            { id: "eid584", tween: [ "style", "${_blackRect}", "display", 'block', { fromValue: 'none'}], position: 26000, duration: 0 },
            { id: "eid587", tween: [ "style", "${_blackRect}", "display", 'none', { fromValue: 'block'}], position: 27500, duration: 0 },
            { id: "eid588", tween: [ "style", "${_blackRect}", "display", 'block', { fromValue: 'none'}], position: 28000, duration: 0 },
            { id: "eid591", tween: [ "style", "${_blackRect}", "display", 'none', { fromValue: 'block'}], position: 29500, duration: 0 },
            { id: "eid341", tween: [ "style", "${_office2007blurb}", "opacity", '1', { fromValue: '0.1'}], position: 16000, duration: 750 },
            { id: "eid342", tween: [ "style", "${_office2007blurb}", "opacity", '0.1', { fromValue: '1'}], position: 16750, duration: 750 },
            { id: "eid400", tween: [ "style", "${_skMM_lg}", "opacity", '1', { fromValue: '0.1'}], position: 20000, duration: 750 },
            { id: "eid403", tween: [ "style", "${_skMM_lg}", "opacity", '0.1', { fromValue: '1'}], position: 20750, duration: 750 },
            { id: "eid232", tween: [ "style", "${_edge_pr5_lg}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid233", tween: [ "style", "${_edge_pr5_lg}", "display", 'block', { fromValue: 'none'}], position: 12000, duration: 0 },
            { id: "eid254", tween: [ "style", "${_edge_pr5_lg}", "display", 'none', { fromValue: 'block'}], position: 13500, duration: 0 },
            { id: "eid130", tween: [ "style", "${_office2011_lg}", "height", '479px', { fromValue: '163.79310344828px'}], position: 4000, duration: 750 },
            { id: "eid137", tween: [ "style", "${_office2011_lg}", "height", '163.79310344828px', { fromValue: '479px'}], position: 4750, duration: 750 },
            { id: "eid34", tween: [ "style", "${_edgePR7blurb}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid18", tween: [ "style", "${_edgePR7blurb}", "display", 'block', { fromValue: 'none'}], position: 250, duration: 0 },
            { id: "eid40", tween: [ "style", "${_edgePR7blurb}", "display", 'none', { fromValue: 'block'}], position: 1750, duration: 0 },
            { id: "eid481", tween: [ "style", "${_flash5_5_lg}", "height", '479px', { fromValue: '164.04109589041px'}], position: 24000, duration: 750 },
            { id: "eid498", tween: [ "style", "${_flash5_5_lg}", "height", '164.04109589041px', { fromValue: '479px'}], position: 24750, duration: 750 },
            { id: "eid66", tween: [ "transform", "${_edgePR7blurb}", "scaleX", '0.98', { fromValue: '0.98'}], position: 1000, duration: 0 },
            { id: "eid182", tween: [ "style", "${_fl3_lg}", "height", '479px', { fromValue: '164px'}], position: 8000, duration: 750 },
            { id: "eid194", tween: [ "style", "${_fl3_lg}", "height", '164px', { fromValue: '479px'}], position: 8750, duration: 750 },
            { id: "eid272", tween: [ "style", "${_premiereblurb}", "opacity", '1', { fromValue: '0.1'}], position: 14000, duration: 750 },
            { id: "eid273", tween: [ "style", "${_premiereblurb}", "opacity", '0.1', { fromValue: '1'}], position: 14750, duration: 750 },
            { id: "eid143", tween: [ "style", "${_flash5blurb}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid167", tween: [ "style", "${_flash5blurb}", "display", 'block', { fromValue: 'none'}], position: 6000, duration: 0 },
            { id: "eid162", tween: [ "style", "${_flash5blurb}", "display", 'block', { fromValue: 'block'}], position: 6750, duration: 0 },
            { id: "eid168", tween: [ "style", "${_flash5blurb}", "display", 'none', { fromValue: 'block'}], position: 7500, duration: 0 },
            { id: "eid351", tween: [ "style", "${_of07_lg}", "top", '70px', { fromValue: '429px'}], position: 16000, duration: 750 },
            { id: "eid355", tween: [ "style", "${_of07_lg}", "top", '429px', { fromValue: '70px'}], position: 16750, duration: 750 },
            { id: "eid120", tween: [ "style", "${_office2011blurb}", "opacity", '1', { fromValue: '0.11957720588235'}], position: 4000, duration: 750 },
            { id: "eid124", tween: [ "style", "${_office2011blurb}", "opacity", '0.11957720588235', { fromValue: '1'}], position: 4750, duration: 750 },
            { id: "eid225", tween: [ "style", "${_word2007strtblurb2}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid226", tween: [ "style", "${_word2007strtblurb2}", "display", 'block', { fromValue: 'none'}], position: 10000, duration: 0 },
            { id: "eid229", tween: [ "style", "${_word2007strtblurb2}", "display", 'none', { fromValue: 'block'}], position: 11500, duration: 0 },
            { id: "eid434", tween: [ "style", "${_wordblurb}", "opacity", '1', { fromValue: '0.1'}], position: 22000, duration: 750 },
            { id: "eid435", tween: [ "style", "${_wordblurb}", "opacity", '0.1', { fromValue: '1'}], position: 22750, duration: 750 },
            { id: "eid33", tween: [ "style", "${_blackRect}", "opacity", '0.645905', { fromValue: '0'}], position: 250, duration: 750 },
            { id: "eid47", tween: [ "style", "${_blackRect}", "opacity", '0', { fromValue: '0.645905'}], position: 1000, duration: 750 },
            { id: "eid91", tween: [ "style", "${_blackRect}", "opacity", '0.645905', { fromValue: '0'}], position: 2000, duration: 750 },
            { id: "eid92", tween: [ "style", "${_blackRect}", "opacity", '0', { fromValue: '0.645905'}], position: 2750, duration: 750 },
            { id: "eid170", tween: [ "style", "${_blackRect}", "opacity", '0.645905', { fromValue: '0'}], position: 4000, duration: 750 },
            { id: "eid171", tween: [ "style", "${_blackRect}", "opacity", '0', { fromValue: '0.645905'}], position: 4750, duration: 750 },
            { id: "eid174", tween: [ "style", "${_blackRect}", "opacity", '0.645905', { fromValue: '0'}], position: 6000, duration: 750 },
            { id: "eid175", tween: [ "style", "${_blackRect}", "opacity", '0', { fromValue: '0.645905'}], position: 6750, duration: 750 },
            { id: "eid260", tween: [ "style", "${_blackRect}", "opacity", '0.645905', { fromValue: '0'}], position: 8000, duration: 750 },
            { id: "eid261", tween: [ "style", "${_blackRect}", "opacity", '0', { fromValue: '0.645905'}], position: 8750, duration: 750 },
            { id: "eid256", tween: [ "style", "${_blackRect}", "opacity", '0.645905', { fromValue: '0'}], position: 10000, duration: 750 },
            { id: "eid257", tween: [ "style", "${_blackRect}", "opacity", '0', { fromValue: '0.645905'}], position: 10750, duration: 750 },
            { id: "eid264", tween: [ "style", "${_blackRect}", "opacity", '0.645905', { fromValue: '0'}], position: 12000, duration: 750 },
            { id: "eid265", tween: [ "style", "${_blackRect}", "opacity", '0', { fromValue: '0.645905'}], position: 12750, duration: 750 },
            { id: "eid297", tween: [ "style", "${_blackRect}", "opacity", '0.645905', { fromValue: '0'}], position: 14000, duration: 750 },
            { id: "eid298", tween: [ "style", "${_blackRect}", "opacity", '0.645905', { fromValue: '0.645905'}], position: 14750, duration: 750 },
            { id: "eid337", tween: [ "style", "${_blackRect}", "opacity", '0.645905', { fromValue: '0'}], position: 16000, duration: 750 },
            { id: "eid338", tween: [ "style", "${_blackRect}", "opacity", '0.645905', { fromValue: '0.645905'}], position: 16750, duration: 750 },
            { id: "eid449", tween: [ "style", "${_blackRect}", "opacity", '0.645905', { fromValue: '0'}], position: 18000, duration: 750 },
            { id: "eid450", tween: [ "style", "${_blackRect}", "opacity", '0.645905', { fromValue: '0.645905'}], position: 18750, duration: 750 },
            { id: "eid453", tween: [ "style", "${_blackRect}", "opacity", '0.645905', { fromValue: '0'}], position: 20000, duration: 750 },
            { id: "eid454", tween: [ "style", "${_blackRect}", "opacity", '0.645905', { fromValue: '0.645905'}], position: 20750, duration: 750 },
            { id: "eid457", tween: [ "style", "${_blackRect}", "opacity", '0.645905', { fromValue: '0'}], position: 22000, duration: 750 },
            { id: "eid458", tween: [ "style", "${_blackRect}", "opacity", '0.645905', { fromValue: '0.645905'}], position: 22750, duration: 750 },
            { id: "eid577", tween: [ "style", "${_blackRect}", "opacity", '0.645905', { fromValue: '0'}], position: 24000, duration: 750 },
            { id: "eid578", tween: [ "style", "${_blackRect}", "opacity", '0.645905', { fromValue: '0.645905'}], position: 24750, duration: 750 },
            { id: "eid585", tween: [ "style", "${_blackRect}", "opacity", '0.645905', { fromValue: '0'}], position: 26000, duration: 750 },
            { id: "eid586", tween: [ "style", "${_blackRect}", "opacity", '0.645905', { fromValue: '0.645905'}], position: 26750, duration: 750 },
            { id: "eid589", tween: [ "style", "${_blackRect}", "opacity", '0.645905', { fromValue: '0'}], position: 28000, duration: 750 },
            { id: "eid590", tween: [ "style", "${_blackRect}", "opacity", '0.645905', { fromValue: '0.645905'}], position: 28750, duration: 750 },
            { id: "eid153", tween: [ "style", "${_flash5_lg}", "width", '365px', { fromValue: '125px'}], position: 6000, duration: 750 },
            { id: "eid159", tween: [ "style", "${_flash5_lg}", "width", '125px', { fromValue: '365px'}], position: 6750, duration: 750 },
            { id: "eid380", tween: [ "style", "${_edge_pr3_lg}", "opacity", '1', { fromValue: '0.1'}], position: 18000, duration: 750 },
            { id: "eid382", tween: [ "style", "${_edge_pr3_lg}", "opacity", '0.1', { fromValue: '1'}], position: 18750, duration: 750 },
            { id: "eid212", tween: [ "style", "${_wrd07strtr_lg}", "top", '70px', { fromValue: '429px'}], position: 10000, duration: 750 },
            { id: "eid219", tween: [ "style", "${_wrd07strtr_lg}", "top", '429px', { fromValue: '70px'}], position: 10750, duration: 750 },
            { id: "eid75", tween: [ "style", "${_flash6_lg}", "height", '479.25207756233px', { fromValue: '163.99617004395px'}], position: 2000, duration: 750 },
            { id: "eid97", tween: [ "style", "${_flash6_lg}", "height", '163.99617004395px', { fromValue: '479.25207756233px'}], position: 2750, duration: 750 },
            { id: "eid154", tween: [ "style", "${_flash5_lg}", "height", '479px', { fromValue: '164.41441441441px'}], position: 6000, duration: 750 },
            { id: "eid160", tween: [ "style", "${_flash5_lg}", "height", '164.41441441441px', { fromValue: '479px'}], position: 6750, duration: 750 },
            { id: "eid523", tween: [ "style", "${_fl4_lg}", "opacity", '1', { fromValue: '0.1'}], position: 26000, duration: 750 },
            { id: "eid524", tween: [ "style", "${_fl4_lg}", "opacity", '0.1', { fromValue: '1'}], position: 26750, duration: 750 },
            { id: "eid419", tween: [ "style", "${_wrd07_lg}", "height", '479px', { fromValue: '164px'}], position: 22000, duration: 750 },
            { id: "eid431", tween: [ "style", "${_wrd07_lg}", "height", '164px', { fromValue: '479px'}], position: 22750, duration: 750 },
            { id: "eid477", tween: [ "style", "${_flash5_5blurb}", "opacity", '1', { fromValue: '0.1'}], position: 24000, duration: 750 },
            { id: "eid478", tween: [ "style", "${_flash5_5blurb}", "opacity", '0.1', { fromValue: '1'}], position: 24750, duration: 750 },
            { id: "eid210", tween: [ "style", "${_wrd07strtr_lg}", "height", '479px', { fromValue: '164px'}], position: 10000, duration: 750 },
            { id: "eid223", tween: [ "style", "${_wrd07strtr_lg}", "height", '164px', { fromValue: '479px'}], position: 10750, duration: 750 },
            { id: "eid115", tween: [ "style", "${_office2011_lg}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid117", tween: [ "style", "${_office2011_lg}", "display", 'block', { fromValue: 'none'}], position: 4000, duration: 0 },
            { id: "eid136", tween: [ "style", "${_office2011_lg}", "display", 'none', { fromValue: 'block'}], position: 5500, duration: 0 },
            { id: "eid126", tween: [ "style", "${_office2011_lg}", "left", '49px', { fromValue: '19px'}], position: 4000, duration: 750 },
            { id: "eid140", tween: [ "style", "${_office2011_lg}", "left", '19px', { fromValue: '49px'}], position: 4750, duration: 750 },
            { id: "eid360", tween: [ "style", "${_edge_pr3_lg}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid363", tween: [ "style", "${_edge_pr3_lg}", "display", 'block', { fromValue: 'none'}], position: 18000, duration: 0 },
            { id: "eid386", tween: [ "style", "${_edge_pr3_lg}", "display", 'none', { fromValue: 'block'}], position: 19500, duration: 0 },
            { id: "eid231", tween: [ "style", "${_edgePR5blurb}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid234", tween: [ "style", "${_edgePR5blurb}", "display", 'block', { fromValue: 'none'}], position: 12000, duration: 0 },
            { id: "eid238", tween: [ "style", "${_edgePR5blurb}", "display", 'none', { fromValue: 'block'}], position: 13500, duration: 0 },
            { id: "eid278", tween: [ "style", "${_pe8MM_lg}", "height", '479px', { fromValue: '164.13551401869px'}], position: 14000, duration: 750 },
            { id: "eid291", tween: [ "style", "${_pe8MM_lg}", "height", '164.13551401869px', { fromValue: '479px'}], position: 14750, duration: 750 },
            { id: "eid535", tween: [ "style", "${_digphto_lg}", "opacity", '1', { fromValue: '0.1'}], position: 28000, duration: 750 },
            { id: "eid544", tween: [ "style", "${_digphto_lg}", "opacity", '0.1', { fromValue: '1'}], position: 28750, duration: 750 },
            { id: "eid71", tween: [ "style", "${_flash6_lg}", "left", '49px', { fromValue: '204px'}], position: 2000, duration: 750 },
            { id: "eid100", tween: [ "style", "${_flash6_lg}", "left", '204px', { fromValue: '49px'}], position: 2750, duration: 750 },
            { id: "eid152", tween: [ "style", "${_flash5_lg}", "opacity", '1', { fromValue: '0.12443942322451'}], position: 6000, duration: 750 },
            { id: "eid158", tween: [ "style", "${_flash5_lg}", "opacity", '0.12443942322451', { fromValue: '1'}], position: 6750, duration: 750 },
            { id: "eid299", tween: [ "style", "${_of07_lg}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid302", tween: [ "style", "${_of07_lg}", "display", 'block', { fromValue: 'none'}], position: 16000, duration: 0 },
            { id: "eid358", tween: [ "style", "${_of07_lg}", "display", 'block', { fromValue: 'block'}], position: 17500, duration: 0 },
            { id: "eid551", tween: [ "style", "${_digiPhotoblurb}", "opacity", '1', { fromValue: '0.1'}], position: 28000, duration: 750 },
            { id: "eid554", tween: [ "style", "${_digiPhotoblurb}", "opacity", '0.1', { fromValue: '1'}], position: 28750, duration: 750 },
            { id: "eid372", tween: [ "style", "${_edge_pr3_lg}", "height", '479px', { fromValue: '163.99082568807px'}], position: 18000, duration: 750 },
            { id: "eid383", tween: [ "style", "${_edge_pr3_lg}", "height", '163.99082568807px', { fromValue: '479px'}], position: 18750, duration: 750 },
            { id: "eid177", tween: [ "style", "${_fl3_lg}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid180", tween: [ "style", "${_fl3_lg}", "display", 'block', { fromValue: 'none'}], position: 8000, duration: 0 },
            { id: "eid196", tween: [ "style", "${_fl3_lg}", "display", 'none', { fromValue: 'block'}], position: 9500, duration: 0 },
            { id: "eid178", tween: [ "style", "${_flash3blurb}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid179", tween: [ "style", "${_flash3blurb}", "display", 'block', { fromValue: 'none'}], position: 8000, duration: 0 },
            { id: "eid200", tween: [ "style", "${_flash3blurb}", "display", 'none', { fromValue: 'block'}], position: 9500, duration: 0 },
            { id: "eid353", tween: [ "style", "${_of07_lg}", "opacity", '1', { fromValue: '0.1'}], position: 16000, duration: 750 },
            { id: "eid356", tween: [ "style", "${_of07_lg}", "opacity", '0.1', { fromValue: '1'}], position: 16750, duration: 750 },
            { id: "eid394", tween: [ "style", "${_skMM_lg}", "width", '365px', { fromValue: '125px'}], position: 20000, duration: 750 },
            { id: "eid402", tween: [ "style", "${_skMM_lg}", "width", '125px', { fromValue: '365px'}], position: 20750, duration: 750 },
            { id: "eid150", tween: [ "style", "${_flash5_lg}", "top", '70px', { fromValue: '234px'}], position: 6000, duration: 750 },
            { id: "eid156", tween: [ "style", "${_flash5_lg}", "top", '234px', { fromValue: '70px'}], position: 6750, duration: 750 },
            { id: "eid543", tween: [ "style", "${_digphto_lg}", "top", '70px', { fromValue: '429px'}], position: 28000, duration: 750 },
            { id: "eid548", tween: [ "style", "${_digphto_lg}", "top", '429px', { fromValue: '70px'}], position: 28750, duration: 750 },
            { id: "eid236", tween: [ "style", "${_edgePR5blurb}", "opacity", '1', { fromValue: '0.1'}], position: 12000, duration: 750 },
            { id: "eid237", tween: [ "style", "${_edgePR5blurb}", "opacity", '0.1', { fromValue: '1'}], position: 12750, duration: 750 },
            { id: "eid141", tween: [ "style", "${_flash5_lg}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid144", tween: [ "style", "${_flash5_lg}", "display", 'block', { fromValue: 'none'}], position: 6000, duration: 0 },
            { id: "eid155", tween: [ "style", "${_flash5_lg}", "display", 'block', { fromValue: 'block'}], position: 6750, duration: 0 },
            { id: "eid161", tween: [ "style", "${_flash5_lg}", "display", 'none', { fromValue: 'block'}], position: 7500, duration: 0 },
            { id: "eid228", tween: [ "style", "${_word2007strtblurb2}", "opacity", '1', { fromValue: '0.1'}], position: 10000, duration: 750 },
            { id: "eid230", tween: [ "style", "${_word2007strtblurb2}", "opacity", '0.1', { fromValue: '1'}], position: 10750, duration: 750 },
            { id: "eid411", tween: [ "style", "${_wordblurb}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid416", tween: [ "style", "${_wordblurb}", "display", 'block', { fromValue: 'none'}], position: 22000, duration: 0 },
            { id: "eid414", tween: [ "style", "${_wordblurb}", "display", 'none', { fromValue: 'block'}], position: 23500, duration: 0 },
            { id: "eid284", tween: [ "style", "${_pe8MM_lg}", "top", '70px', { fromValue: '234px'}], position: 14000, duration: 750 },
            { id: "eid292", tween: [ "style", "${_pe8MM_lg}", "top", '234px', { fromValue: '70px'}], position: 14750, duration: 750 },
            { id: "eid515", tween: [ "style", "${_fl4_lg}", "height", '479px', { fromValue: '164.31924882629px'}], position: 26000, duration: 750 },
            { id: "eid529", tween: [ "style", "${_fl4_lg}", "height", '164.31924882629px', { fromValue: '479px'}], position: 26750, duration: 750 },
            { id: "eid282", tween: [ "style", "${_pe8MM_lg}", "left", '49px', { fromValue: '389px'}], position: 14000, duration: 750 },
            { id: "eid287", tween: [ "style", "${_pe8MM_lg}", "left", '389px', { fromValue: '49px'}], position: 14750, duration: 750 },
            { id: "eid300", tween: [ "style", "${_office2007blurb}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid301", tween: [ "style", "${_office2007blurb}", "display", 'block', { fromValue: 'none'}], position: 16000, duration: 0 },
            { id: "eid343", tween: [ "style", "${_office2007blurb}", "display", 'none', { fromValue: 'block'}], position: 17500, duration: 0 },
            { id: "eid539", tween: [ "style", "${_digphto_lg}", "width", '365px', { fromValue: '125px'}], position: 28000, duration: 750 },
            { id: "eid547", tween: [ "style", "${_digphto_lg}", "width", '125px', { fromValue: '365px'}], position: 28750, duration: 750 },
            { id: "eid186", tween: [ "style", "${_fl3_lg}", "left", '49px', { fromValue: '19px'}], position: 8000, duration: 750 },
            { id: "eid195", tween: [ "style", "${_fl3_lg}", "left", '19px', { fromValue: '49px'}], position: 8750, duration: 750 },
            { id: "eid188", tween: [ "style", "${_fl3_lg}", "top", '70px', { fromValue: '429px'}], position: 8000, duration: 750 },
            { id: "eid191", tween: [ "style", "${_fl3_lg}", "top", '429px', { fromValue: '70px'}], position: 8750, duration: 750 },
            { id: "eid190", tween: [ "style", "${_fl3_lg}", "opacity", '1', { fromValue: '0.1'}], position: 8000, duration: 750 },
            { id: "eid193", tween: [ "style", "${_fl3_lg}", "opacity", '0.1', { fromValue: '1'}], position: 8750, duration: 750 },
            { id: "eid349", tween: [ "style", "${_of07_lg}", "left", '475px', { fromValue: '389px'}], position: 16000, duration: 750 },
            { id: "eid357", tween: [ "style", "${_of07_lg}", "left", '389px', { fromValue: '475px'}], position: 16750, duration: 750 },
            { id: "eid37", tween: [ "style", "${_edgePR7blurb}", "opacity", '0.95106475055218', { fromValue: '0'}], position: 250, duration: 750 },
            { id: "eid41", tween: [ "style", "${_edgePR7blurb}", "opacity", '0', { fromValue: '0.95106475055218'}], position: 1000, duration: 750 },
            { id: "eid56", tween: [ "style", "${_edge_pr7_lg}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid57", tween: [ "style", "${_edge_pr7_lg}", "display", 'block', { fromValue: 'none'}], position: 250, duration: 0 },
            { id: "eid68", tween: [ "style", "${_edge_pr7_lg}", "display", 'none', { fromValue: 'block'}], position: 1750, duration: 0 },
            { id: "eid487", tween: [ "style", "${_flash5_5_lg}", "top", '70px', { fromValue: '33px'}], position: 24000, duration: 750 },
            { id: "eid499", tween: [ "style", "${_flash5_5_lg}", "top", '33px', { fromValue: '70px'}], position: 24750, duration: 750 },
            { id: "eid417", tween: [ "style", "${_wordblurb}", "-webkit-transform-origin", [50,53], { valueTemplate: '@@0@@% @@1@@%', fromValue: [50,53]}], position: 23500, duration: 0 },
            { id: "eid608", tween: [ "style", "${_wordblurb}", "-moz-transform-origin", [50,53], { valueTemplate: '@@0@@% @@1@@%', fromValue: [50,53]}], position: 23500, duration: 0 },
            { id: "eid609", tween: [ "style", "${_wordblurb}", "-ms-transform-origin", [50,53], { valueTemplate: '@@0@@% @@1@@%', fromValue: [50,53]}], position: 23500, duration: 0 },
            { id: "eid610", tween: [ "style", "${_wordblurb}", "msTransformOrigin", [50,53], { valueTemplate: '@@0@@% @@1@@%', fromValue: [50,53]}], position: 23500, duration: 0 },
            { id: "eid611", tween: [ "style", "${_wordblurb}", "-o-transform-origin", [50,53], { valueTemplate: '@@0@@% @@1@@%', fromValue: [50,53]}], position: 23500, duration: 0 },
            { id: "eid519", tween: [ "style", "${_fl4_lg}", "left", '475px', { fromValue: '760px'}], position: 26000, duration: 750 },
            { id: "eid525", tween: [ "style", "${_fl4_lg}", "left", '760px', { fromValue: '475px'}], position: 26750, duration: 750 },
            { id: "eid216", tween: [ "style", "${_wrd07strtr_lg}", "left", '49px', { fromValue: '204px'}], position: 10000, duration: 750 },
            { id: "eid220", tween: [ "style", "${_wrd07strtr_lg}", "left", '204px', { fromValue: '49px'}], position: 10750, duration: 750 },
            { id: "eid54", tween: [ "style", "${_edge_pr7_lg}", "top", '60px', { fromValue: '33px'}], position: 250, duration: 750 },
            { id: "eid62", tween: [ "style", "${_edge_pr7_lg}", "top", '33px', { fromValue: '60px'}], position: 1000, duration: 750 },
            { id: "eid134", tween: [ "style", "${_office2011_lg}", "opacity", '1', { fromValue: '0.20032169117647'}], position: 4000, duration: 750 },
            { id: "eid139", tween: [ "style", "${_office2011_lg}", "opacity", '0.20032169117647', { fromValue: '1'}], position: 4750, duration: 750 },
            { id: "eid408", tween: [ "style", "${_sketchupblurb}", "opacity", '1', { fromValue: '0.1'}], position: 20000, duration: 750 },
            { id: "eid409", tween: [ "style", "${_sketchupblurb}", "opacity", '0.1', { fromValue: '1'}], position: 20750, duration: 750 },
            { id: "eid280", tween: [ "style", "${_pe8MM_lg}", "width", '365px', { fromValue: '125px'}], position: 14000, duration: 750 },
            { id: "eid290", tween: [ "style", "${_pe8MM_lg}", "width", '125px', { fromValue: '365px'}], position: 14750, duration: 750 },
            { id: "eid511", tween: [ "style", "${_flash4blurb}", "opacity", '1', { fromValue: '0.1'}], position: 26000, duration: 750 },
            { id: "eid513", tween: [ "style", "${_flash4blurb}", "opacity", '0.1', { fromValue: '1'}], position: 26750, duration: 750 },
            { id: "eid128", tween: [ "style", "${_office2011_lg}", "top", '70px', { fromValue: '234px'}], position: 4000, duration: 750 },
            { id: "eid138", tween: [ "style", "${_office2011_lg}", "top", '234px', { fromValue: '70px'}], position: 4750, duration: 750 },
            { id: "eid531", tween: [ "style", "${_digphto_lg}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid532", tween: [ "style", "${_digphto_lg}", "display", 'block', { fromValue: 'none'}], position: 28000, duration: 0 },
            { id: "eid545", tween: [ "style", "${_digphto_lg}", "display", 'none', { fromValue: 'block'}], position: 29500, duration: 0 },
            { id: "eid473", tween: [ "style", "${_flash5_5_lg}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid474", tween: [ "style", "${_flash5_5_lg}", "display", 'block', { fromValue: 'none'}], position: 24000, duration: 0 },
            { id: "eid500", tween: [ "style", "${_flash5_5_lg}", "display", 'none', { fromValue: 'block'}], position: 25500, duration: 0 },
            { id: "eid275", tween: [ "style", "${_pe8MM_lg}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid276", tween: [ "style", "${_pe8MM_lg}", "display", 'block', { fromValue: 'none'}], position: 14000, duration: 0 },
            { id: "eid289", tween: [ "style", "${_pe8MM_lg}", "display", 'none', { fromValue: 'block'}], position: 15500, duration: 0 },
            { id: "eid427", tween: [ "style", "${_wrd07_lg}", "opacity", '1', { fromValue: '0.1'}], position: 22000, duration: 750 },
            { id: "eid432", tween: [ "style", "${_wrd07_lg}", "opacity", '0.1', { fromValue: '1'}], position: 22750, duration: 750 },
            { id: "eid286", tween: [ "style", "${_pe8MM_lg}", "opacity", '1', { fromValue: '0.1'}], position: 14000, duration: 750 },
            { id: "eid288", tween: [ "style", "${_pe8MM_lg}", "opacity", '0.1', { fromValue: '1'}], position: 14750, duration: 750 },
            { id: "eid51", tween: [ "style", "${_edge_pr7_lg}", "height", '479px', { fromValue: '164.04109589041px'}], position: 250, duration: 750 },
            { id: "eid63", tween: [ "style", "${_edge_pr7_lg}", "height", '164.04109589041px', { fromValue: '479px'}], position: 1000, duration: 750 },
            { id: "eid361", tween: [ "style", "${_edgePR3blurb}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid362", tween: [ "style", "${_edgePR3blurb}", "display", 'block', { fromValue: 'none'}], position: 18000, duration: 0 },
            { id: "eid369", tween: [ "style", "${_edgePR3blurb}", "display", 'none', { fromValue: 'block'}], position: 19500, duration: 0 },
            { id: "eid489", tween: [ "style", "${_flash5_5_lg}", "opacity", '1', { fromValue: '0.1'}], position: 24000, duration: 750 },
            { id: "eid501", tween: [ "style", "${_flash5_5_lg}", "opacity", '0.1', { fromValue: '1'}], position: 24750, duration: 750 },
            { id: "eid132", tween: [ "style", "${_office2011_lg}", "width", '365px', { fromValue: '125px'}], position: 4000, duration: 750 },
            { id: "eid135", tween: [ "style", "${_office2011_lg}", "width", '125px', { fromValue: '365px'}], position: 4750, duration: 750 },
            { id: "eid392", tween: [ "style", "${_skMM_lg}", "height", '479px', { fromValue: '163.75px'}], position: 20000, duration: 750 },
            { id: "eid406", tween: [ "style", "${_skMM_lg}", "height", '163.75px', { fromValue: '479px'}], position: 20750, duration: 750 },
            { id: "eid485", tween: [ "style", "${_flash5_5_lg}", "left", '475px', { fromValue: '760px'}], position: 24000, duration: 750 },
            { id: "eid496", tween: [ "style", "${_flash5_5_lg}", "left", '760px', { fromValue: '475px'}], position: 24750, duration: 750 },
            { id: "eid483", tween: [ "style", "${_flash5_5_lg}", "width", '365px', { fromValue: '125px'}], position: 24000, duration: 750 },
            { id: "eid497", tween: [ "style", "${_flash5_5_lg}", "width", '125px', { fromValue: '365px'}], position: 24750, duration: 750 },
            { id: "eid374", tween: [ "style", "${_edge_pr3_lg}", "width", '365px', { fromValue: '125px'}], position: 18000, duration: 750 },
            { id: "eid385", tween: [ "style", "${_edge_pr3_lg}", "width", '125px', { fromValue: '365px'}], position: 18750, duration: 750 },
            { id: "eid387", tween: [ "style", "${_skMM_lg}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid390", tween: [ "style", "${_skMM_lg}", "display", 'block', { fromValue: 'none'}], position: 20000, duration: 0 },
            { id: "eid404", tween: [ "style", "${_skMM_lg}", "display", 'none', { fromValue: 'block'}], position: 21500, duration: 0 },
            { id: "eid541", tween: [ "style", "${_digphto_lg}", "left", '475px', { fromValue: '760px'}], position: 28000, duration: 750 },
            { id: "eid546", tween: [ "style", "${_digphto_lg}", "left", '760px', { fromValue: '475px'}], position: 28750, duration: 750 },
            { id: "eid184", tween: [ "style", "${_fl3_lg}", "width", '365px', { fromValue: '124.66666666667px'}], position: 8000, duration: 750 },
            { id: "eid192", tween: [ "style", "${_fl3_lg}", "width", '124.66666666667px', { fromValue: '365px'}], position: 8750, duration: 750 },
            { id: "eid79", tween: [ "style", "${_flash6_lg}", "opacity", '1', { fromValue: '0.20215992647059'}], position: 2000, duration: 750 },
            { id: "eid96", tween: [ "style", "${_flash6_lg}", "opacity", '0.20215992647059', { fromValue: '1'}], position: 2750, duration: 750 },
            { id: "eid105", tween: [ "style", "${_flash6blurb}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid106", tween: [ "style", "${_flash6blurb}", "display", 'block', { fromValue: 'none'}], position: 2000, duration: 0 },
            { id: "eid109", tween: [ "style", "${_flash6blurb}", "display", 'none', { fromValue: 'block'}], position: 3500, duration: 0 },
            { id: "eid240", tween: [ "style", "${_edge_pr5_lg}", "left", '475px', { fromValue: '389px'}], position: 12000, duration: 750 },
            { id: "eid253", tween: [ "style", "${_edge_pr5_lg}", "left", '389px', { fromValue: '475px'}], position: 12750, duration: 750 },
            { id: "eid151", tween: [ "style", "${_flash5_lg}", "left", '49px', { fromValue: '204px'}], position: 6000, duration: 750 },
            { id: "eid157", tween: [ "style", "${_flash5_lg}", "left", '204px', { fromValue: '49px'}], position: 6750, duration: 750 },
            { id: "eid242", tween: [ "style", "${_edge_pr5_lg}", "top", '70px', { fromValue: '33px'}], position: 12000, duration: 750 },
            { id: "eid249", tween: [ "style", "${_edge_pr5_lg}", "top", '33px', { fromValue: '70px'}], position: 12750, duration: 750 },
            { id: "eid246", tween: [ "style", "${_edge_pr5_lg}", "width", '365px', { fromValue: '125px'}], position: 12000, duration: 750 },
            { id: "eid250", tween: [ "style", "${_edge_pr5_lg}", "width", '125px', { fromValue: '365px'}], position: 12750, duration: 750 },
            { id: "eid388", tween: [ "style", "${_sketchupblurb}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid389", tween: [ "style", "${_sketchupblurb}", "display", 'block', { fromValue: 'none'}], position: 20000, duration: 0 },
            { id: "eid410", tween: [ "style", "${_sketchupblurb}", "display", 'none', { fromValue: 'block'}], position: 21500, duration: 0 },
            { id: "eid423", tween: [ "style", "${_wrd07_lg}", "left", '475px', { fromValue: '575px'}], position: 22000, duration: 750 },
            { id: "eid430", tween: [ "style", "${_wrd07_lg}", "left", '575px', { fromValue: '475px'}], position: 22750, duration: 750 },
            { id: "eid376", tween: [ "style", "${_edge_pr3_lg}", "left", '475px', { fromValue: '575px'}], position: 18000, duration: 750 },
            { id: "eid384", tween: [ "style", "${_edge_pr3_lg}", "left", '575px', { fromValue: '475px'}], position: 18750, duration: 750 },
            { id: "eid52", tween: [ "style", "${_edge_pr7_lg}", "width", '365.59190031153px', { fromValue: '125px'}], position: 250, duration: 750 },
            { id: "eid61", tween: [ "style", "${_edge_pr7_lg}", "width", '125px', { fromValue: '365.59190031153px'}], position: 1000, duration: 750 },
            { id: "eid425", tween: [ "style", "${_wrd07_lg}", "top", '70px', { fromValue: '429px'}], position: 22000, duration: 750 },
            { id: "eid429", tween: [ "style", "${_wrd07_lg}", "top", '429px', { fromValue: '70px'}], position: 22750, duration: 750 },
            { id: "eid244", tween: [ "style", "${_edge_pr5_lg}", "height", '479px', { fromValue: '164.04109589041px'}], position: 12000, duration: 750 },
            { id: "eid251", tween: [ "style", "${_edge_pr5_lg}", "height", '164.04109589041px', { fromValue: '479px'}], position: 12750, duration: 750 },
            { id: "eid198", tween: [ "style", "${_flash3blurb}", "opacity", '1', { fromValue: '0.1'}], position: 8000, duration: 750 },
            { id: "eid199", tween: [ "style", "${_flash3blurb}", "opacity", '0.1', { fromValue: '1'}], position: 8750, duration: 750 },
            { id: "eid104", tween: [ "style", "${_flash6_lg}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid102", tween: [ "style", "${_flash6_lg}", "display", 'none', { fromValue: 'none'}], position: 1930, duration: 0 },
            { id: "eid103", tween: [ "style", "${_flash6_lg}", "display", 'block', { fromValue: 'none'}], position: 2000, duration: 0 },
            { id: "eid101", tween: [ "style", "${_flash6_lg}", "display", 'none', { fromValue: 'block'}], position: 3500, duration: 0 },
            { id: "eid116", tween: [ "style", "${_office2011blurb}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid118", tween: [ "style", "${_office2011blurb}", "display", 'block', { fromValue: 'none'}], position: 4000, duration: 0 },
            { id: "eid123", tween: [ "style", "${_office2011blurb}", "display", 'none', { fromValue: 'block'}], position: 5500, duration: 0 },
            { id: "eid268", tween: [ "style", "${_premiereblurb}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid269", tween: [ "style", "${_premiereblurb}", "display", 'block', { fromValue: 'none'}], position: 14000, duration: 0 },
            { id: "eid274", tween: [ "style", "${_premiereblurb}", "display", 'none', { fromValue: 'block'}], position: 15500, duration: 0 },
            { id: "eid218", tween: [ "style", "${_wrd07strtr_lg}", "opacity", '1', { fromValue: '0.1'}], position: 10000, duration: 750 },
            { id: "eid224", tween: [ "style", "${_wrd07strtr_lg}", "opacity", '0.1', { fromValue: '1'}], position: 10750, duration: 750 },
            { id: "eid214", tween: [ "style", "${_wrd07strtr_lg}", "width", '365px', { fromValue: '125.64516129032px'}], position: 10000, duration: 750 },
            { id: "eid221", tween: [ "style", "${_wrd07strtr_lg}", "width", '125.64516129032px', { fromValue: '365px'}], position: 10750, duration: 750 },
            { id: "eid517", tween: [ "style", "${_fl4_lg}", "width", '365px', { fromValue: '125px'}], position: 26000, duration: 750 },
            { id: "eid526", tween: [ "style", "${_fl4_lg}", "width", '125px', { fromValue: '365px'}], position: 26750, duration: 750 },
            { id: "eid521", tween: [ "style", "${_fl4_lg}", "top", '70px', { fromValue: '234px'}], position: 26000, duration: 750 },
            { id: "eid527", tween: [ "style", "${_fl4_lg}", "top", '234px', { fromValue: '70px'}], position: 26750, duration: 750 },
            { id: "eid507", tween: [ "style", "${_fl4_lg}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid508", tween: [ "style", "${_fl4_lg}", "display", 'block', { fromValue: 'none'}], position: 26000, duration: 0 },
            { id: "eid528", tween: [ "style", "${_fl4_lg}", "display", 'none', { fromValue: 'block'}], position: 27500, duration: 0 },
            { id: "eid472", tween: [ "style", "${_flash5_5blurb}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid475", tween: [ "style", "${_flash5_5blurb}", "display", 'block', { fromValue: 'none'}], position: 24000, duration: 0 },
            { id: "eid479", tween: [ "style", "${_flash5_5blurb}", "display", 'none', { fromValue: 'block'}], position: 25500, duration: 0 },
            { id: "eid345", tween: [ "style", "${_of07_lg}", "height", '479px', { fromValue: '164.04109589041px'}], position: 16000, duration: 750 },
            { id: "eid359", tween: [ "style", "${_of07_lg}", "height", '164.04109589041px', { fromValue: '479px'}], position: 16750, duration: 750 },
            { id: "eid537", tween: [ "style", "${_digphto_lg}", "height", '479px', { fromValue: '164.04109589041px'}], position: 28000, duration: 750 },
            { id: "eid549", tween: [ "style", "${_digphto_lg}", "height", '164.04109589041px', { fromValue: '479px'}], position: 28750, duration: 750 },
            { id: "eid530", tween: [ "style", "${_digiPhotoblurb}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid533", tween: [ "style", "${_digiPhotoblurb}", "display", 'block', { fromValue: 'none'}], position: 28000, duration: 0 },
            { id: "eid555", tween: [ "style", "${_digiPhotoblurb}", "display", 'none', { fromValue: 'block'}], position: 29500, duration: 0 },
            { id: "eid412", tween: [ "style", "${_wrd07_lg}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid415", tween: [ "style", "${_wrd07_lg}", "display", 'block', { fromValue: 'none'}], position: 22000, duration: 0 },
            { id: "eid413", tween: [ "style", "${_wrd07_lg}", "display", 'none', { fromValue: 'block'}], position: 23500, duration: 0 },
            { id: "eid378", tween: [ "style", "${_edge_pr3_lg}", "top", '70px', { fromValue: '33px'}], position: 18000, duration: 750 },
            { id: "eid381", tween: [ "style", "${_edge_pr3_lg}", "top", '33px', { fromValue: '70px'}], position: 18750, duration: 750 },
            { id: "eid201", tween: [ "style", "${_wrd07strtr_lg}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid203", tween: [ "style", "${_wrd07strtr_lg}", "display", 'block', { fromValue: 'none'}], position: 10000, duration: 0 },
            { id: "eid222", tween: [ "style", "${_wrd07strtr_lg}", "display", 'none', { fromValue: 'block'}], position: 11500, duration: 0 }         ]
      }
   }
},
"edgePR3blurb": {
   version: "0.1.7",
   minimumCompatibleVersion: "0.1.7",
   build: "0.11.0.161",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
   dom: [
   {
      transform: [[0,0]],
      rect: [0,0,'365px','479px'],
      type: 'rect',
      id: 'bg',
      stroke: [0,'rgb(0, 0, 0)','none'],
      opacity: 0.9,
      fill: ['rgba(255,255,255,1.00)']
   },
   {
      type: 'text',
      rect: ['29','453','244px','28px'],
      id: 'buy',
      opacity: 0.96000001907349,
      align: 'auto',
      text: 'Purchase this book from Amazon',
      cursor: ['pointer'],
      font: ['Arial, Helvetica, sans-serif',14,'rgba(40,110,20,1.00)','600','none','normal']
   },
   {
      font: ['Arial, Helvetica, sans-serif',14,'rgba(0,0,0,1)','normal','none','normal'],
      rect: ['29',96,'303px','296px'],
      type: 'text',
      id: 'blurb',
      align: 'auto',
      text: 'Want to use an Adobe tool to design animated web graphics that work on iPhone and iPad? You’ve come to the right book. Adobe Edge Preview 3: The Missing Manual shows you how to build HTML5 graphics using simple visual tools. No programming experience? No problem. Adobe Edge writes the underlying code for you. With this eBook, you’ll be designing great-looking web elements in no time.<br><br>Get to know the workspace. <br>Create and import graphics. <br>Work with text. <br>Jump into animation.<br>Make it interactive. <br>Peek behind the curtain. <br>Dig into JavaScript.\n',
      transform: [[0,0]],
      tag: 'p'
   },
   {
      transform: [[0,0]],
      type: 'text',
      id: 'title',
      text: 'Adobe Edge Preview 3<br>the missing manual<br>',
      font: ['Arial, Helvetica, sans-serif',24,'rgba(40,110,20,1.00)','600','none',''],
      rect: [29,33,'265px','57px']
   }],
   symbolInstances: [
   ]
   },
   states: {
      "Base State": {
         "${_bg}": [
            ["style", "top", '0px'],
            ["style", "overflow", 'hidden'],
            ["style", "height", '479px'],
            ["style", "opacity", '0.9'],
            ["style", "left", '0px'],
            ["style", "width", '365px']
         ],
         "${symbolSelector}": [
            ["style", "height", '479px'],
            ["style", "width", '365px']
         ],
         "${_blurb}": [
            ["style", "top", '96px'],
            ["style", "left", '29px'],
            ["style", "text-indent", '0px'],
            ["style", "height", '296px'],
            ["style", "font-size", '14px'],
            ["style", "cursor", 'auto'],
            ["style", "width", '303.609375px']
         ],
         "${_buy}": [
            ["style", "font-weight", '600'],
            ["style", "height", '28px'],
            ["color", "color", 'rgba(40,110,20,1.00)'],
            ["style", "opacity", '0.96000001907349'],
            ["style", "cursor", 'pointer'],
            ["style", "width", '244px']
         ],
         "${_title}": [
            ["style", "top", '33px'],
            ["style", "left", '29px'],
            ["color", "color", 'rgba(40,110,20,1.00)'],
            ["style", "height", '57px'],
            ["style", "font-weight", '600'],
            ["style", "cursor", 'auto'],
            ["style", "width", '265.96875px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 0,
         autoPlay: true,
         timeline: [
         ]
      }
   }
},
"flash6blurb": {
   version: "0.1.7",
   minimumCompatibleVersion: "0.1.7",
   build: "0.11.0.161",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
   dom: [
   {
      transform: [[0,0]],
      rect: [0,0,'365px','479px'],
      type: 'rect',
      id: 'bg',
      stroke: [0,'rgb(0, 0, 0)','none'],
      opacity: 0.9,
      fill: ['rgba(255,255,255,1.00)']
   },
   {
      type: 'text',
      rect: ['29','453','244px','28px'],
      id: 'buy',
      opacity: 0.96000001907349,
      align: 'auto',
      text: 'Purchase this book from Amazon',
      cursor: ['pointer'],
      font: ['Arial, Helvetica, sans-serif',14,'rgba(40,110,20,1.00)','600','none','normal']
   },
   {
      font: ['Arial, Helvetica, sans-serif',14,'rgba(0,0,0,1)','normal','none','normal'],
      rect: ['29',96,'303px','296px'],
      type: 'text',
      id: 'blurb',
      align: 'auto',
      text: 'You can build everything from simple animations to full-fledged iPhone, iPad, and Android apps with Flash CS6, but learning this complex program can be difficult—unless you have this fully updated, bestselling guide. Learn how to create gorgeous Flash effects even if you have no programming experience. With Flash CS6: The Missing Manual, you’ll move from the basics to power-user tools with ease.<br><br>Learn animation basics.<br>Master flash\'s tools.<br>Use 3D effects.<br>Create lifelike motion.<br>Build apps that work anywhere.<br>Add multimedia.<br>Create rich interactive animations.',
      transform: [[0,0]],
      tag: 'p'
   },
   {
      transform: [[0,0]],
      type: 'text',
      id: 'title',
      text: 'Flash CS6<br>the missing manual<br>',
      font: ['Arial, Helvetica, sans-serif',24,'rgba(40,110,20,1.00)','600','none',''],
      rect: [29,33,'265px','57px']
   }],
   symbolInstances: [
   ]
   },
   states: {
      "Base State": {
         "${_bg}": [
            ["style", "top", '0px'],
            ["style", "overflow", 'hidden'],
            ["style", "height", '479px'],
            ["style", "opacity", '0.9'],
            ["style", "left", '0px'],
            ["style", "width", '365px']
         ],
         "${symbolSelector}": [
            ["style", "height", '479px'],
            ["style", "width", '365px']
         ],
         "${_blurb}": [
            ["style", "top", '96px'],
            ["style", "left", '29px'],
            ["style", "text-indent", '0px'],
            ["style", "height", '296px'],
            ["style", "width", '303.609375px'],
            ["style", "cursor", 'auto'],
            ["style", "font-size", '14px']
         ],
         "${_buy}": [
            ["style", "font-weight", '600'],
            ["style", "height", '28px'],
            ["color", "color", 'rgba(40,110,20,1.00)'],
            ["style", "opacity", '0.96000001907349'],
            ["style", "cursor", 'pointer'],
            ["style", "width", '244px']
         ],
         "${_title}": [
            ["style", "top", '33px'],
            ["style", "left", '29px'],
            ["style", "height", '57px'],
            ["color", "color", 'rgba(40,110,20,1.00)'],
            ["style", "font-weight", '600'],
            ["style", "cursor", 'auto'],
            ["style", "width", '265.96875px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 0,
         autoPlay: true,
         timeline: [
         ]
      }
   }
},
"office2011blurb": {
   version: "0.1.7",
   minimumCompatibleVersion: "0.1.7",
   build: "0.11.0.161",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
   dom: [
   {
      transform: [[0,0]],
      rect: [0,0,'365px','479px'],
      type: 'rect',
      id: 'bg',
      stroke: [0,'rgb(0, 0, 0)','none'],
      opacity: 0.9,
      fill: ['rgba(255,255,255,1.00)']
   },
   {
      type: 'text',
      rect: ['29','453','244px','28px'],
      id: 'buy',
      opacity: 0.96000001907349,
      align: 'auto',
      text: 'Purchase this book from Amazon',
      cursor: ['pointer'],
      font: ['Arial, Helvetica, sans-serif',14,'rgba(40,110,20,1.00)','600','none','normal']
   },
   {
      font: ['Arial, Helvetica, sans-serif',14,'rgba(0,0,0,1)','normal','none','normal'],
      rect: ['29',96,'303px','296px'],
      type: 'text',
      id: 'blurb',
      align: 'auto',
      text: 'Office 2011 for Mac is easy to use, but to unleash its full power, you need to go beyond the basics. This entertaining guide not only gets you started with Word, Excel, PowerPoint, and the new Outlook for Mac, it also reveals useful lots of things you didn\'t know the software could do. Get crystal-clear explanations on the features you use most -- and plenty of power-user tips when you\'re ready for more.<br><br>Take advantage of new tools.<br>Create professional looking documents.<br>Crunch numbers with ease.<br>Stay organized.<br>Make eye-catching. presentations.<br>Use the programs together.',
      transform: [[0,0]],
      tag: 'p'
   },
   {
      transform: [[0,0]],
      type: 'text',
      id: 'title',
      text: 'Office 2011 for Mac<br>the missing manual<br>',
      font: ['Arial, Helvetica, sans-serif',24,'rgba(40,110,20,1.00)','600','none',''],
      rect: [29,33,'265px','57px']
   }],
   symbolInstances: [
   ]
   },
   states: {
      "Base State": {
         "${_bg}": [
            ["style", "top", '0px'],
            ["style", "overflow", 'hidden'],
            ["style", "height", '479px'],
            ["style", "opacity", '0.9'],
            ["style", "left", '0px'],
            ["style", "width", '365px']
         ],
         "${symbolSelector}": [
            ["style", "height", '479px'],
            ["style", "width", '365px']
         ],
         "${_blurb}": [
            ["style", "top", '96px'],
            ["style", "left", '29px'],
            ["style", "text-indent", '0px'],
            ["style", "height", '296px'],
            ["style", "font-size", '14px'],
            ["style", "cursor", 'auto'],
            ["style", "width", '303.609375px']
         ],
         "${_buy}": [
            ["style", "font-weight", '600'],
            ["style", "height", '28px'],
            ["color", "color", 'rgba(40,110,20,1.00)'],
            ["style", "opacity", '0.96000001907349'],
            ["style", "cursor", 'pointer'],
            ["style", "width", '244px']
         ],
         "${_title}": [
            ["style", "top", '33px'],
            ["style", "left", '29px'],
            ["color", "color", 'rgba(40,110,20,1.00)'],
            ["style", "height", '57px'],
            ["style", "font-weight", '600'],
            ["style", "cursor", 'auto'],
            ["style", "width", '265.96875px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 0,
         autoPlay: true,
         timeline: [
         ]
      }
   }
},
"flash5blurb": {
   version: "0.1.7",
   minimumCompatibleVersion: "0.1.7",
   build: "0.11.0.161",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
   dom: [
   {
      transform: [[0,0]],
      rect: [0,0,'365px','479px'],
      type: 'rect',
      id: 'bg',
      stroke: [0,'rgb(0, 0, 0)','none'],
      opacity: 0.9,
      fill: ['rgba(255,255,255,1.00)']
   },
   {
      type: 'text',
      rect: ['29','453','244px','28px'],
      id: 'buy',
      opacity: 0.96000001907349,
      align: 'auto',
      text: 'Purchase this book from Amazon',
      cursor: ['pointer'],
      font: ['Arial, Helvetica, sans-serif',14,'rgba(40,110,20,1.00)','600','none','normal']
   },
   {
      font: ['Arial, Helvetica, sans-serif',14,'rgba(0,0,0,1)','normal','none','normal'],
      rect: ['29',96,'303px','296px'],
      type: 'text',
      id: 'blurb',
      align: 'auto',
      text: 'Unlock the power of Adobe Flash and bring stunning animations to life onscreen. It\'s easy with Flash CS5: The Missing Manual. You\'ll start creating animations in the first chapter, and learn to produce effective, well-planned visuals that get your message across. This entertaining edition includes a complete primer on animation, a guided tour of the program\'s tools, new illustrations, and lots of details on working with video.<br>\nEvery chapter in this book provides step-by-step Flash tutorials. Beginners will learn to use the software in no time, and experienced Flash designers will improve their skills.\n',
      transform: [[0,0]],
      tag: 'p'
   },
   {
      transform: [[0,0]],
      type: 'text',
      id: 'title',
      text: 'Flash CS5<br>the missing manual<br>',
      font: ['Arial, Helvetica, sans-serif',24,'rgba(40,110,20,1.00)','600','none',''],
      rect: [29,33,'265px','57px']
   }],
   symbolInstances: [
   ]
   },
   states: {
      "Base State": {
         "${_bg}": [
            ["style", "top", '0px'],
            ["style", "overflow", 'hidden'],
            ["style", "height", '479px'],
            ["style", "opacity", '0.9'],
            ["style", "left", '0px'],
            ["style", "width", '365px']
         ],
         "${symbolSelector}": [
            ["style", "height", '479px'],
            ["style", "width", '365px']
         ],
         "${_blurb}": [
            ["style", "top", '96px'],
            ["style", "left", '29px'],
            ["style", "text-indent", '0px'],
            ["style", "height", '296px'],
            ["style", "width", '303.609375px'],
            ["style", "cursor", 'auto'],
            ["style", "font-size", '14px']
         ],
         "${_buy}": [
            ["style", "font-weight", '600'],
            ["style", "height", '28px'],
            ["color", "color", 'rgba(40,110,20,1.00)'],
            ["style", "opacity", '0.96000001907349'],
            ["style", "cursor", 'pointer'],
            ["style", "width", '244px']
         ],
         "${_title}": [
            ["style", "top", '33px'],
            ["style", "left", '29px'],
            ["style", "height", '57px'],
            ["color", "color", 'rgba(40,110,20,1.00)'],
            ["style", "font-weight", '600'],
            ["style", "cursor", 'auto'],
            ["style", "width", '265.96875px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 0,
         autoPlay: true,
         timeline: [
         ]
      }
   }
},
"flash3blurb": {
   version: "0.1.7",
   minimumCompatibleVersion: "0.1.7",
   build: "0.11.0.161",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
   dom: [
   {
      transform: [[0,0]],
      rect: [0,0,'365px','479px'],
      type: 'rect',
      id: 'bg',
      stroke: [0,'rgb(0, 0, 0)','none'],
      opacity: 0.9,
      fill: ['rgba(255,255,255,1.00)']
   },
   {
      type: 'text',
      rect: ['29','453','244px','28px'],
      id: 'buy',
      opacity: 0.96000001907349,
      align: 'auto',
      text: 'Purchase this book from Amazon',
      cursor: ['pointer'],
      font: ['Arial, Helvetica, sans-serif',14,'rgba(40,110,20,1.00)','600','none','normal']
   },
   {
      font: ['Arial, Helvetica, sans-serif',14,'rgba(0,0,0,1)','normal','none','normal'],
      rect: ['29',96,'303px','296px'],
      type: 'text',
      id: 'blurb',
      align: 'auto',
      text: 'Flash CS3 is the premier tool for creating web animations and interactive web sites, can be intimidating to learn. This entertaining reference tutorial provides a reader-friendly animation primer and a guided tour of all the program\'s tools and capabilities. Beginners will learn to use the software in no time, and experienced users will quickly take their skills to the next level. The book gives Flash users of all levels hands-on instructions to help them master:<br><br>•\tSpecial effects<br>•\tMorphing<br>•\tAdding audio and video<br>•\tIntroducing interactivity<br>•\tAnd much more\n',
      transform: [[0,0]],
      tag: 'p'
   },
   {
      transform: [[0,0]],
      type: 'text',
      id: 'title',
      text: 'Flash CS3<br>the missing manual<br>',
      font: ['Arial, Helvetica, sans-serif',24,'rgba(40,110,20,1.00)','600','none',''],
      rect: [29,33,'265px','57px']
   }],
   symbolInstances: [
   ]
   },
   states: {
      "Base State": {
         "${_bg}": [
            ["style", "top", '0px'],
            ["style", "overflow", 'hidden'],
            ["style", "height", '479px'],
            ["style", "opacity", '0.9'],
            ["style", "left", '0px'],
            ["style", "width", '365px']
         ],
         "${symbolSelector}": [
            ["style", "height", '479px'],
            ["style", "width", '365px']
         ],
         "${_blurb}": [
            ["style", "top", '96px'],
            ["style", "left", '29px'],
            ["style", "text-indent", '0px'],
            ["style", "height", '296px'],
            ["style", "font-size", '14px'],
            ["style", "cursor", 'auto'],
            ["style", "width", '303.609375px']
         ],
         "${_buy}": [
            ["style", "font-weight", '600'],
            ["style", "height", '28px'],
            ["color", "color", 'rgba(40,110,20,1.00)'],
            ["style", "opacity", '0.96000001907349'],
            ["style", "cursor", 'pointer'],
            ["style", "width", '244px']
         ],
         "${_title}": [
            ["style", "top", '33px'],
            ["style", "left", '29px'],
            ["color", "color", 'rgba(40,110,20,1.00)'],
            ["style", "height", '57px'],
            ["style", "font-weight", '600'],
            ["style", "cursor", 'auto'],
            ["style", "width", '265.96875px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 0,
         autoPlay: true,
         timeline: [
         ]
      }
   }
},
"word2007strtblurb": {
   version: "0.1.7",
   minimumCompatibleVersion: "0.1.7",
   build: "0.11.0.161",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
   dom: [
   {
      transform: [[0,0]],
      rect: [0,0,'365px','479px'],
      type: 'rect',
      id: 'bg',
      stroke: [0,'rgb(0, 0, 0)','none'],
      opacity: 0.9,
      fill: ['rgba(255,255,255,1.00)']
   },
   {
      type: 'text',
      rect: ['29','453','244px','28px'],
      id: 'buy',
      opacity: 0.96000001907349,
      align: 'auto',
      text: 'Purchase this book from Amazon',
      cursor: ['pointer'],
      font: ['Arial, Helvetica, sans-serif',14,'rgba(40,110,20,1.00)','600','none','normal']
   },
   {
      font: ['Arial, Helvetica, sans-serif',14,'rgba(0,0,0,1)','normal','none','normal'],
      rect: ['29',96,'303px','296px'],
      type: 'text',
      id: 'blurb',
      align: 'auto',
      text: 'Fast-paced and easy to read, this concise book teaches you the basics of Word 2007 so you can start using the program right away. Not only will you learn how to work with Word\'s most useful features to create documents, format and edit text, share the results and more, you\'ll also discover how to go beyond basic documents to handle graphics, create page layouts, and use forms and tables.<br><br>Clear explanations.<br>Step-by-step instructions.<br>Lots of illustrations.<br>Larger type.<br>Plenty of friendly advice.',
      transform: [[0,0]],
      tag: 'p'
   },
   {
      transform: [[0,0]],
      type: 'text',
      id: 'title',
      text: 'Word 2007 for Starters<br>the missing manual<br>',
      font: ['Arial, Helvetica, sans-serif',24,'rgba(40,110,20,1.00)','600','none',''],
      rect: [29,33,'265px','57px']
   }],
   symbolInstances: [
   ]
   },
   states: {
      "Base State": {
         "${_bg}": [
            ["style", "top", '0px'],
            ["style", "overflow", 'hidden'],
            ["style", "height", '479px'],
            ["style", "opacity", '0.9'],
            ["style", "left", '0px'],
            ["style", "width", '365px']
         ],
         "${symbolSelector}": [
            ["style", "height", '479px'],
            ["style", "width", '365px']
         ],
         "${_blurb}": [
            ["style", "top", '96px'],
            ["style", "left", '29px'],
            ["style", "text-indent", '0px'],
            ["style", "height", '296px'],
            ["style", "width", '303.609375px'],
            ["style", "cursor", 'auto'],
            ["style", "font-size", '14px']
         ],
         "${_buy}": [
            ["style", "font-weight", '600'],
            ["style", "height", '28px'],
            ["color", "color", 'rgba(40,110,20,1.00)'],
            ["style", "opacity", '0.96000001907349'],
            ["style", "cursor", 'pointer'],
            ["style", "width", '244px']
         ],
         "${_title}": [
            ["style", "top", '33px'],
            ["style", "left", '29px'],
            ["style", "height", '57px'],
            ["color", "color", 'rgba(40,110,20,1.00)'],
            ["style", "font-weight", '600'],
            ["style", "cursor", 'auto'],
            ["style", "width", '265.96875px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 0,
         autoPlay: true,
         timeline: [
         ]
      }
   }
},
"edgePR5blurb": {
   version: "0.1.7",
   minimumCompatibleVersion: "0.1.7",
   build: "0.11.0.161",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
   dom: [
   {
      transform: [[0,0]],
      rect: [0,0,'365px','479px'],
      type: 'rect',
      id: 'bg',
      stroke: [0,'rgb(0, 0, 0)','none'],
      opacity: 0.9,
      fill: ['rgba(255,255,255,1.00)']
   },
   {
      type: 'text',
      rect: ['29','453','244px','28px'],
      id: 'buy',
      opacity: 0.96000001907349,
      align: 'auto',
      text: 'Purchase this book from Amazon',
      cursor: ['pointer'],
      font: ['Arial, Helvetica, sans-serif',14,'rgba(40,110,20,1.00)','600','none','normal']
   },
   {
      font: ['Arial, Helvetica, sans-serif',14,'rgba(0,0,0,1)','normal','none','normal'],
      rect: ['29',96,'303px','296px'],
      type: 'text',
      id: 'blurb',
      align: 'auto',
      text: 'Want to create animated graphics for iPhone, iPad and the Web, using familiar Adobe features? You’ve come to the right guide. Adobe Edge Preview 5: The Missing Manual shows you how to build HTML5 and JavaScript graphics with Adobe multimedia tools. No programming experience? No problem. Adobe Edge writes all the code for you. With this book, you’ll be designing great-looking web apps in no time.<br><br>Get to know the workspace.<br>Create and import graphics.<br>Work with text.<br>Jump into animation.<br>Make it interactive.<br>Dig into JavaScript.',
      transform: [[0,0]],
      tag: 'p'
   },
   {
      transform: [[0,0]],
      type: 'text',
      id: 'title',
      text: 'Adobe Edge Preview 5<br>the missing manual<br>',
      font: ['Arial, Helvetica, sans-serif',24,'rgba(40,110,20,1.00)','600','none',''],
      rect: [29,33,'265px','57px']
   }],
   symbolInstances: [
   ]
   },
   states: {
      "Base State": {
         "${_bg}": [
            ["style", "top", '0px'],
            ["style", "overflow", 'hidden'],
            ["style", "height", '479px'],
            ["style", "opacity", '0.9'],
            ["style", "left", '0px'],
            ["style", "width", '365px']
         ],
         "${symbolSelector}": [
            ["style", "height", '479px'],
            ["style", "width", '365px']
         ],
         "${_blurb}": [
            ["style", "top", '96px'],
            ["style", "left", '29px'],
            ["style", "text-indent", '0px'],
            ["style", "height", '296px'],
            ["style", "width", '303.609375px'],
            ["style", "cursor", 'auto'],
            ["style", "font-size", '14px']
         ],
         "${_buy}": [
            ["style", "font-weight", '600'],
            ["style", "height", '28px'],
            ["color", "color", 'rgba(40,110,20,1.00)'],
            ["style", "opacity", '0.96000001907349'],
            ["style", "cursor", 'pointer'],
            ["style", "width", '244px']
         ],
         "${_title}": [
            ["style", "top", '33px'],
            ["style", "left", '29px'],
            ["style", "height", '57px'],
            ["color", "color", 'rgba(40,110,20,1.00)'],
            ["style", "font-weight", '600'],
            ["style", "cursor", 'auto'],
            ["style", "width", '265.96875px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 0,
         autoPlay: true,
         timeline: [
         ]
      }
   }
},
"premiereblurb": {
   version: "0.1.7",
   minimumCompatibleVersion: "0.1.7",
   build: "0.11.0.161",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
   dom: [
   {
      transform: [[0,0]],
      rect: [0,0,'365px','479px'],
      type: 'rect',
      id: 'bg',
      stroke: [0,'rgb(0, 0, 0)','none'],
      opacity: 0.9,
      fill: ['rgba(255,255,255,1.00)']
   },
   {
      type: 'text',
      rect: ['29','453','244px','28px'],
      id: 'buy',
      opacity: 0.96000001907349,
      align: 'auto',
      text: 'Purchase this book from Amazon',
      cursor: ['pointer'],
      font: ['Arial, Helvetica, sans-serif',14,'rgba(40,110,20,1.00)','600','none','normal']
   },
   {
      font: ['Arial, Helvetica, sans-serif',14,'rgba(0,0,0,1)','normal','none','normal'],
      rect: ['29',96,'303px','296px'],
      type: 'text',
      id: 'blurb',
      align: 'auto',
      text: 'Whether you\'re aiming for YouTube videos or Hollywood-style epics, you need what Premiere Elements can\'t provide: crystal-clear guidance and real world know-how. This Missing Manual delivers. Packed with great ideas on how to spiff up your footage, this book helps you avoid the dreaded Help! I Never Do Anything With My Video syndrome.\n\nWith this book, you\'ll learn how to use Premiere\'s two approaches to filmmaking: The quick-and-easy InstantMovie technique, and the classic, handcrafted approach for frame-by-frame editing with fine-tuned transitions, effects, and more.',
      transform: [[0,0]],
      tag: 'p'
   },
   {
      transform: [[0,0]],
      type: 'text',
      id: 'title',
      text: 'Premiere Elements 8<br>the missing manual<br>',
      font: ['Arial, Helvetica, sans-serif',24,'rgba(40,110,20,1.00)','600','none',''],
      rect: [29,33,'265px','57px']
   }],
   symbolInstances: [
   ]
   },
   states: {
      "Base State": {
         "${_bg}": [
            ["style", "top", '0px'],
            ["style", "overflow", 'hidden'],
            ["style", "height", '479px'],
            ["style", "opacity", '0.9'],
            ["style", "left", '0px'],
            ["style", "width", '365px']
         ],
         "${symbolSelector}": [
            ["style", "height", '479px'],
            ["style", "width", '365px']
         ],
         "${_blurb}": [
            ["style", "top", '96px'],
            ["style", "left", '29px'],
            ["style", "text-indent", '0px'],
            ["style", "height", '296px'],
            ["style", "font-size", '14px'],
            ["style", "cursor", 'auto'],
            ["style", "width", '303.609375px']
         ],
         "${_buy}": [
            ["style", "font-weight", '600'],
            ["style", "height", '28px'],
            ["color", "color", 'rgba(40,110,20,1.00)'],
            ["style", "opacity", '0.96000001907349'],
            ["style", "cursor", 'pointer'],
            ["style", "width", '244px']
         ],
         "${_title}": [
            ["style", "top", '33px'],
            ["style", "left", '29px'],
            ["color", "color", 'rgba(40,110,20,1.00)'],
            ["style", "height", '57px'],
            ["style", "font-weight", '600'],
            ["style", "cursor", 'auto'],
            ["style", "width", '265.96875px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 0,
         autoPlay: true,
         timeline: [
         ]
      }
   }
},
"office2007blurb": {
   version: "0.1.7",
   minimumCompatibleVersion: "0.1.7",
   build: "0.11.0.161",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
   dom: [
   {
      transform: [[0,0]],
      rect: [0,0,'365px','479px'],
      type: 'rect',
      id: 'bg',
      stroke: [0,'rgb(0, 0, 0)','none'],
      opacity: 0.9,
      fill: ['rgba(255,255,255,1.00)']
   },
   {
      type: 'text',
      rect: ['29','453','244px','28px'],
      id: 'buy',
      opacity: 0.96000001907349,
      align: 'auto',
      text: 'Purchase this book from Amazon',
      cursor: ['pointer'],
      font: ['Arial, Helvetica, sans-serif',14,'rgba(40,110,20,1.00)','600','none','normal']
   },
   {
      font: ['Arial, Helvetica, sans-serif',14,'rgba(0,0,0,1)','normal','none','normal'],
      rect: ['29',96,'303px','296px'],
      type: 'text',
      id: 'blurb',
      align: 'auto',
      text: 'Quickly learn the most useful features of Microsoft Office 2007 with our easy to read four-in-one guide. This fast-paced book gives you the basics of Word, Excel, PowerPoint and Access so you can start using the new versions of these major Office applications right away. Unlike every previous version, Office 2007 offers a completely redesigned user interface for each program. Microsoft has replaced the familiar menus with a new tabbed toolbar (or \"ribbon\"), and added other features such as \"live preview\" that lets you see exactly what each option will look like in the document before you choose it. This is good news for longtime users who never knew about some amazing Office features because they were hidden among cluttered and outdated menus. Adapting to the new format is going to be a shock -- especially if you\'re a longtime user. ',
      transform: [[0,0]],
      tag: 'p'
   },
   {
      transform: [[0,0]],
      type: 'text',
      id: 'title',
      text: 'Office 2007<br>the missing manual<br>',
      font: ['Arial, Helvetica, sans-serif',24,'rgba(40,110,20,1.00)','600','none',''],
      rect: [29,33,'265px','57px']
   }],
   symbolInstances: [
   ]
   },
   states: {
      "Base State": {
         "${_bg}": [
            ["style", "top", '0px'],
            ["style", "overflow", 'hidden'],
            ["style", "height", '479px'],
            ["style", "opacity", '0.9'],
            ["style", "left", '0px'],
            ["style", "width", '365px']
         ],
         "${symbolSelector}": [
            ["style", "height", '479px'],
            ["style", "width", '365px']
         ],
         "${_blurb}": [
            ["style", "top", '96px'],
            ["style", "left", '29px'],
            ["style", "text-indent", '0px'],
            ["style", "height", '296px'],
            ["style", "width", '303.609375px'],
            ["style", "cursor", 'auto'],
            ["style", "font-size", '14px']
         ],
         "${_buy}": [
            ["style", "font-weight", '600'],
            ["style", "height", '28px'],
            ["color", "color", 'rgba(40,110,20,1.00)'],
            ["style", "opacity", '0.96000001907349'],
            ["style", "cursor", 'pointer'],
            ["style", "width", '244px']
         ],
         "${_title}": [
            ["style", "top", '33px'],
            ["style", "left", '29px'],
            ["style", "height", '57px'],
            ["color", "color", 'rgba(40,110,20,1.00)'],
            ["style", "font-weight", '600'],
            ["style", "cursor", 'auto'],
            ["style", "width", '265.96875px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 0,
         autoPlay: true,
         timeline: [
         ]
      }
   }
},
"sketchupblurb": {
   version: "0.1.7",
   minimumCompatibleVersion: "0.1.7",
   build: "0.11.0.161",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
   dom: [
   {
      transform: [[0,0]],
      rect: [0,0,'365px','479px'],
      type: 'rect',
      id: 'bg',
      stroke: [0,'rgb(0, 0, 0)','none'],
      opacity: 0.9,
      fill: ['rgba(255,255,255,1.00)']
   },
   {
      type: 'text',
      rect: ['29','453','244px','28px'],
      id: 'buy',
      opacity: 0.96000001907349,
      align: 'auto',
      text: 'Purchase this book from Amazon',
      cursor: ['pointer'],
      font: ['Arial, Helvetica, sans-serif',14,'rgba(40,110,20,1.00)','600','none','normal']
   },
   {
      font: ['Arial, Helvetica, sans-serif',14,'rgba(0,0,0,1)','normal','none','normal'],
      rect: ['29',96,'303px','296px'],
      type: 'text',
      id: 'blurb',
      align: 'auto',
      text: 'If you want to learn to create 3-D models using Google SketchUp, this Missing Manual is the ideal place to start. Filled with step-by-step tutorials, this entertaining, reader-friendly guide will have you creating detailed 3-D objects, including building plans, furniture, landscaping plans--even characters for computer games--in no time. \n\nGoogle SketchUp: The Missing Manual offers a hands-on tour of the program, with crystal-clear instructions for using every feature and lots of real-world examples to help you pick up the practical skills you need.',
      transform: [[0,0]],
      tag: 'p'
   },
   {
      transform: [[0,0]],
      type: 'text',
      id: 'title',
      text: 'Google SketchUp<br>the missing manual<br>',
      font: ['Arial, Helvetica, sans-serif',24,'rgba(40,110,20,1.00)','600','none',''],
      rect: [29,33,'265px','57px']
   }],
   symbolInstances: [
   ]
   },
   states: {
      "Base State": {
         "${_bg}": [
            ["style", "top", '0px'],
            ["style", "overflow", 'hidden'],
            ["style", "height", '479px'],
            ["style", "opacity", '0.9'],
            ["style", "left", '0px'],
            ["style", "width", '365px']
         ],
         "${symbolSelector}": [
            ["style", "height", '479px'],
            ["style", "width", '365px']
         ],
         "${_blurb}": [
            ["style", "top", '96px'],
            ["style", "left", '29px'],
            ["style", "text-indent", '0px'],
            ["style", "height", '296px'],
            ["style", "width", '303.609375px'],
            ["style", "cursor", 'auto'],
            ["style", "font-size", '14px']
         ],
         "${_buy}": [
            ["style", "font-weight", '600'],
            ["style", "height", '28px'],
            ["color", "color", 'rgba(40,110,20,1.00)'],
            ["style", "opacity", '0.96000001907349'],
            ["style", "cursor", 'pointer'],
            ["style", "width", '244px']
         ],
         "${_title}": [
            ["style", "top", '33px'],
            ["style", "left", '29px'],
            ["style", "height", '57px'],
            ["color", "color", 'rgba(40,110,20,1.00)'],
            ["style", "font-weight", '600'],
            ["style", "cursor", 'auto'],
            ["style", "width", '265.96875px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 0,
         autoPlay: true,
         timeline: [
         ]
      }
   }
},
"wordblurb": {
   version: "0.1.7",
   minimumCompatibleVersion: "0.1.7",
   build: "0.11.0.161",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
   dom: [
   {
      transform: [[0,0]],
      rect: [0,0,'365px','479px'],
      type: 'rect',
      id: 'bg',
      stroke: [0,'rgb(0, 0, 0)','none'],
      opacity: 0.9,
      fill: ['rgba(255,255,255,1.00)']
   },
   {
      type: 'text',
      rect: ['29','453','244px','28px'],
      id: 'buy',
      opacity: 0.96000001907349,
      align: 'auto',
      text: 'Purchase this book from Amazon',
      cursor: ['pointer'],
      font: ['Arial, Helvetica, sans-serif',14,'rgba(40,110,20,1.00)','600','none','normal']
   },
   {
      font: ['Arial, Helvetica, sans-serif',14,'rgba(0,0,0,1)','normal','none','normal'],
      rect: ['29',96,'303px','296px'],
      type: 'text',
      id: 'blurb',
      align: 'auto',
      text: 'Microsoft Word has grown considerably in power, sophistication and capability over the past decade, but one thing that hasn\'t changed since the early \'90s is its user interface. The simple toolbar in version 2.0 has been packed with so many features since then that few users know where to find them all. Consequently, more and more people are looking for \"insider\" tips that will allow them to use these advanced and often hidden features. Microsoft has addressed this problem in Word 2007 by radically redesigning the user interface with a tabbed toolbar that makes every feature easy to locate and use. Unfortunately, Microsoft\'s documentation is as scant as ever, so even though you will be able to find advanced features, you might not know what to do with them.',
      transform: [[0,0]],
      tag: 'p'
   },
   {
      transform: [[0,0]],
      type: 'text',
      id: 'title',
      text: 'Word 2007<br>the missing manual<br>',
      font: ['Arial, Helvetica, sans-serif',24,'rgba(40,110,20,1.00)','600','none',''],
      rect: [29,33,'265px','57px']
   }],
   symbolInstances: [
   ]
   },
   states: {
      "Base State": {
         "${_bg}": [
            ["style", "top", '0px'],
            ["style", "overflow", 'hidden'],
            ["style", "height", '479px'],
            ["style", "opacity", '0.9'],
            ["style", "left", '0px'],
            ["style", "width", '365px']
         ],
         "${symbolSelector}": [
            ["style", "height", '479px'],
            ["style", "width", '365px']
         ],
         "${_blurb}": [
            ["style", "top", '96px'],
            ["style", "left", '29px'],
            ["style", "text-indent", '0px'],
            ["style", "height", '296px'],
            ["style", "font-size", '14px'],
            ["style", "cursor", 'auto'],
            ["style", "width", '303.609375px']
         ],
         "${_buy}": [
            ["style", "font-weight", '600'],
            ["style", "height", '28px'],
            ["color", "color", 'rgba(40,110,20,1.00)'],
            ["style", "opacity", '0.96000001907349'],
            ["style", "cursor", 'pointer'],
            ["style", "width", '244px']
         ],
         "${_title}": [
            ["style", "top", '33px'],
            ["style", "left", '29px'],
            ["color", "color", 'rgba(40,110,20,1.00)'],
            ["style", "height", '57px'],
            ["style", "font-weight", '600'],
            ["style", "cursor", 'auto'],
            ["style", "width", '265.96875px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 0,
         autoPlay: true,
         timeline: [
         ]
      }
   }
},
"flash5_5blurb": {
   version: "0.1.7",
   minimumCompatibleVersion: "0.1.7",
   build: "0.11.0.161",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
   dom: [
   {
      transform: [[0,0]],
      rect: [0,0,'365px','479px'],
      type: 'rect',
      id: 'bg',
      stroke: [0,'rgb(0, 0, 0)','none'],
      opacity: 0.9,
      fill: ['rgba(255,255,255,1.00)']
   },
   {
      type: 'text',
      rect: ['29','453','244px','28px'],
      id: 'buy',
      opacity: 0.96000001907349,
      align: 'auto',
      text: 'Purchase this book from Amazon',
      cursor: ['pointer'],
      font: ['Arial, Helvetica, sans-serif',14,'rgba(40,110,20,1.00)','600','none','normal']
   },
   {
      font: ['Arial, Helvetica, sans-serif',14,'rgba(0,0,0,1)','normal','none','normal'],
      rect: ['29',96,'303px','296px'],
      type: 'text',
      id: 'blurb',
      align: 'auto',
      text: 'You can build everything from simple animations to full-fledged iOS and Android apps with Flash CS5.5, but learning this complex program can be difficult—unless you have this fully updated, bestselling guide. Learn how to create gorgeous Flash effects even if you have no programming experience. With Flash CS5.5: The Missing Manual, you\'ll move from the basics to power-user tools with ease.<br><br>Learn anmiation basics.<br>Master Flash\'s tools.<br>Use 3D effects.<br>Create lifelike motion.<br>Build apps for tablets and smartphones.<br>Add multimedia.<br>Create rich interactive animations.',
      transform: [[0,0]],
      tag: 'p'
   },
   {
      transform: [[0,0]],
      type: 'text',
      id: 'title',
      text: 'Flash CS5.5<br>the missing manual<br>',
      font: ['Arial, Helvetica, sans-serif',24,'rgba(40,110,20,1.00)','600','none',''],
      rect: [29,33,'265px','57px']
   }],
   symbolInstances: [
   ]
   },
   states: {
      "Base State": {
         "${_bg}": [
            ["style", "top", '0px'],
            ["style", "overflow", 'hidden'],
            ["style", "height", '479px'],
            ["style", "opacity", '0.9'],
            ["style", "left", '0px'],
            ["style", "width", '365px']
         ],
         "${symbolSelector}": [
            ["style", "height", '479px'],
            ["style", "width", '365px']
         ],
         "${_blurb}": [
            ["style", "top", '96px'],
            ["style", "left", '29px'],
            ["style", "text-indent", '0px'],
            ["style", "height", '296px'],
            ["style", "width", '303.609375px'],
            ["style", "cursor", 'auto'],
            ["style", "font-size", '14px']
         ],
         "${_buy}": [
            ["style", "font-weight", '600'],
            ["style", "height", '28px'],
            ["color", "color", 'rgba(40,110,20,1.00)'],
            ["style", "opacity", '0.96000001907349'],
            ["style", "cursor", 'pointer'],
            ["style", "width", '244px']
         ],
         "${_title}": [
            ["style", "top", '33px'],
            ["style", "left", '29px'],
            ["style", "height", '57px'],
            ["color", "color", 'rgba(40,110,20,1.00)'],
            ["style", "font-weight", '600'],
            ["style", "cursor", 'auto'],
            ["style", "width", '265.96875px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 0,
         autoPlay: true,
         timeline: [
         ]
      }
   }
},
"flash4blurb": {
   version: "0.1.7",
   minimumCompatibleVersion: "0.1.7",
   build: "0.11.0.161",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
   dom: [
   {
      transform: [[0,0]],
      rect: [0,0,'365px','479px'],
      type: 'rect',
      id: 'bg',
      stroke: [0,'rgb(0, 0, 0)','none'],
      opacity: 0.9,
      fill: ['rgba(255,255,255,1.00)']
   },
   {
      type: 'text',
      rect: ['29','453','244px','28px'],
      id: 'buy',
      opacity: 0.96000001907349,
      align: 'auto',
      text: 'Purchase this book from Amazon',
      cursor: ['pointer'],
      font: ['Arial, Helvetica, sans-serif',14,'rgba(40,110,20,1.00)','600','none','normal']
   },
   {
      font: ['Arial, Helvetica, sans-serif',14,'rgba(0,0,0,1)','normal','none','normal'],
      rect: ['29',96,'303px','296px'],
      type: 'text',
      id: 'blurb',
      align: 'auto',
      text: 'Unlock the power of Flash and bring gorgeous animations to life onscreen. It\'s easy with Flash CS4: The Missing Manual. You\'ll start creating animations in the first chapter, and will learn to produce effective, well-planned visuals that get your message across. This entertaining new edition includes a complete primer on animation, a guided tour of the program\'s tools, lots of new illustrations, and more details on working with video. Beginners will learn to use the software in no time, and experienced Flash designers will improve their skills.<br><br>Learn to draw object, animate themand integrate your own audio and video files. Add interactivity, use special effects, learn morphing and much more.',
      transform: [[0,0]],
      tag: 'p'
   },
   {
      transform: [[0,0]],
      type: 'text',
      id: 'title',
      text: 'Flash CS4<br>the missing manual<br>',
      font: ['Arial, Helvetica, sans-serif',24,'rgba(40,110,20,1.00)','600','none',''],
      rect: [29,33,'265px','57px']
   }],
   symbolInstances: [
   ]
   },
   states: {
      "Base State": {
         "${_bg}": [
            ["style", "top", '0px'],
            ["style", "overflow", 'hidden'],
            ["style", "height", '479px'],
            ["style", "opacity", '0.9'],
            ["style", "left", '0px'],
            ["style", "width", '365px']
         ],
         "${symbolSelector}": [
            ["style", "height", '479px'],
            ["style", "width", '365px']
         ],
         "${_blurb}": [
            ["style", "top", '96px'],
            ["style", "left", '29px'],
            ["style", "text-indent", '0px'],
            ["style", "height", '296px'],
            ["style", "font-size", '14px'],
            ["style", "cursor", 'auto'],
            ["style", "width", '303.609375px']
         ],
         "${_buy}": [
            ["style", "font-weight", '600'],
            ["style", "height", '28px'],
            ["color", "color", 'rgba(40,110,20,1.00)'],
            ["style", "opacity", '0.96000001907349'],
            ["style", "cursor", 'pointer'],
            ["style", "width", '244px']
         ],
         "${_title}": [
            ["style", "top", '33px'],
            ["style", "left", '29px'],
            ["color", "color", 'rgba(40,110,20,1.00)'],
            ["style", "height", '57px'],
            ["style", "font-weight", '600'],
            ["style", "cursor", 'auto'],
            ["style", "width", '265.96875px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 0,
         autoPlay: true,
         timeline: [
         ]
      }
   }
},
"digiPhotoblurb": {
   version: "0.1.7",
   minimumCompatibleVersion: "0.1.7",
   build: "0.11.0.161",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
   dom: [
   {
      transform: [[0,0]],
      rect: [0,0,'365px','479px'],
      type: 'rect',
      id: 'bg',
      stroke: [0,'rgb(0, 0, 0)','none'],
      opacity: 0.9,
      fill: ['rgba(255,255,255,1.00)']
   },
   {
      type: 'text',
      rect: ['29','453','244px','28px'],
      id: 'buy',
      opacity: 0.96000001907349,
      align: 'auto',
      text: 'Purchase this book from Amazon',
      cursor: ['pointer'],
      font: ['Arial, Helvetica, sans-serif',14,'rgba(40,110,20,1.00)','600','none','normal']
   },
   {
      font: ['Arial, Helvetica, sans-serif',14,'rgba(0,0,0,1)','normal','none','normal'],
      rect: ['29',96,'303px','296px'],
      type: 'text',
      id: 'blurb',
      align: 'auto',
      text: 'Digital Photography: The Missing Manual helps you to take beautiful digital pictures -- of your baby, your trip to Paris, your new pet iguana--and then share the stunning results with your friends and family. Spiked with the advice and humor that are trademarks of the Missing Manual series, this book shows you how to:<br><br>•\tMaster your digital camera.<br>•\tLearn how to use those mysterious buttons and modes to improve your pictures.<br>•\tTake memorable photos.<br>•\tBecome a better photographer right away with a few simple tricks from the pros.<br>•\tEdit your photos to remove red eye, or crop out extraneous buildings.',
      transform: [[0,0]],
      tag: 'p'
   },
   {
      transform: [[0,0]],
      type: 'text',
      id: 'title',
      text: 'Digital Photography<br>the missing manual<br>',
      font: ['Arial, Helvetica, sans-serif',24,'rgba(40,110,20,1.00)','600','none',''],
      rect: [29,33,'265px','57px']
   }],
   symbolInstances: [
   ]
   },
   states: {
      "Base State": {
         "${_bg}": [
            ["style", "top", '0px'],
            ["style", "overflow", 'hidden'],
            ["style", "height", '479px'],
            ["style", "opacity", '0.9'],
            ["style", "left", '0px'],
            ["style", "width", '365px']
         ],
         "${symbolSelector}": [
            ["style", "height", '479px'],
            ["style", "width", '365px']
         ],
         "${_blurb}": [
            ["style", "top", '96px'],
            ["style", "left", '29px'],
            ["style", "text-indent", '0px'],
            ["style", "height", '296px'],
            ["style", "font-size", '14px'],
            ["style", "cursor", 'auto'],
            ["style", "width", '303.609375px']
         ],
         "${_buy}": [
            ["style", "font-weight", '600'],
            ["style", "height", '28px'],
            ["color", "color", 'rgba(40,110,20,1.00)'],
            ["style", "opacity", '0.96000001907349'],
            ["style", "cursor", 'pointer'],
            ["style", "width", '244px']
         ],
         "${_title}": [
            ["style", "top", '33px'],
            ["style", "left", '29px'],
            ["color", "color", 'rgba(40,110,20,1.00)'],
            ["style", "height", '57px'],
            ["style", "font-weight", '600'],
            ["style", "cursor", 'auto'],
            ["style", "width", '265.96875px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 0,
         autoPlay: true,
         timeline: [
         ]
      }
   }
}
};


Edge.registerCompositionDefn(compId, symbols, fonts, resources);

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     Edge.launchComposition(compId);
});
})(jQuery, AdobeEdge, "EDGE-3521704");
