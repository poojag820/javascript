/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
var im='images/';

var fonts = {};


var resources = [
];
var symbols = {
"stage": {
   version: "0.1.7",
   minimumCompatibleVersion: "0.1.7",
   build: "0.11.0.161",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
         dom: [
         {
            id:'frame',
            type:'rect',
            rect:['0px','0px','464px','55px','auto','auto'],
            fill:["rgba(10,33,148,0.00)"],
            stroke:[2,"rgb(0, 0, 0)","solid"]
         },
         {
            id:'stutz_logo',
            type:'image',
            rect:['0','0','243','207','undefined','undefined'],
            fill:["rgba(0,0,0,0)",im+"stutz_logo.png"],
            transform:[[],['0deg']]
         },
         {
            id:'Drive',
            type:'text',
            rect:['-56','-118','374','48','undefined','undefined'],
            clip:['rect(0px 1px 48px 0px)'],
            text:"Drive like a bearcat.",
            font:['Arial Black, Gadget, sans-serif',24,"rgba(0,0,0,1)","normal","none",""]
         },
         {
            id:'road',
            type:'rect',
            rect:['0px','53px','468px','7px','auto','auto'],
            fill:["rgba(10,33,148,1.00)"],
            stroke:[0,"rgba(0,0,0,1)","none"]
         },
         {
            id:'StutzBearcat',
            type:'image',
            rect:['-75px','-49px','381','151','undefined','undefined'],
            fill:["rgba(0,0,0,0)",im+"StutzBearcat.png"]
         }],
         symbolInstances: [

         ]
      },
   states: {
      "Base State": {
         "${_StutzBearcat}": [
            ["transform", "scaleX", '0.35'],
            ["transform", "scaleY", '0.35'],
            ["style", "left", '-74.83px'],
            ["style", "top", '-49.07px']
         ],
         "${_road}": [
            ["style", "top", '53px'],
            ["color", "background-color", 'rgba(10,33,148,1.00)']
         ],
         "${_Drive}": [
            ["style", "top", '12px'],
            ["style", "clip", [0,1,48,0], {valueTemplate:'rect(@@0@@px @@1@@px @@2@@px @@3@@px)'} ],
            ["style", "left", '52px'],
            ["style", "width", '374px']
         ],
         "${_Stage}": [
            ["color", "background-color", 'rgba(255,255,255,1)'],
            ["style", "height", '60px'],
            ["style", "width", '468px']
         ],
         "${_frame}": [
            ["style", "left", '0px'],
            ["style", "height", '55px'],
            ["style", "border-style", 'solid'],
            ["style", "border-width", '2px'],
            ["style", "width", '464px']
         ],
         "${_stutz_logo}": [
            ["style", "top", '-77.8px'],
            ["transform", "scaleY", '0.2'],
            ["transform", "rotateZ", '0deg'],
            ["transform", "scaleX", '0.2'],
            ["style", "left", '-97.2px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 2000,
         autoPlay: true,
         timeline: [
            { id: "eid13", tween: [ "style", "${_StutzBearcat}", "top", '-49.07px', { fromValue: '-49.07px'}], position: 0, duration: 2000 },
            { id: "eid21", tween: [ "style", "${_Drive}", "clip", [0,298,48,0], { valueTemplate: 'rect(@@0@@px @@1@@px @@2@@px @@3@@px)', fromValue: [0,1,48,0]}], position: 0, duration: 2000 },
            { id: "eid20", tween: [ "transform", "${_stutz_logo}", "rotateZ", '720deg', { fromValue: '0deg'}], position: 0, duration: 2000 },
            { id: "eid12", tween: [ "style", "${_StutzBearcat}", "left", '203.24px', { fromValue: '-74.83px'}], position: 0, duration: 2000 }         ]
      }
   }
}
};


Edge.registerCompositionDefn(compId, symbols, fonts, resources);

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     Edge.launchComposition(compId);
});
})(jQuery, AdobeEdge, "EDGE-34947207");
