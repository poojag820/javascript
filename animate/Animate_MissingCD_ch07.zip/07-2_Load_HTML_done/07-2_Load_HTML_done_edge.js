/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
var im='images/';

var fonts = {};


var resources = [
];
var symbols = {
"stage": {
   version: "0.1.7",
   minimumCompatibleVersion: "0.1.7",
   build: "0.11.0.161",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
         dom: [
],
         symbolInstances: [

         ]
      },
   states: {
      "Base State": {
         "body > p:nth-child(2)": [
            ["transform", "translateY", '92px'],
            ["transform", "translateX", '151px'],
            ["style", "width", '413px']
         ],
         "${_bearcat}": [
            ["transform", "translateX", '0px'],
            ["style", "height", '79.265091863517px'],
            ["style", "display", 'inline-block'],
            ["transform", "translateY", '0px'],
            ["style", "width", '200px']
         ],
         "${_pitch}": [
            ["transform", "scaleY", '1'],
            ["transform", "translateX", '151px'],
            ["transform", "scaleX", '1'],
            ["style", "opacity", '0'],
            ["transform", "translateY", '92px'],
            ["style", "width", '451px']
         ],
         "${_pause}": [
            ["transform", "translateX", '151px'],
            ["transform", "scaleY", '1'],
            ["transform", "scaleX", '1'],
            ["style", "opacity", '0'],
            ["transform", "translateY", '92px'],
            ["style", "width", '451px']
         ],
         "${_headline}": [
            ["transform", "translateY", '-111px'],
            ["transform", "translateX", '151px'],
            ["style", "width", '412.80859375px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 5250,
         autoPlay: true,
         labels: {
            "driveaway": 3250
         },
         timeline: [
            { id: "eid13", tween: [ "transform", "${_pause}", "scaleX", '1.5', { fromValue: '1'}], position: 2328, duration: 422 },
            { id: "eid15", tween: [ "transform", "${_pause}", "scaleX", '1', { fromValue: '1.5'}], position: 2750, duration: 422 },
            { id: "eid12", tween: [ "style", "${_pause}", "opacity", '0.93406519396552', { fromValue: '0'}], position: 2328, duration: 422 },
            { id: "eid1", tween: [ "transform", "${_bearcat}", "translateX", '765px', { fromValue: '0px'}], position: 3250, duration: 2000 },
            { id: "eid5", tween: [ "style", "${_pitch}", "opacity", '1', { fromValue: '0'}], position: 1000, duration: 500 },
            { id: "eid4", tween: [ "transform", "${_headline}", "translateY", '92px', { fromValue: '-111px'}], position: 0, duration: 1000, easing: "easeInBounce" },
            { id: "eid2", tween: [ "transform", "${_bearcat}", "translateY", '1px', { fromValue: '0px'}], position: 3250, duration: 2000 },
            { id: "eid14", tween: [ "transform", "${_pause}", "scaleY", '1.5', { fromValue: '1'}], position: 2328, duration: 422 },
            { id: "eid16", tween: [ "transform", "${_pause}", "scaleY", '1', { fromValue: '1.5'}], position: 2750, duration: 422 },
            { id: "eid9", tween: [ "transform", "${_pitch}", "scaleY", '1.42', { fromValue: '1'}], position: 1000, duration: 500 },
            { id: "eid10", tween: [ "transform", "${_pitch}", "scaleY", '1', { fromValue: '1.42'}], position: 1500, duration: 500 },
            { id: "eid8", tween: [ "transform", "${_pitch}", "scaleX", '1.42', { fromValue: '1'}], position: 1000, duration: 500 },
            { id: "eid11", tween: [ "transform", "${_pitch}", "scaleX", '1', { fromValue: '1.42'}], position: 1500, duration: 500 }         ]
      }
   }
}
};


Edge.registerCompositionDefn(compId, symbols, fonts, resources);

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     Edge.launchComposition(compId);
});
})(jQuery, AdobeEdge, "EDGE-6844874");
